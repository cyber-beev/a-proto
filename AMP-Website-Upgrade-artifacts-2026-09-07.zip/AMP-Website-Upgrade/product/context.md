# AMP-Website-Upgrade — Context

## Situation

The current AMP website (ampglobalent.com) is live but visually chaotic and
presents significant UX problems: interactions require users to engage with page
elements in specific, unintuitive ways to trigger intended outcomes, and
animations are inconsistent across the site. The logo and wordmark are outdated.

AMP's branding has since been updated, and the website does not reflect the new
brand identity. The live site fails to communicate the brand at all and feels
cheap relative to the vibe AMP has established.

As background, the current site is WordPress-managed. The proposed solution
includes migrating to a more performant Next.js backend. A detailed
current-vs-proposed comparison is deferred to Stage 2 (Analysis).

> Attachments received: current-site screens (ampglobalent.com, WordPress) and
> ATIDE Studios "AMP Global — New Logo Direction" deck (July 2026). To be
> analyzed in Stage 2 and applied in Stage 4.

## Goal

**Overall picture:** A website that reflects AMP's updated brand identity, backed
by a consistent design system and animation ruleset, running on a performant
Next.js stack.

**Description:** The project delivers three things:
1. Translation of the updated brand identity / guidelines onto the website.
2. A design system for AMP's digital footprint.
3. A consistent animation ruleset.

**Justification:** AMP's client and end users get a site that communicates the
real brand identity (replacing one that reads as cheap and inconsistent), plus a
more performant Next.js backend replacing the current WordPress-managed site.

**Definition of done:** AMP partners are happy with the updated website.

## Stakeholders

| Name | Role | Organization |
| --- | --- | --- |
| Anna Berzinji | Project Manager | AMP |
| Temi Adeniji | COO / Founder | AMP |
| Joshua Ahazie | CEO | ATIDE Studios |
| Oluwafemi Bamigboye | Lead Software Developer | B9 |

### Interfaces

**Technical:** Hostinger (hosting) · GoDaddy (DNS / domain) · WordPress (current CMS, to be migrated)

**Organizational:** Standard comms flow. Escalation and approval route through
Joshua → Anna → Temi → AMP Board.

```mermaid
flowchart LR
  Dev[Oluwafemi Bamigboye<br/>Lead Dev · B9] --> Anna[Anna Berzinji<br/>PM · AMP]
  Josh[Joshua Ahazie<br/>CEO · ATIDE] --> Anna
  Anna --> Temi[Temi Adeniji<br/>COO/Founder · AMP]
  Temi --> Board[AMP Board]
```
