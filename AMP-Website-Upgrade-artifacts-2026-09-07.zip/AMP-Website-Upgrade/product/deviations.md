# Deviations Log

Change-request-only after kickoff. Any deviation from confirmed scope/plan is
recorded here.

| Date | Deviation | Reason | Impact |
| --- | --- | --- | --- |
