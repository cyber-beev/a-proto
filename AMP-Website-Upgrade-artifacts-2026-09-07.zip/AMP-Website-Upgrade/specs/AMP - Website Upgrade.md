# AMP - Website Upgrade

**Living project document.** Updated as each stage is confirmed by Bee (Lead Dev, B9).
Client: AMP Global · Started 2026-08-31 · Last updated 2026-09-07.

**Stage status:** Context ✅ confirmed · Analysis ✅ confirmed · Planning ◐ decisions and time plan set (release plan and stage sign-off outstanding) · Design ⬜ · QA ⬜ · Closure ⬜

---


## Situation

The current AMP website (ampglobalent.com) is live but visually chaotic and
presents significant UX problems: interactions require users to engage with page
elements in specific, unintuitive ways to trigger intended outcomes, and
animations are inconsistent across the site. The logo and wordmark are outdated.

AMP's branding has since been updated, and the website does not reflect the new
brand identity. The live site fails to communicate the brand at all and feels
cheap relative to the vibe AMP has established.

As background, the current site is WordPress-managed. The proposed solution
includes migrating to a more performant Next.js backend. A detailed
current-vs-proposed comparison is deferred to Stage 2 (Analysis).

> Attachments received: current-site screens (ampglobalent.com, WordPress) and
> ATIDE Studios "AMP Global — New Logo Direction" deck (July 2026). To be
> analyzed in Stage 2 and applied in Stage 4.

## Goal

**Overall picture:** A website that reflects AMP's updated brand identity, backed
by a consistent design system and animation ruleset, running on a performant
Next.js stack.

**Description:** The project delivers three things:
1. Translation of the updated brand identity / guidelines onto the website.
2. A design system for AMP's digital footprint.
3. A consistent animation ruleset.

**Justification:** AMP's client and end users get a site that communicates the
real brand identity (replacing one that reads as cheap and inconsistent), plus a
more performant Next.js backend replacing the current WordPress-managed site.

**Definition of done:** AMP partners are happy with the updated website.

## Stakeholders

| Name | Role | Organization |
| --- | --- | --- |
| Anna Berzinji | Project Manager | AMP |
| Temi Adeniji | COO / Founder | AMP |
| Joshua Ahazie | CEO | ATIDE Studios |
| Oluwafemi Bamigboye | Lead Software Developer | B9 |

### Interfaces

**Technical:** Hostinger (hosting) · GoDaddy (DNS / domain) · WordPress (current CMS, to be migrated)

**Organizational:** Standard comms flow. Escalation and approval route through
Joshua → Anna → Temi → AMP Board.

```mermaid
flowchart LR
  Dev[Oluwafemi Bamigboye<br/>Lead Dev · B9] --> Anna[Anna Berzinji<br/>PM · AMP]
  Josh[Joshua Ahazie<br/>CEO · ATIDE] --> Anna
  Anna --> Temi[Temi Adeniji<br/>COO/Founder · AMP]
  Temi --> Board[AMP Board]
```


---


> IDs are permanent once this stage is confirmed. Later stages reference these.

## Analysis: current vs. proposed

### 1. Current solution (as-is)

The live site at ampglobalent.com runs on **WordPress**, hosted on **Hostinger**
(Premium Web Hosting, prepaid through 2030-05-26), added there as an external
domain. DNS and registration for the `.com` sit at **GoDaddy**, whose zone also
holds the Microsoft 365 mail records. The two are cleanly split: GoDaddy owns
DNS + mail, Hostinger serves the site because GoDaddy's `A @` record points at the
Hostinger IP (46.202.182.36).

Problems with the as-is site (from Context):
- Visually chaotic; does not communicate AMP's brand identity, feels cheap
  relative to AMP's actual positioning.
- UX is unintuitive: elements must be interacted with in specific ways to trigger
  intended outcomes.
- Animations are inconsistent across the site; poorly executed.
- Logo and wordmark are outdated versus AMP's updated branding (ATIDE "New Logo
  Direction", July 2026).
- Originally built by a third-party agency; the AMP team has editing ability but
  has not edited since launch, so there is no internal familiarity with the WP
  build to preserve.

### 2. Proposed solution (to-be)

Rebuild on the modern stack (**Next.js / Astro**, deployed to **Vercel**, resolved
in Planning, see section 4), carrying the new ATIDE brand identity, a design
system, and a consistent animation ruleset. Include a lightweight headless **CMS**
so the team can self-edit content. Keep the **general DNS/mail setup as is**. The
GoDaddy zone and M365 records are untouched; only the web records (`A @`, `www`)
repoint to the new site at cutover.

### 3. Why replace WordPress (justification)

The brief could, in principle, be met by re-theming the existing WordPress site.
It is being replaced instead for these reasons:

1. **No preservation value in the current build.** The WP site was agency-built
   and has not been edited by the team since launch. There is no institutional
   knowledge, custom workflow, or content-editing habit that a rebuild would
   disrupt, so the usual cost of leaving WordPress does not apply here.
2. **The goals are a design-system + animation problem, not a content problem.**
   Two of the three goals (a coherent design system, a consistent animation
   ruleset) are about tightly controlled, reusable UI primitives. A component
   framework (Next.js/Astro) expresses design tokens and a shared animation
   ruleset natively and enforces consistency by construction; retrofitting the
   same rigor onto a theme + plugin stack fights the platform.
3. **Performance.** A statically-rendered / edge-served Next.js or Astro build
   removes the PHP + plugin runtime overhead of the current site, directly serving
   the "more performant" goal in the brief.
4. **The self-editing need is satisfiable without WordPress.** Anna confirmed the
   team wants editing ability. A lightweight headless CMS matched to *occasional*
   editing preserves that capability without carrying WordPress's full weight.
   Editing scope is content only. Brand guidelines editing is explicitly out of
   scope.
5. **Migration risk is bounded and unrelated to the CMS choice.** Because mail
   lives in the GoDaddy zone and nameservers stay put, cutover is a single
   in-place web-record change. Moving off WordPress does not increase DNS/email
   risk (see the migration/DNS checklist).

**Trade-off recorded:** moving off WordPress reduces the team's ability to
independently manage the full site (structure, not just content) the way a WP
admin nominally allows. This is mitigated by (a) the CMS for content, and (b)
handover documentation, captured as a risk to address in Planning/Closure.

### 4. Deploy target comparison (resolved in Planning: Vercel)

Both keep the same one-record GoDaddy DNS change; the choice does not affect email risk.

| Factor | Vercel | Reuse Hostinger (prepaid to 2030) |
|---|---|---|
| Fit with Next.js/Astro | Native; zero-config builds, edge/SSR, preview deploys | Works for static/Astro; Next.js SSR needs Node hosting setup |
| Cost | New spend (free tier may suffice; Pro if needed) | Already paid through 2030-05-26 (sunk, no new spend) |
| Performance | Global edge CDN by default | Single-origin hosting; CDN not default |
| CI/CD & previews | Git-push deploys, per-PR previews built in | Manual or self-configured pipeline |
| DNS change at cutover | `A`/`www` → Vercel target | `A`/`www` → Hostinger target (may be unchanged) |

**Resolved in Planning: Vercel** (see Planning decisions). CMS is Keystatic and
render mode is static plus a serverless form endpoint, which Vercel serves natively.

---

## Planning decisions

### CMS: Keystatic (confirmed)
Keystatic with **Keystatic Cloud free tier** for editor auth (2 editors, within
the 3-user free limit). Chosen for minimal dependencies and cost: content lives as
YAML/JSON/MDX in the Git repo (no database, no content lake), admin UI runs inside
the Next.js app at `/admin` (no separate admin app or server), TypeScript-native
schema. The live editing UI plus preview covers the approachability need. The one
SaaS touch point is Keystatic Cloud handling editor auth, chosen over
self-configuring GitHub OAuth for editor convenience; reversible to fully
self-hosted auth without content migration. True click-on-page editing (Tina) was
rejected because it forces a heavier backend dependency. A custom-built CMS was
rejected as self-owned maintenance and auth burden, worse for handoff than a free
maintained tool. Mechanism to note: each edit is a Git commit that triggers a
rebuild, fine for occasional editing. Full record: planning/decision-cms.md.

### Hosting: Vercel, existing team plan (confirmed)
Deploy the Next.js site to **Vercel under the existing team plan**. Native fit for
Next.js: git-connected deploys, a serverless function for the contact form (FR-7),
and edge CDN by default (NFR-1). It also suits Keystatic's commit-and-rebuild loop.
Free tier is expected to cover a static brochure site, so no new billing. Reusing
the prepaid Hostinger plan was rejected: it would mean hand-building the pipeline
and form endpoint to save money already sunk. A separate AMP-owned Vercel account
was considered for ownership continuity and rejected as overhead (seat management,
membership needed to deploy, another account to maintain), and the billing-lapse
risk it addressed does not apply on a free-tier static site.

### `.de` domain: redirect (confirmed)
`ampglobalent.de` redirects to `ampglobalent.com`. No separate site or regional
variant.

### Microsoft 365 email: no action required (confirmed)
Closed. Mail works and the records' location is known: M365 records sit in the
GoDaddy zone, which is authoritative and staying put. Protection is already
specified by FR-9, FR-10, FR-11 and NFR-2.

### Ownership continuity (confirmed approach)
Addressed by documentation, not account structure. AMP owns the domain and the
GoDaddy DNS zone, and the apex A-record is the real control point: AMP can repoint
the site at any time regardless of the Vercel account.

The handover package consists of three things:

1. **ZIP archive of the full project repository**, so AMP holds a complete
   standalone copy of the codebase and content, independent of access to our GitHub
   or Vercel accounts.
2. **A standing-up runbook**, because the ZIP carries code and content but not the
   environment. The runbook must cover: how to stand the project up from scratch,
   the required environment variables, the Keystatic Cloud connection, the Vercel
   project settings, how to relink it to a Git repository, and how to repoint DNS
   at a new deployment. Without this, AMP would hold the code but no path to
   running it.
3. **The Vercel-team arrangement and project-transfer path**, recording that the
   project lives in the ATIDE/B9 Vercel team and that transferring it to an
   AMP-owned Vercel account is supported if the relationship ends.

**Snapshot caveat:** the ZIP is a point-in-time snapshot and goes stale as soon as
anyone edits content through Keystatic, since content lives in the repo. It is
therefore produced at handover from the final repo state, and should be regenerated
if content changes materially after delivery.

### Time plan and milestones (confirmed)

**Constraints:** solo (Bee), ~3-4 hrs/day, calendar days including the weekend,
from Mon 2026-09-07. Budget $1500, ~15-20 hrs total, so an effort-to-cost basis of
~$75-100/hr. Scope 4-5 pages.

**Milestones**
- **Preview (Vercel URL):** end of Day 3, Wed 2026-09-09.
- **Complete site (Vercel URL):** end of Day 5, Fri 2026-09-11.
- **Go-live on ampglobalent.com:** decoupled and scheduled after delivery. DNS
  cutover, GoDaddy 2FA and mail verification all sit outside these 5 days, off the
  critical path.

The design system and animation ruleset are working tools for build coherence, not
standalone client deliverables. They are established lightly and early, held in the
repo, and not owed to AMP as polished documents. This qualifies how FR-2 and FR-3
are satisfied within this budget; measurable acceptance criteria still land in
Stage 4.

| Day | Date | Focus | Output |
|-----|------|-------|--------|
| 1 | Mon Sep 7 | Next.js scaffold, deploy to Vercel early. Design tokens from ATIDE identity (colour, type, spacing). Animation rules laid down lightly. Shared layout, header, footer, nav. | Deployed skeleton with brand system in place |
| 2 | Tue Sep 8 | Home + About built with real brand identity and layout on the tokens. Heaviest build day. | Two core pages built |
| 3 | Wed Sep 9 | Third key page (e.g. Focus Regions). Tidy 3 pages to presentable state, confirm preview URL. **Buffer parked here.** | **Milestone: preview link to AMP** |
| 4 | Thu Sep 10 | Remaining 1-2 pages. Contact form wired to serverless endpoint → info@ampglobalent.com. Google Analytics added. | Pages + form + analytics |
| 5 | Fri Sep 11 | Keystatic wired, admin at `/admin`, content moved in. Responsive + cross-page consistency pass. | **Milestone: complete site on Vercel URL** |

**Documentation checkpoint:** once the preview URL exists at the end of Day 3, this
document is updated with the live preview link and whatever the build has settled
(page set as actually built, token and animation decisions, form and analytics
wiring), so the go-live and QA moves are planned against current information rather
than the Day 1 assumptions.

**Risks**
1. 3-4 hrs/day is a firm ceiling. Any day slipping eats the Day 3 buffer fast, and
   there is no second buffer before Day 5.
2. Keystatic wiring on the last day is the classic underestimate. If Day 4 finishes
   ahead, pull it forward.

### Resourcing (confirmed)
Solo delivery by Bee (Lead Developer, B9). No additional resourcing required. Design
direction is delegated to ATIDE, and Bee is the decision-maker on that side, so no
external approval blocks the build days.

### Still outstanding before Planning can be confirmed
1. **Release plan for go-live.** The 5-day plan ends at a Vercel URL. Cutover to
   ampglobalent.com needs its own sequence and date: zone backup, TTL lowered to
   300s roughly a day ahead (NFR-3), the `A @` and `www` edit (FR-9), and
   post-cutover web plus mail verification (FR-11).
2. **Owner and date for GoDaddy 2FA / mail-record verification.** Tracker item 6,
   still unassigned. It gates go-live, not the build.
3. **Formal stage sign-off** to move `planning` to `confirmed` in state.yaml.

*Resolved 2026-09-07:* NFR-1 now carries a concrete metric (Lighthouse Performance
≥ 95 on mobile, and above the current site's score). Resourcing closed as solo.

---

## Functional requirements

| ID | Requirement | Source | Notes |
|---|---|---|---|
| FR-1 | Rebuild the site on a modern component stack (Next.js/Astro) carrying AMP's updated brand identity from the ATIDE "New Logo Direction" deck (July 2026). | Goals; Anna/Temi | Visual execution deferred to ATIDE (Stage 4). |
| FR-2 | Implement a design system (reusable tokens + components) for AMP's digital footprint. | Goals | Measurable criteria set in Stage 4. Delivered as an in-repo working tool, not a standalone document (see Time plan). |
| FR-3 | Implement a consistent, documented animation ruleset applied site-wide. | Goals | Measurable criteria set in Stage 4. Delivered as an in-repo working tool, not a standalone document (see Time plan). |
| FR-4 | Preserve existing core page content/messaging; no copy rewriting. Design-driven tightening may be proposed, not authored. | Anna; Scope | Copywriting out of scope. |
| FR-5 | Page set is at implementer's discretion; additions/removals/restructures may be proposed as part of the redesign. | Anna | Not a fixed client-imposed structure. Time plan assumes 4-5 pages. |
| FR-6 | Provide a lightweight headless CMS enabling the team to self-edit site content. | Anna | Content only; brand-guideline editing out of scope. Tool: Keystatic + Cloud free tier auth (2 editors), admin at `/admin`. See Planning decision. |
| FR-7 | Contact / "Submit Proposal" form: submissions forwarded to info@ampglobalent.com. | Anna | Serverless endpoint on Vercel. Day 4. |
| FR-8 | Integrate Google Analytics (GA) across all pages. | Anna; Scope | Tool fixed: GA. Day 4. |
| FR-9 | At cutover, repoint only the GoDaddy web records (`A @`, `www`) to the new site; do not rebuild the zone or move nameservers. | Migration checklist | Go-live, after Day 5. |
| FR-10 | Preserve all M365 mail records unchanged (MX, SPF, DKIM selectors, autodiscover, _dmarc). | Migration checklist | Zero mail-record edits. |
| FR-11 | Post-cutover verification: web resolves to new target AND test email sends/receives both directions. | Migration checklist | Go-live, after Day 5. |

## Non-functional requirements

| ID | Requirement | Source | Notes |
|---|---|---|---|
| NFR-1 | Site outperforms the current WordPress build (static/edge-served; no PHP+plugin runtime). Measured as **Lighthouse Performance ≥ 95 on mobile** (simulated throttling) for every page, and higher than the current site's score on the equivalent page. | Goals (performant) | Verified at QA. **Baseline action:** capture Lighthouse scores for the live WordPress site before cutover, while it is still serving, otherwise "outperforms" has nothing to compare against. |
| NFR-2 | Zero email downtime through migration; mail-record TTLs left as-is. | Checklist; past outage | Hard constraint. |
| NFR-3 | Cutover reversible: full GoDaddy zone backed up beforehand; web-record TTL lowered to 300s ~1 day pre-cutover. | Checklist | Belongs to the release plan, not the 5 build days. |
| NFR-4 | CMS matched to occasional editing (light footprint), not daily/heavy use. | Anna; checklist | |
| NFR-5 | Analytics respects applicable privacy/consent law given EU (`.de`) + Global-South audience. | Analysis | GA config must account for consent. |

## Deferred to later stages (not FRs yet)
- Measurable brand/design-system/animation acceptance criteria, Stage 4 (Design).

**Resolved in Planning:** deploy target (Vercel), CMS (Keystatic + Cloud free tier),
`.de` (redirect to `.com`), M365 mail records (no action required), time plan and
milestones, resourcing (solo).

## Out of scope (from SCOPE_LATEST.yaml)
- Mobile app (website only) · Content rewriting/copywriting · Editing brand guidelines.
