# CMS Comparison (Planning)

> **SUPERSEDED 2026-09-02.** This document recommends TinaCMS. The decision taken
> was **Keystatic**, which was not evaluated here. Keystatic satisfies the same
> approachability need through a live editing UI plus preview, without Tina's
> backend dependency. This file is retained only as the record of the Tina / Decap
> / Sanity comparison. The binding decision is `planning/decision-cms.md`.

**Decision context (locked inputs):** Next.js, fully static (SSG) + one serverless
form endpoint, occasional content editing (NFR-4), design-system-driven build
(FR-2), click-to-edit visual editing wanted, host leaning Vercel. Editing scope is
content only; brand guidelines out of scope.

## Candidates
Tina, Decap, and Sanity free tier, per the standing shortlist.

## How each stores content and touches the frontend

| | TinaCMS | Decap CMS | Sanity (free tier) |
|---|---|---|---|
| Storage | Git (Markdown/MDX/JSON) in the repo | Git (Markdown/YAML/JSON) in the repo | Hosted content lake (Sanity's cloud) |
| Where editing happens | On-page click-to-edit + sidebar, live preview | Separate `/admin` form UI, no on-page preview | Separate Studio app (own React app) |
| Frontend coupling | Highest: components must be wired for inline editing | Low: frontend just reads Git files | Low: frontend queries an API, Studio is decoupled |
| Design freedom | Full (no themes); coupling is structural, not visual | Full | Full |
| SaaS dependency | Tina Cloud (auth/editing) unless self-hosted | None | Sanity cloud (always) |
| Cost at this scale | Free tier likely sufficient | Free / open-source | Free tier likely sufficient |
| Fit with static + Vercel | Native (built by/for the Next.js ecosystem) | Works; static-friendly | Works; API fetch at build time |

## Against the deciding criterion: visual editing

Click-to-edit was wanted because it makes the CMS approachable for occasional
editors. That criterion splits the field cleanly:

- **Tina** is the only candidate with true on-page, click-to-edit visual editing with
  live preview. This is its defining strength.
- **Decap** has no visual/inline editing at all: editing is a separate admin form.
  Simplest to wire, but fails the stated requirement.
- **Sanity** has an excellent editing UI, but it lives in a separate Studio app, not
  on the live page. Visual/preview editing exists but needs extra setup and is not
  the same click-the-text-on-your-page experience.

## The real trade-off with Tina

Tina's visual editing is what couples CMS to design: components have to be built
"editing-aware" for inline edit to attach. Two mitigating facts for this project:

1. FR-2 already pushes the build toward reusable, structured components. An
   editing-aware component model is the same model the design system wants anyway,
   so the coupling is largely work you were doing regardless.
2. Editing is occasional (NFR-4), so the schema surface is small: hero, section
   blocks, team members, contact details. Modeling that in Tina's field types
   (string, rich-text, image, object, reference) is light.

Residual cost: Tina Cloud is a SaaS dependency (auth + editing backend). It can be
self-hosted on Node to remove that, at the price of running infrastructure.
Self-hosting also interacts with the host decision (needs Node, i.e. Vercel-style).

## Recommendation as written at the time (NOT the final decision)

**TinaCMS**, because it was the only candidate that satisfied the click-to-edit
requirement, and its one real drawback (design/component coupling) overlaps with the
design-system work already in scope.

**What changed:** Keystatic was introduced after this comparison. It keeps content in
Git like Decap, adds a TypeScript-native schema and a first-party Next.js admin UI at
`/admin`, and meets the approachability need without Tina's backend dependency. The
click-to-edit requirement was consciously downgraded to "live editing UI plus
preview" once it was clear that approachability, not literal on-page clicking, was
the underlying need. See `planning/decision-cms.md`.

## Consequence for the host decision
Both the serverless form endpoint and a Node-hosted CMS backend pull toward a
Node/serverless host. This fed the deploy-target decision, resolved as Vercel.
