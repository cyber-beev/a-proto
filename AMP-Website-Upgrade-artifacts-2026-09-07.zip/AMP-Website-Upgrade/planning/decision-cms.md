# Planning Decision: CMS

**Decision:** Use **Keystatic** with **Keystatic Cloud free tier** for editor auth
(2 editors, well within the 3-user free limit). Content stays in Git; no database,
no content lake. Admin UI at `/admin` inside the Next.js app.

## Why
- **Minimal dependencies and cost (primary driver).** Content stored as
  YAML/JSON/MDX in the project Git repo. No database, no content lake, no runtime
  cost, $0 at 2 editors. The only SaaS touch point is Keystatic Cloud for editor
  auth, a deliberate convenience trade (see Auth mode) that is reversible to a
  fully self-hosted OAuth setup without touching content.
- **Fits the stack.** First-party Next.js integration; admin UI runs inside the
  app at `/admin`, so there is no separate admin app or server to deploy
  (supersedes the earlier `admin.ampglobalent.com` idea).
- **TypeScript-native schema.** Better DX and maintainability than Decap's YAML
  config; more actively developed.
- **Approachability need is met by live editing UI + preview**, which was the real
  reason visual editing was wanted. True click-on-page editing (Tina only) was
  rejected because it forces a Tina Cloud / self-hosted-backend dependency, which
  conflicts with the minimal-deps goal.

## Auth mode
- **Chosen:** Keystatic Cloud free tier. Handles GitHub auth for editors so they
  don't each need to configure GitHub access; free for up to 3 users (only 2
  editors needed here). This is a managed-auth convenience layer only; content
  still lives in Git (YAML/JSON/MDX in the repo), no database, no content-lake
  dependency.
- **Trade-off accepted:** this adds a Keystatic Cloud account as an auth
  dependency (the one SaaS touch point), chosen over self-configuring a GitHub
  OAuth App. Still $0 at 2 editors. Fallback if the account is ever unwanted:
  switch to GitHub mode with self-hosted OAuth (no code/content migration, just an
  auth-config change).
- **Admin UI:** editor-facing path `/admin`, inside the Next.js app. No separate admin app. (Keystatic mounts at `/keystatic` by default; expose it at `/admin` via a Next.js rewrite.)

## Consequence / mechanism to note
- Every content edit is a GitHub commit that triggers a full site rebuild. Fine for
  occasional editing (NFR-4); flagged so it is understood, not a surprise. Same
  model for any Git-based CMS.

## Rejected alternatives
- **TinaCMS:** only tool with true click-to-edit, but requires Tina Cloud (or
  self-hosted Node backend + DB). Dependency rejected.
- **Decap:** zero-SaaS and proven, but YAML config, slower post-2023 development,
  and no TypeScript-native schema. Keystatic is the better-maintained equivalent.
- **Sanity / Payload / Contentful:** hosted content lake or DB-backed; more
  infrastructure than an occasional-edit marketing site needs.
- **Custom-built CMS on a subdomain:** rejected. Reintroduces the avoided costs as
  self-owned maintenance and a hand-rolled auth/security surface; worse for a
  client handoff than a free, maintained, Git-based tool.

## Effect on deploy-target decision
- Keystatic in GitHub mode is edge/serverless compatible and needs no dedicated
  Node server, so it did not force Vercel. The serverless form endpoint remained
  the main pull toward Vercel, which is the decision taken.

## Requirements touched
- Satisfies FR-6 (self-editing CMS) and NFR-4 (light footprint, occasional editing).
- FR-6 note updated: CMS tool resolved to Keystatic (was Tina/Decap/Sanity TBD).
