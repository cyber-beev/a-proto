# AMP-Website-Upgrade — Artifact Archive

Exported 2026-09-07. Client: AMP Global. Lead: Oluwafemi Bamigboye (B9).

## Single source of truth
`specs/AMP - Website Upgrade.md` is the living document. Every confirmed decision
lives there. The per-stage files below are supporting records; where they disagree
with the living document, the living document wins.

## Contents

| Path | Status |
|---|---|
| `specs/AMP - Website Upgrade.md` | **Living.** Context, Analysis, Planning decisions, time plan, FR/NFR tables |
| `state.yaml` | Stage and artifact status |
| `open-questions-for-team.md` | Living. Tracker reconciled 2026-09-07 |
| `product/context.md` | Confirmed 2026-09-01 |
| `product/SCOPE_LATEST.yaml` | Confirmed 2026-09-01 |
| `product/deviations.md` | Confirmed 2026-09-01. Empty; change-request-only after kickoff |
| `analysis/analysis.md` | Confirmed 2026-09-02 |
| `planning/decision-cms.md` | Confirmed 2026-09-02. Binding CMS record |
| `planning/cms-comparison.md` | **Superseded.** Recommends Tina; decision was Keystatic. Retained as reasoning history |

## Known gap
`analysis/requirements.md` is listed in `state.yaml` as confirmed 2026-09-02 but is
not present in this archive. Its FR and NFR tables are reproduced in full inside the
living document, so no content is lost, but the standalone file is missing.

## Stage status at export
Context confirmed · Analysis confirmed · Planning **not yet confirmed**.
Outstanding: release plan for go-live, owner and date for the GoDaddy 2FA and
mail-record verification, and formal stage sign-off.
