# AMP-Website-Upgrade — Open Questions for Team Review

**Purpose:** originally raised because Stage 2 (Analysis) was blocked pending these
confirmations. FR/NFR IDs lock once answered, so nothing here was guessed. Grouped
for a single review pass.
**Prepared:** 2026-09-01 · **Tracker reconciled:** 2026-09-07 · **Owner to route:** Anna (PM) → Josh / Temi / AMP Board as needed.

---

## A. Site scope & structure

1. **Page set.** Rebuild the existing pages like-for-like on the new brand/stack
   (Home, About Us, Focus Regions, Our Team, Contact Us, including What We Do, Our
   Edge, Who We Work With), or add/remove/restructure? Copy rewriting is out of
   scope, so we assume existing content is preserved as-is. Confirm.
2. **Content editing (CMS).** Does the team need to edit content themselves via a
   headless CMS, or is hardcoded content with a redeploy-on-change workflow
   acceptable? (Context: team can edit today but hasn't since launch → occasional
   at most.)
3. **Contact / "Submit Proposal" form.** Is there a working form today, and where
   should submissions go on the new site: email, CRM, or other? Or no form needed?

## B. Migration & email preservation
*(Source: site-migration-dns-email-checklist.md, technically detailed; needs sign-off before locking as requirements.)*

4. **Confirm the low-risk cutover approach:** edit only the web records (`A @`,
   `www`) in place in the GoDaddy zone; never rebuild the zone or move
   nameservers; leave all M365 mail records untouched (MX, SPF, DKIM,
   autodiscover, _dmarc).
5. **Deploy target for the new site:** reuse the existing Hostinger Premium plan
   (prepaid through 2030-05-26) or deploy elsewhere (e.g. Vercel)? Same one-record
   DNS change either way.
6. **GoDaddy 2FA access** to verify the remaining mail records (SMS 2FA on Temi's
   account). Who performs this and when?
7. **`.de` domain** (ampglobalent.de, empty placeholder on Hostinger): redirect to
   `.com`, keep as primary, or regional use?

## C. Analytics

8. **Tool choice:** specific product (GA4 / Plausible / Vercel Analytics / Fathom)
   or "privacy-respecting analytics, tool TBD"? Any consent/GDPR constraints given
   the Global-South + EU (`.de`) footprint?

## D. Deferred to Stage 4 (Design), noted, not blocking
- Brand identity translation, design-system tokens, and animation ruleset will get
  measurable acceptance criteria during Design, worked against the ATIDE
  "New Logo Direction" deck (July 2026). No team input needed now.

---

## Status tracker
Reconciled 2026-09-07 against the living document. Items 5 and 7 were decided
internally during Planning and are no longer questions for the team. Item 4 is
captured as requirements but has not been signed off. Item 6 is the only genuinely
open item, and the time plan places it off the critical path.

| # | Topic | Owner | Answer | Locked? |
|---|---|---|---|---|
| 1 | Page set | Anna | Our judgment; may propose add/remove/restructure | ✅ |
| 2 | CMS | Anna | Yes, include a CMS. Tool resolved internally: Keystatic | ✅ |
| 3 | Form handling | Anna | Submissions forwarded to info@ampglobalent.com | ✅ |
| 4 | Cutover approach | Bee → Anna | Captured as FR-9, FR-10, FR-11, NFR-2, NFR-3. Awaiting team sign-off | ◐ |
| 5 | Deploy target | Bee | **Resolved in Planning: Vercel, existing ATIDE/B9 team plan** | ✅ |
| 6 | 2FA / mail-record verify | Temi | **Still open.** Needs a named owner and date. Off the 5-day critical path; required before go-live | ⬜ |
| 7 | .de domain | Bee | **Resolved in Planning: redirect to .com** | ✅ |
| 8 | Analytics tool | Anna | No strong preference → our recommendation → GA (FR-8) | ✅ |
| — | Copy | Anna | Keep core messaging; may suggest tightening | ✅ |
| — | Visual direction | Anna/Temi | Defer to ATIDE on go-forward aesthetic + new logo | ✅ |
