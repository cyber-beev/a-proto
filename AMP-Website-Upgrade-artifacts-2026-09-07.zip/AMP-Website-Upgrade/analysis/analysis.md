# AMP-Website-Upgrade — Analysis

## 1. Current solution (as-is)

The live site at ampglobalent.com runs on **WordPress**, hosted on **Hostinger**
(Premium Web Hosting, prepaid through 2030-05-26), added there as an external
domain. DNS and registration for the `.com` sit at **GoDaddy**, whose zone also
holds the Microsoft 365 mail records. The two are cleanly split: GoDaddy owns
DNS + mail, Hostinger serves the site because GoDaddy's `A @` record points at the
Hostinger IP (46.202.182.36).

Problems with the as-is site (from Context):
- Visually chaotic; does not communicate AMP's brand identity, feels cheap
  relative to AMP's actual positioning.
- UX is unintuitive: elements must be interacted with in specific ways to trigger
  intended outcomes.
- Animations are inconsistent across the site; poorly executed.
- Logo and wordmark are outdated versus AMP's updated branding (ATIDE "New Logo
  Direction", July 2026).
- Originally built by a third-party agency; the AMP team has editing ability but
  has not edited since launch, so there is no internal familiarity with the WP
  build to preserve.

## 2. Proposed solution (to-be)

Rebuild on the modern stack (**Next.js / Astro**, deployed to **Vercel**, resolved
in Planning, see section 4), carrying the new ATIDE brand identity, a design
system, and a consistent animation ruleset. Include a lightweight headless **CMS**
so the team can self-edit content. Keep the **general DNS/mail setup as is**. The
GoDaddy zone and M365 records are untouched; only the web records (`A @`, `www`)
repoint to the new site at cutover.

## 3. Why replace WordPress (justification)

The brief could, in principle, be met by re-theming the existing WordPress site.
It is being replaced instead for these reasons:

1. **No preservation value in the current build.** The WP site was agency-built
   and has not been edited by the team since launch. There is no institutional
   knowledge, custom workflow, or content-editing habit that a rebuild would
   disrupt, so the usual cost of leaving WordPress does not apply here.
2. **The goals are a design-system + animation problem, not a content problem.**
   Two of the three goals (a coherent design system, a consistent animation
   ruleset) are about tightly controlled, reusable UI primitives. A component
   framework (Next.js/Astro) expresses design tokens and a shared animation
   ruleset natively and enforces consistency by construction; retrofitting the
   same rigor onto a theme + plugin stack fights the platform.
3. **Performance.** A statically-rendered / edge-served Next.js or Astro build
   removes the PHP + plugin runtime overhead of the current site, directly serving
   the "more performant" goal in the brief.
4. **The self-editing need is satisfiable without WordPress.** Anna confirmed the
   team wants editing ability. A lightweight headless CMS matched to *occasional*
   editing preserves that capability without carrying WordPress's full weight.
   Editing scope is content only. Brand guidelines editing is explicitly out of
   scope. (Tool resolved in Planning: Keystatic.)
5. **Migration risk is bounded and unrelated to the CMS choice.** Because mail
   lives in the GoDaddy zone and nameservers stay put, cutover is a single
   in-place web-record change. Moving off WordPress does not increase DNS/email
   risk (see the migration/DNS checklist).

**Trade-off recorded:** moving off WordPress reduces the team's ability to
independently manage the full site (structure, not just content) the way a WP
admin nominally allows. This is mitigated by (a) the CMS for content, and (b)
handover documentation, captured as a risk to address in Planning/Closure.

## 4. Deploy target comparison (RESOLVED in Planning: Vercel)

> **Status update 2026-09-07.** This section was written while the deploy target
> was still open. It is retained as the reasoning record. The decision is
> **Vercel on the existing ATIDE/B9 team plan**. See the Planning decisions in
> `specs/AMP - Website Upgrade.md`.

Both keep the same one-record GoDaddy DNS change; the choice does not affect email risk.

| Factor | Vercel | Reuse Hostinger (prepaid to 2030) |
|---|---|---|
| Fit with Next.js/Astro | Native; zero-config builds, edge/SSR, preview deploys | Works for static/Astro; Next.js SSR needs Node hosting setup |
| Cost | New spend (free tier may suffice; Pro if needed) | Already paid through 2030-05-26 (sunk, no new spend) |
| Performance | Global edge CDN by default | Single-origin hosting; CDN not default |
| CI/CD & previews | Git-push deploys, per-PR previews built in | Manual or self-configured pipeline |
| DNS change at cutover | `A`/`www` → Vercel target | `A`/`www` → Hostinger target (may be unchanged) |

## 5. Requirements source

Functional/non-functional requirements derived from: Context (confirmed), Anna's
team replies (page set, CMS, form, copy, analytics, visual direction), and the
migration/DNS checklist. See requirements.md, mirrored in the living document.
