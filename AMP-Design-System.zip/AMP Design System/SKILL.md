---
name: amp-global-design
description: Use this skill to generate well-branded interfaces and assets for AMP Global, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for protoyping.
user-invocable: true
---

Read `GUIDELINES.md` — it contains the entire system: content rules, visual foundations, iconography, and every token value. `index.html` is the approved prototype this system was derived from — open it to see the intended result. The other files are code: `styles.css` + `tokens/` to import, `components/` and `ui_kits/website/` to copy and fork, `assets/` for the logos and portraits.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
