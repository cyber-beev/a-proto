# UI kit — AMP Global website

A recreation of the live AMP Global site, composed from this system's components.
Copy, colour, type and spacing are taken from the production shells
(`amp-shell.jsx` / `amp-shell-mobile.jsx` in the source project), not from
screenshots.

## Structure

| File | What it holds |
| --- | --- |
| `index.html` | Click-through: page nav, section rail, light/dark, working proposal form |
| `Shell.jsx` | Fixed header, section frame, footer |
| `Screens.jsx` | The eight sections, plus the `SITE` page-to-section map |

## What the real site does that this kit does not

The production site is a **one-section-per-swipe pager**: sections are exactly
one viewport tall and a wheel, swipe or arrow key transitions between them over
800ms, with off-screen sections held `inert`. It also paints an animated dot
matrix behind everything, and switches to a separate compact layout under 768px.

This kit keeps the layout, type, colour and controls, and lets the rail switch
sections directly — enough to design against, without reproducing the pager's
gesture handling. If you need the real pager behaviour, take it from the source
project rather than rebuilding it; the momentum filtering, axis locking and
inert handling took several rounds to get right.

## Copy provenance

Headlines, the hero lead, the three "What We Do" pillars, the four "Our Edge"
items, the four "Who We Work With" labels, the team names and roles, and the
footer are **verbatim from the client's site**.

Three lines of connective body copy are **mine, written to fill a section that
has no equivalent copy in the source** — replace them before treating this kit
as a reference:

1. Approach — "Music consumption in these markets is growing faster than the
   infrastructure that supports it. We invest where that gap is widest."
2. What We Do — "Three things, in order. Capital first, then the work that makes
   it compound, then the relationships that keep it aligned."
3. Contact statement — "If you are building in these markets, or hold rights in
   them, we would like to hear from you."

## Page and section map

- **Home** — Hero, Approach
- **About** — What We Do, Our Edge, Who We Work With
- **Team** — Team & Advisors
- **Contact** — Statement, Submit Proposal

Every page ends with a footer stop, shown on the rail as a dot rather than a bar.
