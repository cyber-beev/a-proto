import React from "react";
import { Button } from "../../components/core/Button.jsx";
import { Field } from "../../components/forms/Field.jsx";
import { Card } from "../../components/display/Card.jsx";
import { Eyebrow } from "../../components/display/Eyebrow.jsx";
import { Icon } from "../../components/display/Icon.jsx";
import { FounderCard } from "../../components/display/FounderCard.jsx";
import { RegionPill } from "../../components/navigation/RegionPill.jsx";
import { Carousel } from "../../components/navigation/Carousel.jsx";

/* Copy is verbatim from the production site. */
const PILLARS = [
  ["Invest", "We deploy capital into music rights and platforms with long-term growth potential."],
  ["Build", "We actively support development, optimisation, and scale, not passive ownership."],
  ["Partner", "We collaborate with creators, rights holders, and local partners to align incentives and unlock value."],
];
const EDGES = [
  ["Local Access", "On-the-ground insight and trusted regional relationships.", "pin"],
  ["Disciplined Capital", "Institutional approach to valuation, risk, and long-term returns.", "scale"],
  ["Build, Not Just Buy", "Active ownership focused on development and scale.", "build"],
  ["Data-Informed Strategy", "Using analytics and technology to support smarter decisions and monetisation.", "data"],
];
const WHO = [
  ["Artists and creators", "head"],
  ["Catalogue owners and rights holders", "catalogue"],
  ["Independent labels and platforms", "record"],
  ["Strategic partners and investors", "partners"],
];
const FOUNDERS = [
  ["Alfonso Perez Soto", "CEO & Founder", "../../assets/alfonso.png"],
  ["Temi Adeniji", "COO & Founder", "../../assets/temi.png"],
  ["Inigo Zabala", "AMP Global Partner", "../../assets/inigo.png"],
];
const REGION_NAMES = ["Africa", "LATAM", "South Asia", "Middle East"];

const TWOCOL = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 340px), 1fr))",
  gap: "var(--space-twocol-gap)",
  alignItems: "start",
};
const D1 = {
  margin: 0,
  fontSize: "var(--text-d1-size)",
  lineHeight: "var(--text-d1-leading)",
  letterSpacing: "var(--text-d1-tracking)",
  fontWeight: "var(--weight-regular)",
};
const H2 = {
  margin: 0,
  fontSize: "var(--text-h2-size)",
  lineHeight: "var(--text-h2-leading)",
  letterSpacing: "var(--text-h2-tracking)",
  fontWeight: "var(--weight-regular)",
};
const BODY = { margin: 0, fontSize: "var(--text-body-size)", lineHeight: "var(--text-body-leading)" };
const EM = { fontWeight: "var(--weight-emphasis)" };
const RULE_LEFT = {
  borderLeft: "1px solid var(--border-rule)",
  paddingLeft: "var(--space-rule-inset)",
  alignSelf: "stretch",
};

export function Hero({ onGo }) {
  return (
    <div style={TWOCOL}>
      <h1 style={{ ...D1, textWrap: "balance" }}>
        Investing In The Future Of <span style={{ ...EM, letterSpacing: "-0.045em" }}>Global</span> Music Culture
      </h1>
      <div style={{ display: "grid", gap: 26, justifyItems: "start" }}>
        <p style={{ ...BODY, fontSize: "var(--text-lead-size)", lineHeight: "var(--text-lead-leading)", color: "var(--text-body)", maxWidth: "var(--measure-copy)" }}>
          AMP Global is a music investment platform focused on high-growth markets,
          partnering with creators, rights holders, and local ecosystems to build
          long-term value.
        </p>
        <Button variant="accent" onClick={onGo}>Submit Proposal</Button>
      </div>
    </div>
  );
}

export function Approach() {
  return (
    <div style={TWOCOL}>
      <div style={{ display: "grid", gap: 22 }}>
        <Eyebrow>Africa · LATAM · South Asia · Middle East</Eyebrow>
        <p style={{ ...BODY, color: "var(--text-body)", maxWidth: "var(--measure-copy-wide)" }}>
          Music consumption in these markets is growing faster than the
          infrastructure that supports it. We invest where that gap is widest.
        </p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
          {REGION_NAMES.map((r, i) => (
            <RegionPill key={r} active={i === 0}>{r}</RegionPill>
          ))}
        </div>
      </div>
      <h2 style={{ ...H2, ...RULE_LEFT }}>
        A Long-Term, <span style={{ ...EM, letterSpacing: "-0.035em" }}>Global</span> Approach To Music IP.
      </h2>
    </div>
  );
}

export function WhatWeDo() {
  return (
    <div style={{ display: "grid", gap: "var(--space-section-gap)" }}>
      <div style={TWOCOL}>
        <h2 style={H2}>What We Do</h2>
        <p style={{ ...BODY, ...RULE_LEFT, color: "var(--text-body)", maxWidth: "var(--measure-copy)" }}>
          Three things, in order. Capital first, then the work that makes it
          compound, then the relationships that keep it aligned.
        </p>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 260px), 1fr))", gap: "var(--space-grid-gap)" }}>
        {PILLARS.map(([title, copy]) => (
          <Card key={title} roomy>
            <Eyebrow tone="strong">{title}</Eyebrow>
            <p style={{ ...BODY, fontSize: "var(--text-small-size)", color: "var(--text-soft)" }}>{copy}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}

export function OurEdge() {
  const [active, setActive] = React.useState(0);
  return (
    <div style={TWOCOL}>
      <h2 style={H2}>Our Edge</h2>
      <div style={{ display: "grid", gap: 4 }}>
        {EDGES.map(([title, copy, shape], i) => (
          <button
            key={title}
            type="button"
            onMouseEnter={() => setActive(i)}
            onFocus={() => setActive(i)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 16,
              border: 0,
              background: "none",
              padding: "12px 0",
              textAlign: "left",
              cursor: "pointer",
              borderBottom: "1px solid var(--border-rule)",
            }}
          >
            <span
              style={{
                flex: "none",
                display: "grid",
                placeItems: "center",
                color: active === i ? "var(--accent)" : "var(--text-dim)",
                transform: active === i ? "scale(1)" : "scale(0.86)",
                transition: "color var(--transition-hover), transform var(--transition-hover)",
              }}
            >
              <Icon shape={shape} size={22} />
            </span>
            <span style={{ display: "grid", gap: 4, minWidth: 0 }}>
              <span
                style={{
                  fontSize: "var(--text-h3-size)",
                  fontWeight: "var(--weight-medium)",
                  letterSpacing: active === i ? "-0.008em" : "-0.02em",
                  color: active === i ? "var(--accent)" : "var(--text-strong)",
                  opacity: active === i ? 1 : 0.62,
                  transition: "color var(--transition-hover), letter-spacing var(--transition-hover), opacity var(--transition-hover)",
                }}
              >
                {title}
              </span>
              <span style={{ fontSize: "var(--text-small-size)", color: "var(--text-soft)" }}>{copy}</span>
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

export function WhoWeWorkWith() {
  return (
    <div style={{ display: "grid", gap: "var(--space-section-gap)" }}>
      <div style={{ display: "grid", gap: 14, justifyItems: "center", textAlign: "center" }}>
        <h2 style={{ ...H2, textAlign: "center" }}>Who We Work With</h2>
        <p style={{ ...BODY, color: "var(--text-soft)" }}>We collaborate across the music ecosystem, including:</p>
      </div>
      <div style={{ width: "100%", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 210px), 1fr))", gap: "var(--space-grid-gap)" }}>
        {WHO.map(([label, shape]) => (
          <Card key={label} roomy center>
            <Icon shape={shape} accent />
            <Eyebrow size="small" tone="strong" style={{ maxWidth: "18ch" }}>{label}</Eyebrow>
          </Card>
        ))}
      </div>
    </div>
  );
}

/**
 * Production derives the founder card's width from viewport HEIGHT — the
 * portrait is a fixed 3:4 frame, so width is the only lever that keeps a card
 * inside a one-viewport section. Capping the image's height instead crops the
 * frame and changes the card's proportions with the viewport.
 */
function useCardWidth() {
  const read = () => Math.max(176, Math.min(248, Math.round((typeof window === "undefined" ? 900 : window.innerHeight) * 0.26)));
  const [w, setW] = React.useState(read);
  React.useEffect(() => {
    const onResize = () => setW(read());
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  return w;
}

export function Team() {
  const cardW = useCardWidth();
  return (
    <div style={{ display: "grid", gap: "var(--space-section-gap)" }}>
      <div style={TWOCOL}>
        <h2 style={H2}>Team &amp; Advisors</h2>
        <p style={{ ...BODY, ...RULE_LEFT, color: "var(--text-body)", maxWidth: "var(--measure-copy)" }}>
          A global team with deep experience across music, investment, and emerging markets.
        </p>
      </div>
      <div style={{ display: "grid", gap: "var(--space-block-gap)", width: "100%", minWidth: 0 }}>
        <Eyebrow>Founders</Eyebrow>
        <div style={{ width: "100%", minWidth: 0, overflow: "hidden" }}>
          <Carousel minSlide={Math.min(200, cardW)} maxSlide={cardW} gap={20}>
            {FOUNDERS.map(([name, role, photo]) => (
              <FounderCard key={name} name={name} role={role} photo={photo} width="100%" />
            ))}
          </Carousel>
        </div>
      </div>
    </div>
  );
}

export function ContactStatement() {
  return (
    <div style={TWOCOL}>
      <h2 style={{ ...D1, maxWidth: "20ch" }}>
        Building the Next Chapter of <span style={{ ...EM, letterSpacing: "-0.04em" }}>Global</span> Music
      </h2>
      <div style={{ display: "grid", gap: 18, ...RULE_LEFT }}>
        <p style={{ ...BODY, color: "var(--text-body)", maxWidth: "var(--measure-copy)" }}>
          If you are building in these markets, or hold rights in them, we would like to hear from you.
        </p>
        <Eyebrow>Africa · LATAM · South Asia · Middle East</Eyebrow>
      </div>
    </div>
  );
}

export function Proposal() {
  const [sent, setSent] = React.useState(false);
  return (
    <div style={TWOCOL}>
      <div style={{ display: "grid", gap: 14, alignContent: "start" }}>
        <h3 style={H2}>Submit Proposal</h3>
        <p style={{ ...BODY, color: "var(--text-soft)", maxWidth: "34ch" }}>
          Tell us about your proposal and we'll get in touch.
        </p>
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          setSent(true);
        }}
        style={{ display: "grid", gap: "clamp(10px, 1.7vh, 18px)", minWidth: 0 }}
      >
        <Field label="Name" name="name" placeholder="Your name" />
        <div style={{ display: "grid", gridTemplateColumns: "minmax(0, 1fr) minmax(0, 1fr)", gap: "clamp(10px, 1.7vh, 18px)" }}>
          <Field label="Email" type="email" name="email" placeholder="you@company.com" />
          <Field label="Phone" name="phone" placeholder="Optional" />
        </div>
        <Field label="About the proposal" as="textarea" rows={4} name="detail" />
        <Button variant="accent" type="submit" style={{ justifySelf: "start" }}>Submit Proposal</Button>
        {sent && (
          <p style={{ margin: 0, fontSize: "var(--text-small-size)", color: "var(--accent)" }}>
            Thanks — we'll be in touch at the address you provided.
          </p>
        )}
      </form>
    </div>
  );
}

export const SITE = {
  Home: [
    { label: "Hero", render: (go) => <Hero onGo={go} /> },
    { label: "Approach", render: () => <Approach /> },
  ],
  About: [
    { label: "What We Do", render: () => <WhatWeDo /> },
    { label: "Our Edge", render: () => <OurEdge /> },
    { label: "Who We Work With", render: () => <WhoWeWorkWith /> },
  ],
  Team: [{ label: "Team", render: () => <Team /> }],
  Contact: [
    { label: "Statement", render: () => <ContactStatement /> },
    { label: "Proposal", render: () => <Proposal /> },
  ],
};
