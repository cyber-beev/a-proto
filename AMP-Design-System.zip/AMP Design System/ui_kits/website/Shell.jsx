import React from "react";
import { NavLink } from "../../components/navigation/NavLink.jsx";
import { SectionRail } from "../../components/navigation/SectionRail.jsx";
import { ThemeToggle } from "../../components/core/ThemeToggle.jsx";

export const PAGES = ["Home", "About", "Team", "Contact"];

/** Fixed header: wordmark left, page links and theme switch right. */
export function SiteHeader({ page, onPage, dark, onToggleTheme }) {
  return (
    <header
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 20,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 20,
        padding: "20px var(--section-pad-x)",
      }}
    >
      <img
        src={dark ? "../../assets/amp-logo-white.png" : "../../assets/amp-logo-black.png"}
        alt="AMP Global"
        style={{ width: 104, height: "auto", display: "block" }}
      />
      <nav style={{ display: "flex", alignItems: "center", gap: 22 }}>
        {PAGES.map((p) => (
          <NavLink key={p} active={page === p} onClick={() => onPage(p)}>
            {p}
          </NavLink>
        ))}
        <ThemeToggle dark={dark} onToggle={onToggleTheme} />
      </nav>
    </header>
  );
}

/**
 * One full-viewport section. The site shows exactly one at a time and pages
 * between them; here the rail switches which is mounted.
 */
export function SectionFrame({ children }) {
  return (
    <section
      style={{
        boxSizing: "border-box",
        minHeight: "100%",
        display: "grid",
        // "safe center" centres only while the content fits; once it doesn't it
        // falls back to start, so a tall section can never overflow upward
        // under the fixed header. Browsers without safe alignment get start.
        alignContent: "safe center",
        overflowY: "auto",
        // The header is 70px tall and overlays the section, so the top pad has
        // to clear it even when --section-pad-top bottoms out on a short screen.
        padding: "max(var(--section-pad-top), 76px) var(--section-pad-x) var(--section-pad-bottom)",
      }}
    >
      <div style={{ display: "grid", gap: "var(--space-section-gap)", width: "100%", minWidth: 0 }}>
        {children}
      </div>
    </section>
  );
}

export function SiteFooter({ dark }) {
  return (
    <footer
      style={{
        boxSizing: "border-box",
        borderTop: "1px solid var(--border-rule)",
        padding: "34px var(--section-pad-x)",
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "space-between",
        gap: 16,
        background: dark ? "rgba(255,255,255,0.02)" : "rgba(0,0,0,0.02)",
      }}
    >
      <div style={{ fontSize: "var(--text-ui-size-small)", color: "var(--text-soft)" }}>
        Built by <strong style={{ fontWeight: 700 }}>ATIDE</strong> x <strong style={{ fontWeight: 700 }}>B9</strong>
      </div>
      <div style={{ display: "grid", gap: 8, justifyItems: "end", textAlign: "right" }}>
        <img
          src={dark ? "../../assets/amp-logo-white.png" : "../../assets/amp-logo-black.png"}
          alt="AMP Global"
          style={{ display: "block", width: 128, height: "auto" }}
        />
        <div style={{ fontSize: "var(--text-ui-size-small)", color: "var(--text-soft)", lineHeight: 1.4 }}>
          © 2026 AMP Global.
          <br />
          All rights reserved.
        </div>
      </div>
    </footer>
  );
}

export { SectionRail };
