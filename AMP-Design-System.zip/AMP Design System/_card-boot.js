/* Card bootstrap. The specimen cards render from the component sources directly,
   so they work whether or not the compiled bundle is present. If a bundle
   namespace is available it is preferred. Cards call:

     const { Button } = await dsLoad("./", ["Button.jsx"]);
*/
(function () {
  const cache = {};

  function fromBundle(names) {
    for (const key of Object.keys(window)) {
      // Some window properties are cross-origin (frames, opener); touching them
      // throws, so every probe is guarded.
      try {
        const v = window[key];
        if (v && typeof v === "object" && names.every((n) => typeof v[n] === "function")) return v;
      } catch (e) {
        /* not ours */
      }
    }
    return null;
  }

  async function dsLoad(base, files, want) {
    if (want && want.length) {
      const hit = fromBundle(want);
      if (hit) return hit;
    }
    let src = "";
    for (const file of files) {
      const url = base + file;
      if (!cache[url]) cache[url] = await (await fetch(url)).text();
      src += cache[url].replace(/^\s*import[^;]*;\s*$/gm, "").replace(/^export\s+/gm, "") + "\n";
    }
    const names = [];
    src.replace(/^(?:function|const|let|var)\s+([A-Z][A-Za-z0-9_]*)/gm, (m, n) => {
      if (!names.includes(n)) names.push(n);
      return m;
    });
    const code = Babel.transform(src, { presets: ["react"] }).code;
    const build = new Function("React", code + "\nreturn { " + names.join(", ") + " };");
    return build(React);
  }

  window.dsLoad = dsLoad;
})();
