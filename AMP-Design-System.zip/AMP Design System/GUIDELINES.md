# AMP Global — Design System

AMP Global is a music investment platform focused on high-growth markets —
Africa, LATAM, South Asia and the Middle East. It buys and builds music rights
and the platforms around them, working with artists, catalogue owners,
independent labels and local partners. The public face of the company is a
single site; this system is derived from it.

This file is the whole system in prose and values — read it and you have the
rules. Everything else in this package is code: `index.html` (the approved
prototype, self-contained), the token stylesheets, the components, the UI kit,
and the assets.

## Sources

Everything here was read out of the production source in the sibling project,
not from screenshots:

| Source | What it gave |
| --- | --- |
| `amp-shell.jsx` | Desktop shell: palette, type scale, motion constants, section copy, icon set |
| `amp-shell-mobile.jsx` | Compact layout: the 560px measure, compact type clamps, touch behaviour |
| `amp-shell-responsive.jsx` | The combined build that switches layouts at 768px |
| `amp-assets.js`, `assets/` | Logo lockups and founder portraits |
| `uploads/ampglobalent-current-copy.md` | Team names and roles |
| `uploads/AMP GLOBAL_Carousel 1.PNG`, `… 6.PNG` | Brand carousels; the accent orange was sampled from these |

There is one product: the marketing site. No app, no docs site, no deck template
was supplied, so no UI kits or slide templates exist for those.

## CONTENT FUNDAMENTALS

**Voice.** Institutional, plain, declarative. It describes what the company does
and stops. No superlatives, no "revolutionising", no growth-hacking verbs. The
longest sentence on the site is one clause plus a qualifier:

> AMP Global is a music investment platform focused on high-growth markets,
> partnering with creators, rights holders, and local ecosystems to build
> long-term value.

**Person.** First-person plural for actions, third-person for the company.
"We deploy capital into…", "AMP Global is a music investment platform…".
Never "you" except in direct address on the contact page: "If you are building
in these markets…". Never "I".

**Casing.** Headlines are Title Case — "Investing In The Future Of Global Music
Culture", "A Long-Term, Global Approach To Music IP." Body copy is sentence
case. Labels and kickers are uppercase via CSS, written in sentence case in
source. Buttons are Title Case and verb-first: "Submit Proposal".

**Spelling.** British-leaning: "optimisation", "monetisation". Keep it.

**Sentence shape.** Section bodies are one or two sentences. Card bodies are one.
The pattern in "Our Edge" is a noun phrase then a single supporting clause:
"Local Access — On-the-ground insight and trusted regional relationships."

**Negative definition.** The copy repeatedly says what the company is *not*,
using a comma rather than a dash: "We actively support development,
optimisation, and scale, not passive ownership." "Build, Not Just Buy." Use it
sparingly; it is a house move, not a tic.

**Emoji.** None. Not in copy, not in UI, not in labels.

**Numbers.** There are none. No fund size, no deal count, no AUM, no "10x".
Do not add invented statistics to fill a layout — an empty-feeling section is a
layout problem here, not a content gap.

## VISUAL FOUNDATIONS

**Palette.** Five values: warm off-white paper `#FAF8F5`, warm near-black ink
`#17130F`, soft ink `#3A332C`, a warm rule `#DDD6CC`, and one orange
`#F9603D`. Everything else is a tint or an alpha of those. Dark mode is a
first-class, user-chosen theme — not a system-preference follow — and its card
grey `#242426` is deliberately neutral, because a tint of the warm ink read
reddish against a paper-toned palette.

**The accent is rationed.** One orange, used for: the active nav page, the active
section bar, carousel chevrons, the "Who We Work With" glyphs, the Our Edge
selection state, filled calls to action, focus rings, and the footer gradient.
It is never a panel background or a section fill. It always carries ink text,
never white — white on this orange is about 3.2:1 and fails at UI sizes; ink is
about 5.4:1.

**Type.** IBM Plex Sans, weights 400/500/600/700. One family, and the whole
typographic idea is a single move: display sizes run at **400**, and the one
emphasised word inside them jumps to **700**. That 300-step gap replaced a
600/900 pairing when the face changed, because IBM Plex Sans stops at 700.
Tracking is negative everywhere except the uppercase eyebrow, which is the only
place it opens up (0.1em at 11px, 0.06em at 15px). Display type is clamped
against viewport *height* as well as width in the compact layout, so a short
phone never gets a headline taller than its section. Write copy in sentence
case and let `text-transform` do the shouting.

**Spacing.** Fluid, not a step scale. Nearly every gap is a `clamp()` whose
middle term is a viewport unit — vh for vertical rhythm, vw for horizontal —
because sections are exactly one viewport tall and must not overflow at any
height. A fixed 4/8px scale would break the layout on a short screen.

**Layout.** Two fixed elements: the header (top, full width) and the section
indicator rail (right edge, 18px wide). Content gets its own right lane
(`--rail-lane`, 22px minimum — a lane equal to the rail's own 18px leaves no
visible gap) on the *pager*, not on each section, so every section and the
footer clear the rail as one block. The recurring content pattern is a
two-column `repeat(auto-fit, minmax(min(100%, 340px), 1fr))` grid that collapses
to one column on its own. Long copy is separated from its heading by a 1px rule
— a left border on wide layouts, a top border when stacked. The compact layout
centres a 560px measure on wide viewports rather than stretching a phone layout
across a desktop.

**Backgrounds.** A fixed, animated dot matrix sits behind everything: a 5px grid
of 0.5px dots at 0.1 opacity, brightening near the cursor and swept by a
periodic band. Region maps and the logo are rendered into the same matrix as
denser dot fields. Over that, each section gets a soft ground-tinted gradient
bleeding up from its bottom edge (16% opacity); the footer gets an accent one at
38%. No photographs are used as backgrounds. The only imagery is the three
founder portraits: black-and-white, grainy, shot against plain walls, cropped
3:4 from the top.

**Depth.** There are no drop shadows anywhere. Depth comes from three devices,
in order of preference: a 1px rule; a near-opaque frost fill
(`--surface-frost`) that lifts a control off the matrix; a gradient. The frost
is deliberately *not* a backdrop blur — the pager's transform creates a backdrop
root, so a blur there can never sample the fixed background behind it. A
`box-shadow` on an AMP surface will read as foreign.

**Corners.** Two radii: 4px for controls, 6px for boxes. Both follow the logo's
rounded stroke ends. Nothing is pill-shaped and nothing is square.

**Cards.** Flat fill, 1px rule, 6px radius, no shadow. Padding is a clamp
(12–16px, or 16–22px for icon-and-label tiles). Cards in a row are equal height,
and a card's text block reserves its lines so a wrapping name never makes one
card taller than its neighbours.

**Motion.** Four curves, and one does most of the work: `out-quint`
(`cubic-bezier(0.22, 1, 0.36, 1)`) — quick to commit, long to settle. Also
`out-expo`, `in-out-quart` for on-screen movement, and `out-back` for nav
hover only. **Nothing uses ease-in.** Pointer feedback runs at 200ms and
selection changes at 320ms — two jobs, two tokens, same curve. The full-section
page transition is 800ms, long for UI and deliberate, because it moves a whole
viewport rather than a control responding. Reduced motion caps it at 260ms
rather than removing it; the view still has to show that it changed.

**Hover and press.** Hover is colour and opacity, not movement — except the nav,
which scales to 1.12 on `out-back`. Selection states change colour *and*
letter-spacing slightly (Our Edge tightens from -0.02em to -0.008em when
active), which reads as the item leaning forward. There is no press-scale
convention on buttons; if you add one, keep it at 0.97.

**Transparency and blur.** Used sparingly and only as near-opaque tints: 0.72
for control frost, 0.9–0.92 for field fills, 0.18–0.22 for nav and footer
tints. Real `backdrop-filter` blur is 4–5px where it works at all.

**Focus.** A 2px accent outline at 3px offset. Always visible; never removed.

## ICONOGRAPHY

There is **no icon font and no third-party icon set**. The site draws fourteen
glyphs inline, and they are copied verbatim into
`components/display/Icon.jsx` — eight "who" glyphs (head, curve, headphones,
wave, mic, catalogue, record, partners), four "edge" glyphs (pin, scale, build,
data), and two chevrons for carousel controls.

The family is strict: a 34×34 viewBox, 1.6 stroke, round caps, outline only. The
one fill in the set is the record spindle. Rendered sizes are 26px in the Who
tiles, 22px in the Our Edge list, 16px in controls.

If you need a glyph that isn't in the set, **ask for it** — do not substitute
from Lucide, Heroicons or Phosphor. Their stroke weights are 1.5 or 2 on a 24
grid and will not sit with these. Unicode characters and emoji are never used as
icons.

**Logo.** Two supplied lockups, `assets/amp-logo-black.png` and
`assets/amp-logo-white.png` — both wordmark-plus-"Global", dark ink and white
knockout. Use the supplied PNGs only. There is no icon-only mark in the sources,
so none exists here. Do not reconstruct one.

## VALUES

The authoritative definitions are the stylesheets in `tokens/`; these tables are
the same values in one place, for reading and for copying into throwaway mocks.

### Colour — base

| Token | Value | Role |
| --- | --- | --- |
| `--paper` | `#FAF8F5` | Warm off-white ground |
| `--ink` | `#17130F` | Warm near-black |
| `--ink-soft` | `#3A332C` | Body ink |
| `--rule` | `#DDD6CC` | Warm 1px rule |
| `--accent` | `#F9603D` | The one orange |

`--accent-fg` is `--ink`, always. Ink on accent is ~5.4:1; white on accent is
~3.2:1 and fails at UI sizes.

### Colour — surfaces and text

| Token | Light | Dark |
| --- | --- | --- |
| `--ground` | `#FAF8F5` | `#17130F` |
| `--surface-card` | `#FFFFFF` | `#242426` |
| `--surface-field` | `rgba(255,255,255,.92)` | `rgba(34,28,23,.9)` |
| `--surface-frost` | `rgba(255,255,255,.72)` | `rgba(46,39,32,.72)` |
| `--surface-off` | `#E4DED4` | `rgba(255,255,255,.13)` |
| `--border-rule` | `#DDD6CC` | `#4A423A` |
| `--text-strong` | `#17130F` | `#FAF8F5` |
| `--text-body` | `#3A332C` | `#D6CFC5` |
| `--text-soft` | `#6B635B` | `#C9C2B8` |
| `--text-dim` | `#8C847A` | `#8C8478` |
| `--button-solid-bg` / `-fg` | ink on paper | paper on ink |

Dark also flips `--rail-inactive` to a paper alpha; `--rail-active` is the
accent in both themes.

### Type scale

| Step | Size | Leading | Tracking | Weight |
| --- | --- | --- | --- | --- |
| D1 | `clamp(2.4rem, 5.6vw, 5.2rem)` | 0.98 | -0.035em | 400 |
| D1 compact | `clamp(2.1rem, min(10.5vw, 5.2vh), 3.3rem)` | 1.02 | -0.035em | 400 |
| H2 | `clamp(1.75rem, 3.4vw, 3rem)` | 1.08 | -0.025em | 400 |
| H2 compact | `clamp(1.5rem, min(7.4vw, 4vh), 2.1rem)` | 1.08 | -0.025em | 400 |
| H3 | `clamp(1.25rem, 2.2vw, 1.75rem)` | 1.3 | -0.02em | 500 |
| Sub | `1.125rem` | — | -0.01em | 600 |
| Lead | `clamp(1.0625rem, 1.3vw, 1.25rem)` | 1.55 | — | 400 |
| Body | `1.0625rem` (compact `1rem`) | 1.65 (1.6) | — | 400 |
| Small | `0.9375rem` | — | — | 400 |
| Micro | `0.8125rem` | — | — | 400 |
| Eyebrow | `0.6875rem` | — | +0.1em, uppercase | 500 |
| List caps | `clamp(1rem, 1.6vw, 1.25rem)` | — | +0.06em, uppercase | 500 |

Control type: 15px for buttons, nav and pills; 14px for footer and meta; **16px
minimum inside inputs**, or iOS zooms on focus. Card names run 1.125rem/600 at
+0.02em uppercase.

### Spacing

| Token | Value |
| --- | --- |
| `--space-section-gap` | `clamp(18px, 4vh, 64px)` |
| `--space-block-gap` | `clamp(14px, 2.2vh, 22px)` |
| `--space-card-pad` | `clamp(12px, 1.8vh, 16px)` |
| `--space-card-pad-roomy` | `clamp(16px, 2.6vh, 22px)` |
| `--space-card-gap` | `clamp(12px, 2vh, 18px)` |
| `--space-grid-gap` | `clamp(14px, 1.6vw, 20px)` |
| `--space-twocol-gap` | `clamp(28px, 5vw, 80px)` |
| `--space-rule-inset` | `clamp(20px, 3vw, 44px)` |
| `--section-pad-x` | `clamp(20px, 5vw, 72px)` · compact `20px` |
| `--section-pad-top` | `clamp(64px, 9vh, 104px)` · compact `clamp(70px, 11vh, 92px)` |
| `--section-pad-bottom` | `clamp(28px, 5vh, 72px)` · compact `clamp(22px, 4vh, 34px)` |
| `--rail-width` / `--rail-lane` | `18px` / `22px` |
| `--measure-compact` | `560px` |
| `--measure-copy` / `-wide` | `46ch` / `58ch` |
| `--tap-target` | `44px` |

### Radius and depth

`--radius-control: 4px`, `--radius-box: 6px`. No shadows: `--shadow-none: none`.
Gradient opacities are 0.16 for a section ground and 0.38 for the footer accent;
frost tints are 0.18 (nav) and 0.22 (footer), with 5px and 4px blur respectively.

### Motion

| Token | Value | Used for |
| --- | --- | --- |
| `--ease-out-quint` | `cubic-bezier(0.22, 1, 0.36, 1)` | House curve |
| `--ease-out-expo` | `cubic-bezier(0.16, 1, 0.3, 1)` | — |
| `--ease-in-out-quart` | `cubic-bezier(0.76, 0, 0.24, 1)` | On-screen movement |
| `--ease-out-back` | `cubic-bezier(0.34, 1.4, 0.64, 1)` | Nav hover only |
| `--duration-hover` | 200ms | Pointer feedback |
| `--duration-selection` | 320ms | Selection settling |
| `--duration-swap` | 260ms | Bar and colour swaps |
| `--duration-carousel` | 420ms | Carousel slide |
| `--duration-nav` | 420ms | Nav open/close |
| `--duration-nav-hover` | 220ms | Nav link scale (1.12) |
| `--duration-theme` | 400ms | Light/dark swap |
| `--duration-page` | 800ms | Full-section page transition |
| `--duration-page-reduced` | 260ms | Same, under reduced motion |

## MOTION AUDIT

The site's motion reviewed against the animation standards in
`uploads/skills-main/skills/review-animations/STANDARDS.md`. Values are read
from the production shells.

### Passes

**Easing.** The house curve is a strong ease-out, close to the reference
`--ease-out: cubic-bezier(0.23, 1, 0.32, 1)`. On-screen movement uses
`in-out-quart`, matching the reference's strong ease-in-out. Nothing uses
ease-in. The one overshoot curve, `out-back`, is confined to nav hover — bounce
reserved for a playful accent rather than applied across the UI.

**Should it animate.** Section paging is an occasional action, correctly
animated. Keyboard paging reuses the same transition rather than adding one of
its own. Hover effects are colour and opacity only, not movement — which is what
the frequency table asks for at "tens of times a day".

**Interruptibility.** Carousel slides, hover states and theme swaps are CSS
`transition`s, not keyframes, so a rapid second input retargets rather than
restarting. The section pager is rAF-driven with an explicit animation lock and
a cooldown, so a mid-flight input is swallowed rather than queued.

**Performance.** Only `transform` and `opacity` animate. The pager writes
`transform` directly on the moving element rather than setting a CSS variable
on a parent, which is exactly the recalc trap the standards call out.

**Gestures.** Dismissal is velocity-based, not distance-based
(`touchVel: 0.45px/ms` alongside `touchDist: 60px`, either one commits).
Over-drag past either end is damped to 0.35–0.5 rather than hitting a wall.
Pointer capture is taken on drag start in the desktop carousel. Multi-touch is
guarded by a per-gesture axis lock, so a second finger cannot jump the track.

**Accessibility.** `prefers-reduced-motion` caps the page transition at 260ms
instead of removing it — the standards' "fewer and gentler, not zero".

**Stagger.** Not used. Nothing is staggered, so nothing blocks interaction
waiting for a stagger to finish.

### Findings

**1. The page transition is 800ms, well over the 300ms UI ceiling.**
The standards allow 200–500ms for modals and drawers and say UI stays under
300ms. This is a deliberate exception: it moves a full viewport, so it reads as
"marketing / explanatory" rather than a control responding. Worth testing at
600ms if it ever feels slow — but it is the site's signature and not a defect.

**2. ~~Hover transitions run at 320ms~~ — fixed.** One token was doing two jobs.
Pointer feedback on buttons and carousel arrows now runs at 200ms
(`--duration-hover`); selection changes — a region becoming active, a rail bar
filling, an Our Edge item being chosen — keep 320ms (`--duration-selection`),
where the longer settle is the point. Both share `out-quint`, so the two still
read as one family.

**3. Hover motion is not gated behind `@media (hover: hover)`.** The nav's
1.12 hover scale can fire on a tap on touch devices. The standards ask for that
gate explicitly.

**4. No press feedback anywhere.** Buttons have no `:active` state. The
standards recommend `transform: scale(0.97)` at 160ms ease-out on pressable
elements; the system has no convention for it.

**5. `scale(0)` check — clean.** Nothing animates from zero scale. The Our
Edge selection scales between 0.86 and 1, well inside the 0.9–0.97 guidance.

**6. Carousel opacity dip.** Off-frame slides sit at 0.5 opacity and cross-fade
over 420ms alongside the transform. This is the "opacity plus movement in
entering/exiting lists" case the standards describe as trial and error; it reads
cleanly here and needs no blur masking.

### Recommendation order

Finding (2) is done. Of what remains: (4) add a press-scale convention, then
(3) gate hover motion behind `hover: hover`. (1) should be left alone unless the
client raises it.

## Index

| Path | What it is |
| --- | --- |
| `GUIDELINES.md` | This file — every rule and value in the system |
| `index.html` | The approved prototype, self-contained. The reference build for the polished app. |
| `styles.css` | The entry point. `@import` list only. |
| `tokens/` | `fonts`, `colors`, `typography`, `spacing`, `radius`, `motion`, `elevation` |
| `components/core/` | `Button`, `ThemeToggle` |
| `components/forms/` | `Field` |
| `components/display/` | `Card`, `Eyebrow`, `Icon`, `FounderCard` |
| `components/navigation/` | `NavLink`, `SectionRail`, `RegionPill`, `Carousel` |
| `ui_kits/website/` | The site recreation — `index.html`, `Shell.jsx`, `Screens.jsx` |
| `assets/` | Logo lockups, three founder portraits |
| `_card-boot.js` | Lets the component cards and UI kit render from source, with or without the compiled bundle |

## Component inventory

The component list **is** the site's inventory. Nothing was added because a
design system "usually" has it — there is no Toast, Avatar, Tabs, Tooltip,
Dialog, Switch or Badge here, because the site has none.

**Intentional additions (2):**

- `Icon` — a wrapper around the site's fourteen inline glyphs. The site repeats
  the SVGs in two local components (`WhoIcon`, `EdgeIcon`); this merges them
  into one addressable set without changing any path data.
- `Carousel` — generalised from the founders carousel, which exists on the site
  but is welded into its Team section. Extracted so other short card rows can
  page the same way.

## Caveats

- **Fonts are CDN-loaded.** No licensed binaries were supplied, so
  `tokens/fonts.css` imports IBM Plex Sans from Google Fonts and declares no
  local `@font-face` rules. If you have the files, drop them in and they should
  be declared properly.
- **Inigo Zabala's portrait is a placeholder frame**, not a photo.
- **The dot-matrix background is documented but not implemented here.** It is a
  canvas renderer with cursor tracking, periodic sweeps and rasterised region
  maps — several hundred lines in the source. Take it from the production shells
  rather than rebuilding it.
- **Three lines of connective copy in the UI kit are mine, not the client's** —
  see `ui_kits/website/README.md`. Replace them with real copy before the kit
  is used as a reference.
- **The Approach section's region map is omitted** from the UI kit.
