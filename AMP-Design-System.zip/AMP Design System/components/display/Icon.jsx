import React from "react";

/**
 * The site's complete glyph set, copied from the production shells. One family:
 * 34×34 grid, 1.6 stroke, no fills except the record spindle. There is no icon
 * font and no third-party set — if a glyph is missing, it does not exist yet.
 */
const PATHS = {
  head: (
    <>
      <circle cx="17" cy="12" r="7" />
      <path d="M5.5 30c1.8-6.2 5.9-9.2 11.5-9.2s9.7 3 11.5 9.2" />
    </>
  ),
  curve: <path d="M2 17c3.2 0 4-11 7.2-11s4 22 7.2 22 4-16.5 7.2-16.5S29 17 32 17" />,
  headphones: (
    <>
      <path d="M5.5 21v-4a11.5 11.5 0 0 1 23 0v4" />
      <rect x="3" y="20" width="6" height="10" rx="3" />
      <rect x="25" y="20" width="6" height="10" rx="3" />
    </>
  ),
  wave: <path d="M3 17v0M8 11v12M13 6v22M18 9.5v15M23 13v8M28 15.5v3" />,
  mic: (
    <>
      <rect x="12.5" y="3" width="9" height="16" rx="4.5" />
      <path d="M7.5 15.5a9.5 9.5 0 0 0 19 0" />
      <path d="M17 25v6" />
    </>
  ),
  catalogue: (
    <>
      <rect x="4" y="6" width="18" height="22" rx="1.5" />
      <path d="M26 9.5c2 .6 3 1.2 3 2.4V26c0 1.4-1.3 2-3 2.4" />
      <path d="M9 13h8M9 18h8" />
    </>
  ),
  record: (
    <>
      <circle cx="17" cy="17" r="13" />
      <circle cx="17" cy="17" r="6" />
      <circle cx="17" cy="17" r="1.4" fill="currentColor" stroke="none" />
    </>
  ),
  partners: (
    <>
      <circle cx="12" cy="17" r="9" />
      <circle cx="22" cy="17" r="9" />
    </>
  ),
  pin: (
    <>
      <path d="M17 31c6.5-8 9.5-12.6 9.5-17a9.5 9.5 0 0 0-19 0c0 4.4 3 9 9.5 17z" />
      <circle cx="17" cy="13.5" r="3.2" />
    </>
  ),
  scale: (
    <>
      <path d="M17 5v24M7 29h20" />
      <path d="M4 12h26M4 12l-2.5 6.5h5zM30 12l2.5 6.5h-5z" />
    </>
  ),
  build: (
    <>
      <rect x="4" y="21" width="8" height="9" />
      <rect x="13" y="14" width="8" height="16" />
      <rect x="22" y="7" width="8" height="23" />
    </>
  ),
  data: (
    <>
      <path d="M5 5v24h24" />
      <path d="M10 23l6.5-7.5 5 4L29 10" />
    </>
  ),
  chevronLeft: <polyline points="19.5,5 8.5,17 19.5,29" />,
  chevronRight: <polyline points="14.5,5 25.5,17 14.5,29" />,
};

export const ICON_SHAPES = Object.keys(PATHS);

export function Icon({ shape, size = 26, accent = false, style, ...rest }) {
  const d = PATHS[shape];
  if (!d) return null;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 34 34"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      aria-hidden="true"
      style={{ display: "block", color: accent ? "var(--accent)" : undefined, ...style }}
      {...rest}
    >
      {d}
    </svg>
  );
}
