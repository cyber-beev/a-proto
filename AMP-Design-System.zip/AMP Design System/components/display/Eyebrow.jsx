import React from "react";

/** Uppercase micro label. The only place tracking opens up in this system. */
export function Eyebrow({ size = "micro", tone = "soft", as = "div", children, style, ...rest }) {
  const Tag = as;
  return (
    <Tag
      style={{
        fontSize: size === "small" ? "var(--text-small-size)" : "var(--text-eyebrow-size)",
        fontWeight: "var(--weight-medium)",
        letterSpacing: size === "small" ? "var(--text-list-caps-tracking)" : "var(--text-eyebrow-tracking)",
        textTransform: "uppercase",
        lineHeight: size === "small" ? 1.45 : 1.2,
        color: tone === "strong" ? "var(--text-strong)" : "var(--text-soft)",
        ...style,
      }}
      {...rest}
    >
      {children}
    </Tag>
  );
}
