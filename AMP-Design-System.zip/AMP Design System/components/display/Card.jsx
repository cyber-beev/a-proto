import React from "react";

/** The system's one container: 1px rule, 6px radius, flat fill. No shadow. */
export function Card({ roomy = false, center = false, children, style, ...rest }) {
  return (
    <div
      style={{
        boxSizing: "border-box",
        minWidth: 0,
        border: "1px solid var(--border-rule)",
        borderRadius: "var(--radius-box)",
        background: "var(--surface-card)",
        padding: roomy ? "var(--space-card-pad-roomy)" : "var(--space-card-pad)",
        display: "grid",
        gridTemplateColumns: "minmax(0, 1fr)",
        gap: "var(--space-card-gap)",
        alignContent: "start",
        color: "var(--text-strong)",
        ...(center ? { justifyItems: "center", textAlign: "center" } : null),
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}
