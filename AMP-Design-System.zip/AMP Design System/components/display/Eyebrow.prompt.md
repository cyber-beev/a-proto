One-line: the uppercase kicker that labels a block — "FOUNDERS", "AFRICA · LATAM · SOUTH ASIA · MIDDLE EAST", card captions.

```jsx
<Eyebrow>Founders</Eyebrow>
<Eyebrow size="small" tone="strong">Catalogue owners and rights holders</Eyebrow>
```

Notes
- Write the text in sentence case in JSX and let `text-transform` do the shouting, so copy stays readable in source.
- `micro` (11px / 0.1em) labels a section. `small` (15px / 0.06em) is the card-label size used inside the Who tiles.
