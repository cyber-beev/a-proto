import React from "react";
import { Card } from "./Card.jsx";

/**
 * Portrait card. The portrait is a fixed 3:4 frame and the card is sized by
 * WIDTH alone — capping the image's height instead crops the frame and changes
 * the card's proportions with the viewport.
 */
export function FounderCard({ name, role, photo, width = 248, style, ...rest }) {
  return (
    <Card style={{ width, height: "100%", ...style }} {...rest}>
      {photo ? (
        <img
          src={photo}
          alt={name}
          style={{
            width: "100%",
            aspectRatio: "3 / 4",
            objectFit: "cover",
            objectPosition: "center top",
            display: "block",
            borderRadius: "var(--radius-control)",
            background: "var(--photo-placeholder)",
            border: "1px solid var(--border-rule)",
          }}
        />
      ) : (
        <div
          style={{
            width: "100%",
            aspectRatio: "3 / 4",
            borderRadius: "var(--radius-control)",
            background: "var(--photo-placeholder)",
            border: "1px solid var(--border-rule)",
          }}
        />
      )}
      <div>
        <div
          style={{
            fontSize: "var(--text-sub-size)",
            fontWeight: "var(--weight-semibold)",
            letterSpacing: "0.02em",
            textTransform: "uppercase",
            lineHeight: 1.3,
            minHeight: "2.6em",
          }}
        >
          {name}
        </div>
        <div style={{ marginTop: 6, fontSize: "var(--text-small-size)", color: "var(--text-soft)" }}>
          {role}
        </div>
      </div>
    </Card>
  );
}
