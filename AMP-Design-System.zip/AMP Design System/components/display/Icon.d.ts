import type { CSSProperties } from "react";

/**
 * The site's whole glyph set. 34×34 grid, 1.6 stroke, outline only.
 *
 * @startingPoint section="Display" subtitle="The complete 14-glyph set" viewport="700x150"
 */
export interface IconProps {
  shape:
    | "head" | "curve" | "headphones" | "wave" | "mic" | "catalogue" | "record" | "partners"
    | "pin" | "scale" | "build" | "data"
    | "chevronLeft" | "chevronRight";
  /** Rendered px. 26 in the Who tiles, 22 in the Our Edge list, 16 in controls. */
  size?: number;
  /** Paint the glyph with --accent. Who-tile icons do; Our Edge uses it for selection only. */
  accent?: boolean;
  style?: CSSProperties;
}

export declare const ICON_SHAPES: IconProps["shape"][];
export function Icon(props: IconProps): JSX.Element | null;
