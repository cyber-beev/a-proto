One-line: a team member — 3:4 portrait above an uppercase name and a soft role line.

```jsx
<FounderCard name="Temi Adeniji" role="COO & Founder" photo="assets/temi.png" />
<FounderCard name="Inigo Zabala" role="AMP Global Partner" />
```

Notes
- The name block reserves two lines (`min-height: 2.6em`) so a wrapping name never makes its card taller than its neighbours.
- Never cap the portrait's height to fit a section. Size the card by WIDTH and derive that width from viewport height, the way production does:

  ```js
  const cardW = Math.max(176, Math.min(248, Math.round(window.innerHeight * 0.26)));
  ```

  A hardcoded 248 produces a ~408px card, which overflows a one-viewport section on any screen shorter than about 610px.
- Omitting `photo` gives the blank placeholder frame; that is the correct state for a portrait you don't have yet, not a drawn avatar.
