One-line: every boxed surface on the site — founder cards, capability cards, the "Who We Work With" tiles.

```jsx
<Card roomy center>
  <Icon shape="record" />
  <Eyebrow size="small">Independent labels and platforms</Eyebrow>
</Card>
```

Notes
- Never add a `box-shadow`. Depth in this system is a rule, a frost fill, or a gradient — see tokens/elevation.css.
- `grid-template-columns: minmax(0, 1fr)` is deliberate: without it a long unbroken label inflates the card's column and drags images past its edge.
- Cards in a row should be equal height — put them in a flex row and let the card fill, rather than letting each size to its own content.
