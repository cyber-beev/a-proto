import type { CSSProperties } from "react";

/** A person: 3:4 portrait, uppercase name, soft role line. */
export interface FounderCardProps {
  name: string;
  role: string;
  /** Omit to render the empty placeholder frame used for portraits not yet supplied. */
  photo?: string;
  /** px, or "100%" inside a carousel slide. */
  width?: number | string;
  style?: CSSProperties;
}

export function FounderCard(props: FounderCardProps): JSX.Element;
