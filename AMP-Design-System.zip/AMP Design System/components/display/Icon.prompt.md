One-line: every icon on the site, copied verbatim from the production shells — there is no icon font and no third-party set.

```jsx
<Icon shape="record" accent />
<Icon shape="scale" size={22} />
<Icon shape="chevronRight" size={16} />
```

Notes
- Eight "who" glyphs (head, curve, headphones, wave, mic, catalogue, record, partners), four "edge" glyphs (pin, scale, build, data), two chevrons for carousel controls.
- Stroke is always 1.6 on a 34-unit grid, so glyphs stay one family across sizes.
- If you need a glyph that isn't here, ask for it rather than substituting from Lucide or Heroicons — the stroke weight will not match.
