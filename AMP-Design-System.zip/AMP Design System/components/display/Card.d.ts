import type { CSSProperties, ReactNode } from "react";

/**
 * The only container in the system — flat fill, 1px rule, 6px radius, never a shadow.
 *
 * @startingPoint section="Display" subtitle="Bordered content card" viewport="700x220"
 */
export interface CardProps {
  /** Wider padding, for icon-and-label cards that stand alone in a grid. */
  roomy?: boolean;
  /** Centres content and text — the "Who We Work With" treatment. */
  center?: boolean;
  children?: ReactNode;
  style?: CSSProperties;
}

export function Card(props: CardProps): JSX.Element;
