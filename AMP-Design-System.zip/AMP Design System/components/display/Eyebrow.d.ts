import type { CSSProperties, ReactNode } from "react";

/** Uppercase kicker: section labels ("FOUNDERS"), card labels, field labels. */
export interface EyebrowProps {
  /** micro = 11px kicker; small = 15px card label. */
  size?: "micro" | "small";
  tone?: "soft" | "strong";
  as?: "div" | "span" | "p";
  children?: ReactNode;
  style?: CSSProperties;
}

export function Eyebrow(props: EyebrowProps): JSX.Element;
