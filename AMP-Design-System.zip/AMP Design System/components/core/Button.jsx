import React from "react";

/**
 * AMP's only button. Three variants, all 1px-bordered, all on --radius-control.
 * "accent" always pairs the orange with ink — never white.
 */
export function Button({
  variant = "solid",
  size = "md",
  as = "button",
  frosted = false,
  children,
  style,
  ...rest
}) {
  const pad = size === "sm" ? "10px 20px" : "14px 28px";
  const skin = {
    solid: { background: "var(--button-solid-bg)", color: "var(--button-solid-fg)", borderColor: "var(--button-solid-bg)" },
    accent: { background: "var(--accent)", color: "var(--accent-fg)", borderColor: "var(--accent)" },
    outline: {
      background: frosted ? "var(--surface-frost)" : "transparent",
      color: "var(--text-strong)",
      borderColor: "var(--text-strong)",
    },
  }[variant];
  const Tag = as;
  return (
    <Tag
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        padding: pad,
        borderStyle: "solid",
        borderWidth: 1,
        borderRadius: "var(--radius-control)",
        fontFamily: "inherit",
        fontSize: "var(--text-ui-size)",
        fontWeight: "var(--weight-medium)",
        lineHeight: 1,
        whiteSpace: "nowrap",
        cursor: "pointer",
        transition: "background var(--transition-hover), border-color var(--transition-hover), color var(--transition-hover)",
        ...skin,
        ...style,
      }}
      {...rest}
    >
      {children}
    </Tag>
  );
}
