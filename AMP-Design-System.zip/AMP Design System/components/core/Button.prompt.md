One-line: AMP's only button — use `accent` for the primary call to action, `solid` for form submits, `outline` for anything secondary.

```jsx
<Button variant="accent" onClick={goToContact}>Submit Proposal</Button>
<Button variant="outline" frosted>Read the approach</Button>
<Button variant="solid" type="submit" size="sm">Send</Button>
```

Notes
- `accent` renders ink text on the orange, never white — white on #F9603D is ~3.2:1 and fails at 15px.
- `frosted` exists for outline buttons placed over the dot-matrix background; it fills with a near-opaque tint rather than a backdrop blur, because the pager's transform makes a backdrop root.
- Label copy is title case and verb-first: "Submit Proposal", not "SUBMIT PROPOSAL" or "Submit a proposal now".
