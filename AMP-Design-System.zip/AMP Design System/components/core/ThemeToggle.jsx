import React from "react";

/** Sun/moon glyph toggle. Dark mode is user-chosen here, not system-followed. */
export function ThemeToggle({ dark = false, onToggle, style, ...rest }) {
  return (
    <button
      type="button"
      aria-pressed={dark}
      aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}
      onClick={onToggle}
      style={{
        width: 30,
        height: 30,
        display: "grid",
        placeItems: "center",
        border: 0,
        background: "none",
        color: "var(--text-strong)",
        cursor: "pointer",
        transition: "color var(--transition-hover)",
        ...style,
      }}
      {...rest}
    >
      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden="true">
        {dark ? (
          <path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z" />
        ) : (
          <>
            <circle cx="12" cy="12" r="4.2" />
            <path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M18.7 5.3l-1.6 1.6M6.9 17.1l-1.6 1.6" />
          </>
        )}
      </svg>
    </button>
  );
}
