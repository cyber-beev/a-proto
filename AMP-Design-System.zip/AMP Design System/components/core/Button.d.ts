import type { CSSProperties, ReactNode } from "react";

/**
 * The site's button. Solid for form submits, accent for calls to action,
 * outline for secondary actions sitting on the animated matrix.
 *
 * @startingPoint section="Core" subtitle="Solid, accent and outline buttons" viewport="700x180"
 */
export interface ButtonProps {
  /** solid = ink fill; accent = orange fill with ink text; outline = 1px rule. */
  variant?: "solid" | "accent" | "outline";
  size?: "sm" | "md";
  /** Render as another element, e.g. "a" for a link-styled action. */
  as?: "button" | "a";
  /** Outline only: fills with --surface-frost so the control lifts off the matrix. */
  frosted?: boolean;
  children?: ReactNode;
  style?: CSSProperties;
  onClick?: () => void;
  disabled?: boolean;
  type?: "button" | "submit";
  href?: string;
}

export function Button(props: ButtonProps): JSX.Element;
