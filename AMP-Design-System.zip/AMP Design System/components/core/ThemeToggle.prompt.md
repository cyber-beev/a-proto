One-line: the header's light/dark switch — set `data-theme="dark"` on a root element in response to it.

```jsx
const [dark, setDark] = React.useState(false);
<div data-theme={dark ? "dark" : undefined}>
  <ThemeToggle dark={dark} onToggle={() => setDark(!dark)} />
</div>
```

Notes
- 30×30 glyph, no border or background — it sits inside the fixed header beside the nav.
- The theme swap animates `background` and `color` over `--duration-theme` (400ms); don't animate anything else across the change.
