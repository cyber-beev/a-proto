import type { CSSProperties } from "react";

/** Header sun/moon switch. Dark mode is an explicit user choice on this site. */
export interface ThemeToggleProps {
  dark?: boolean;
  onToggle?: () => void;
  style?: CSSProperties;
}

export function ThemeToggle(props: ThemeToggleProps): JSX.Element;
