import React from "react";

/**
 * A page link in the fixed header. Active takes the accent and weight 700.
 *
 * The hover scale sits on a nested span, not on the button. In production the
 * button's own `transform` is owned by the header's fold-in animation, and two
 * animations cannot share one property without the later one inheriting the
 * other's timing — so hover gets its own element.
 */
export function NavLink({ active = false, children, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      type="button"
      aria-current={active ? "page" : undefined}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      onFocus={() => setHover(true)}
      onBlur={() => setHover(false)}
      style={{
        border: 0,
        background: "none",
        padding: 0,
        cursor: "pointer",
        fontFamily: "inherit",
        fontSize: "var(--text-ui-size-small)",
        fontWeight: active ? "var(--weight-emphasis)" : "var(--weight-regular)",
        color: active ? "var(--accent)" : "var(--text-strong)",
        whiteSpace: "nowrap",
        transition: "color var(--transition-hover)",
        ...style,
      }}
      {...rest}
    >
      <span
        style={{
          display: "inline-block",
          transform: hover ? "scale(var(--nav-hover-scale))" : "scale(1)",
          transition: "transform var(--duration-nav-hover) var(--ease-out-back)",
        }}
      >
        {children}
      </span>
    </button>
  );
}
