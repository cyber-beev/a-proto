One-line: one of the four page links in the fixed header.

```jsx
{["Home", "About", "Team", "Contact"].map((p) => (
  <NavLink key={p} active={page === p} onClick={() => setPage(p)}>{p}</NavLink>
))}
```

Notes
- Active is colour + weight only (accent, 700). No underline, no pill, no background.
- Nav links are 14px, one step down from the 15px used for buttons and inputs.
- Hover is a 1.12 scale over 220ms on `--ease-out-back` — the one place in the system that overshoots.
- That scale is applied to a **nested span**, not to the button. The header's fold-in animation owns the button's own `transform`; putting hover on the same property makes it inherit the fold's 1180ms timing. If you add any other transform-based state here, give it its own element too.
- Lay the set out with `display: flex` and a gap; the header collapses to a menu button below the compact breakpoint.
