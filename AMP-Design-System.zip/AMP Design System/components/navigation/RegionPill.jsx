import React from "react";

/** Region selector on the focus-map section. Selected fills with the accent. */
export function RegionPill({ active = false, size = "md", children, style, ...rest }) {
  return (
    <button
      type="button"
      aria-pressed={active}
      style={{
        padding: size === "sm" ? "12px 6px" : "13px 30px",
        minHeight: size === "sm" ? "var(--tap-target)" : undefined,
        textAlign: "center",
        border: `1px solid ${active ? "var(--accent)" : "var(--border-rule)"}`,
        borderRadius: "var(--radius-control)",
        background: active ? "var(--accent)" : "transparent",
        color: active ? "var(--accent-fg)" : "var(--text-strong)",
        fontFamily: "inherit",
        fontSize: "var(--text-ui-size)",
        fontWeight: "var(--weight-medium)",
        cursor: "pointer",
        transition: "background var(--transition-selection), border-color var(--transition-selection), color var(--transition-selection)",
        ...style,
      }}
      {...rest}
    >
      {children}
    </button>
  );
}
