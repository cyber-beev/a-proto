import type { CSSProperties, ReactNode } from "react";

/**
 * One region in the focus-map selector. Despite the name it is not pill-shaped —
 * it uses --radius-control like every other control.
 *
 * @startingPoint section="Navigation" subtitle="Region selector, selected and idle" viewport="700x150"
 */
export interface RegionPillProps {
  active?: boolean;
  /** sm is the compact-layout variant: narrower padding, 44px min height. */
  size?: "md" | "sm";
  children?: ReactNode;
  onClick?: () => void;
  style?: CSSProperties;
}

export function RegionPill(props: RegionPillProps): JSX.Element;
