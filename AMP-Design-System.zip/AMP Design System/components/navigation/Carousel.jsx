import React from "react";
import { Icon } from "../display/Icon.jsx";

/**
 * Horizontal carousel for a short set of cards. It shows whole slides only:
 * it works out how many fit at `minSlide`, sizes them to fill those slots, and
 * stops paging when the last slide is fully in frame — so the final step always
 * lands a complete card rather than an index.
 *
 * Arrows are the only affordance and they are context-aware: each is disabled
 * when there is nothing further that way. Drag works too, via pointer events,
 * with damping past either end.
 */
export function Carousel({ children, minSlide = 200, maxSlide = 248, gap = 20, style }) {
  const slides = React.Children.toArray(children);
  const n = slides.length;
  const wrapRef = React.useRef(null);
  const [w, setW] = React.useState(0);
  const [i, setI] = React.useState(0);
  const [drag, setDrag] = React.useState(0);
  const dragRef = React.useRef(0);
  const gesture = React.useRef(null);

  React.useEffect(() => {
    const el = wrapRef.current;
    if (!el) return undefined;
    setW(el.clientWidth);
    if (typeof ResizeObserver === "undefined") return undefined;
    const ro = new ResizeObserver((entries) => setW(entries[0].contentRect.width));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const track = w || minSlide;
  const perView = Math.max(1, Math.min(n, Math.floor((track + gap) / (minSlide + gap))));
  // maxSlide wins over minSlide: a caller that derives maxSlide from viewport
  // height needs the cap respected, or a tall card overflows a short section.
  const floorW = Math.min(minSlide, maxSlide);
  const slideW = Math.min(maxSlide, Math.max(floorW, Math.floor((track - (perView - 1) * gap) / perView)));
  const step = slideW + gap;
  const maxI = Math.max(0, n - perView);
  const at = Math.min(i, maxI);

  const onDown = (e) => {
    if (maxI === 0) return;
    gesture.current = { x: e.clientX };
    dragRef.current = 0;
    if (e.currentTarget.setPointerCapture) e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onMove = (e) => {
    if (!gesture.current) return;
    let d = (e.clientX - gesture.current.x) / step;
    if ((at === 0 && d > 0) || (at === maxI && d < 0)) d *= 0.35;
    dragRef.current = d;
    setDrag(d);
  };
  const onUp = () => {
    if (!gesture.current) return;
    gesture.current = null;
    const d = dragRef.current;
    dragRef.current = 0;
    if (d < -0.18 && at < maxI) setI(at + 1);
    else if (d > 0.18 && at > 0) setI(at - 1);
    setDrag(0);
  };

  const arrow = (dir) => {
    const to = at + dir;
    const off = to < 0 || to > maxI;
    return (
      <button
        type="button"
        onClick={() => !off && setI(to)}
        disabled={off}
        aria-label={dir < 0 ? "Previous" : "Next"}
        style={{
          width: "var(--tap-target)",
          height: "var(--tap-target)",
          display: "grid",
          placeItems: "center",
          border: 0,
          background: "transparent",
          color: off ? "var(--border-rule)" : "var(--accent)",
          opacity: off ? 0.45 : 1,
          cursor: off ? "default" : "pointer",
          transition: "opacity var(--transition-hover), color var(--transition-hover)",
        }}
      >
        <Icon shape={dir < 0 ? "chevronLeft" : "chevronRight"} size={16} />
      </button>
    );
  };

  return (
    <div style={{ display: "grid", gap: 14, width: "100%", minWidth: 0, ...style }}>
      <div
        ref={wrapRef}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
        style={{ overflow: "hidden", cursor: maxI ? "grab" : "default", touchAction: "pan-y" }}
      >
        <div
          style={{
            display: "flex",
            gap,
            transform: `translateX(${(-at + drag) * step}px)`,
            transition: drag ? "none" : "transform var(--duration-carousel) var(--ease-out-quint)",
            willChange: "transform",
          }}
        >
          {slides.map((child, idx) => (
            <div
              key={idx}
              style={{
                flex: `0 0 ${slideW}px`,
                display: "flex",
                opacity: idx >= at && idx < at + perView ? 1 : 0.5,
                transition: "opacity var(--duration-carousel) var(--ease-out-quint)",
              }}
            >
              {child}
            </div>
          ))}
        </div>
      </div>
      {maxI > 0 && (
        <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
          {arrow(-1)}
          {arrow(1)}
        </div>
      )}
    </div>
  );
}
