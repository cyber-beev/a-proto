One-line: pages a short row of cards when they stop fitting — arrows only, no dots.

```jsx
<Carousel minSlide={200} maxSlide={248}>
  {founders.map((p) => <FounderCard key={p.name} {...p} width="100%" />)}
</Carousel>
```

Notes
- It stops at the last **slide**, not the last index: if two cards are visible, one step right brings the third fully in and Next disables. Paging by index leaves a step into empty space.
- Arrows hide entirely when everything fits, so a static row shows no controls.
- Don't add dots. Bars were tried and removed; the arrows say which way you can go, which dots don't.
- Over-drag is damped rather than blocked, and a release past either end settles back instead of stranding the track.
