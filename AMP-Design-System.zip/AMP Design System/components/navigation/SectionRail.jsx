import React from "react";

/**
 * The fixed right-edge indicator: one 18px bar per section, plus a dot for the
 * footer stop. It is 18px wide and lives in the viewport's right margin — give
 * the paged content its own right lane (--rail-lane) so nothing crowds it.
 */
export function SectionRail({ count, active = 0, hasFooter = true, onGo, style, ...rest }) {
  const stops = [];
  for (let i = 0; i < count; i += 1) stops.push(i);
  return (
    <nav
      aria-label="Section navigation"
      style={{
        display: "grid",
        justifyItems: "center",
        alignContent: "center",
        gap: 0,
        width: "var(--rail-width)",
        ...style,
      }}
      {...rest}
    >
      {stops.map((i) => (
        <button
          key={i}
          type="button"
          aria-label={`Go to section ${i + 1}`}
          aria-current={active === i ? "true" : undefined}
          onClick={() => onGo && onGo(i)}
          style={{
            width: 30,
            height: 23,
            display: "grid",
            placeItems: "center",
            border: 0,
            background: "none",
            padding: 0,
            cursor: "pointer",
          }}
        >
          <span
            style={{
              display: "block",
              width: 18,
              height: 3,
              borderRadius: 1.5,
              background: active === i ? "var(--rail-active)" : "var(--rail-inactive)",
              transition: "background var(--transition-selection)",
            }}
          />
        </button>
      ))}
      {hasFooter && (
        <button
          type="button"
          aria-label="Go to footer"
          aria-current={active === count ? "true" : undefined}
          onClick={() => onGo && onGo(count)}
          style={{
            width: 30,
            height: 23,
            display: "grid",
            placeItems: "center",
            border: 0,
            background: "none",
            padding: 0,
            cursor: "pointer",
          }}
        >
          <span
            style={{
              display: "block",
              width: 5,
              height: 5,
              borderRadius: "50%",
              background: active === count ? "var(--rail-active)" : "var(--rail-inactive)",
              transition: "background var(--transition-selection)",
            }}
          />
        </button>
      )}
    </nav>
  );
}
