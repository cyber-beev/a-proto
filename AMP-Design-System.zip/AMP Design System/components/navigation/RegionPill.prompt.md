One-line: the Africa / LATAM / South Asia / Middle East selector above the focus map.

```jsx
{regions.map((r, i) => (
  <RegionPill key={r} active={i === active} onClick={() => setActive(i)}>{r}</RegionPill>
))}
```

Notes
- Selected is an accent fill with ink text. Idle is transparent with a rule border.
- Use `size="sm"` in the compact layout, where four of these share one row and need a 44px tap height.
- It transitions on `--transition-selection` (320ms), not `--transition-hover` (200ms): becoming the active region is a selection settling, and the longer curve is deliberate there.
