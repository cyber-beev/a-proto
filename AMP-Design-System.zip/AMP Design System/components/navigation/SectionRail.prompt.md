One-line: the fixed bars down the right edge that show which section of a page you're on.

```jsx
<SectionRail count={3} active={index} onGo={goTo}
  style={{ position: "fixed", right: 0, top: 0, height: "100%", zIndex: 15 }} />
```

Notes
- Bars sit on a 23px pitch so the stack reads as one group; the tap target stays 30px wide.
- The footer gets a dot, not a bar — it is a partial stop, not a full section.
- Because the rail is fixed in the right margin, the paged content needs `padding-right: var(--rail-lane)`. Put that on the pager, not on each section, so every section and the footer shift together.
