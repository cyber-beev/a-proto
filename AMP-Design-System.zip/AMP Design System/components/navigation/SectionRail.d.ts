import type { CSSProperties } from "react";

/** Fixed right-edge progress indicator for the one-section-per-swipe pager. */
export interface SectionRailProps {
  /** Number of full-height sections on the page (excluding the footer stop). */
  count: number;
  /** 0-based index; pass `count` itself when the footer stop is active. */
  active?: number;
  hasFooter?: boolean;
  onGo?: (index: number) => void;
  style?: CSSProperties;
}

export function SectionRail(props: SectionRailProps): JSX.Element;
