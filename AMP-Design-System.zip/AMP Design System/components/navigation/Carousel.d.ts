import type { CSSProperties, ReactNode } from "react";

/**
 * Whole-slide carousel with context-aware arrows. Used for the founders row
 * once three cards stop fitting side by side.
 *
 * @startingPoint section="Navigation" subtitle="Whole-slide carousel with arrows" viewport="700x400"
 */
export interface CarouselProps {
  /** One child per slide. */
  children?: ReactNode;
  /** Smallest readable slide width; decides how many fit per view. */
  minSlide?: number;
  /** Largest a slide may grow to when there is spare room. */
  maxSlide?: number;
  gap?: number;
  style?: CSSProperties;
}

export function Carousel(props: CarouselProps): JSX.Element;
