import type { CSSProperties, ReactNode } from "react";

/** Header page link. Active state is accent + weight 700, never an underline. */
export interface NavLinkProps {
  active?: boolean;
  children?: ReactNode;
  onClick?: () => void;
  style?: CSSProperties;
}

export function NavLink(props: NavLinkProps): JSX.Element;
