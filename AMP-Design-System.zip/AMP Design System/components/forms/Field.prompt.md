One-line: the proposal form's only control — a label-above-input pair that works for both single-line and multi-line entry.

```jsx
<Field label="Name" name="name" required />
<Field label="Email" type="email" name="email" />
<Field label="About the proposal" as="textarea" rows={5} />
```

Notes
- The control is 16px, not the 15px used elsewhere: anything smaller makes iOS Safari zoom on focus.
- `width: 100%` + `box-sizing: border-box` + `min-width: 0` are load-bearing. Without them the control sizes to its intrinsic width and overflows its grid column — this was a real bug on both layouts.
- Pair two fields with `grid-template-columns: minmax(0, 1fr) minmax(0, 1fr)`; plain `1fr 1fr` will not let them shrink.
