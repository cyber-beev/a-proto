import React from "react";

/** Label + control. Renders an input or a textarea; same skin either way. */
export function Field({ label, as = "input", rows = 4, style, ...rest }) {
  const Control = as === "textarea" ? "textarea" : "input";
  return (
    <label
      style={{
        display: "grid",
        gap: 8,
        minWidth: 0,
        fontSize: "var(--text-eyebrow-size)",
        fontWeight: "var(--weight-medium)",
        letterSpacing: "var(--text-eyebrow-tracking)",
        textTransform: "uppercase",
        color: "var(--text-soft)",
        ...style,
      }}
    >
      {label}
      <Control
        rows={as === "textarea" ? rows : undefined}
        style={{
          width: "100%",
          boxSizing: "border-box",
          minWidth: 0,
          maxWidth: "100%",
          padding: "clamp(9px, 1.5vh, 12px) 12px",
          border: "1px solid var(--border-rule)",
          borderRadius: "var(--radius-control)",
          background: "var(--surface-field)",
          fontFamily: "inherit",
          fontSize: "var(--text-ui-size-mobile-min)",
          fontWeight: "var(--weight-regular)",
          letterSpacing: "normal",
          textTransform: "none",
          color: "var(--text-strong)",
          resize: as === "textarea" ? "vertical" : undefined,
        }}
        {...rest}
      />
    </label>
  );
}
