import type { CSSProperties } from "react";

/**
 * A labelled text input or textarea — the only form control on the site.
 *
 * @startingPoint section="Forms" subtitle="Labelled input and textarea" viewport="700x260"
 */
export interface FieldProps {
  /** Rendered as an uppercase eyebrow above the control. */
  label: string;
  as?: "input" | "textarea";
  rows?: number;
  type?: string;
  name?: string;
  value?: string;
  placeholder?: string;
  required?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  style?: CSSProperties;
}

export function Field(props: FieldProps): JSX.Element;
