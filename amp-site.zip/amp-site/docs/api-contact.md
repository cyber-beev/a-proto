# API routes

`contact.ts` is the only hand-written endpoint.

Keystatic's routes are injected by its Astro integration and must **not** be
duplicated here — doing so produces a router collision warning and, in a later
Astro version, a hard error:

- `/keystatic/[...params]` — the admin UI (a React app, `client:only="react"`)
- `/api/keystatic/[...params]` — its API

The admin UI is exposed publicly at `/admin` by a Vercel rewrite; in local
development it is served at its real path, `http://localhost:4321/keystatic/`.
