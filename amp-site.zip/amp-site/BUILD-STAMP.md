# Build stamp

export: 2026-09-17 (pass 5 — E14, one blur, no tint)

## Changed in this export
- src/styles/global.css
  - Footer frost is suppressed while the menu is open, so the section above the
    footer is no longer blurred twice (`!important`, because pager.ts writes
    those values inline).
  - `.nav-frost` and `.sheet` carry NO tint — they are click targets only. The
    grey was the footer frost's 0.22 stacking with the nav frost's 0.06.
  - Only `.track` is blurred now (8px). Blurring the fixed `.matrix` and
    `.gradients` layers was what put the dark rounded frame around the page:
    a filter on a full-viewport fixed element fades its own edges inward.
    `.track` is inside `.viewport` (overflow: hidden), so its soft edge clips.

## Pass 4 (E13)
Menu blur moved off `backdrop-filter` — `.nav-frost` was only ever rendering
its tint.

## Pass 3 (E9–E12)
hero CTA grid stretch; footer full-bleed (rail lane off `.track`); matrix no
longer pauses between sections; pulse origin ignores mid-fold rects.

## Pass 2 (E1–E8) + 2b/2c
pulse handover; AMP sweep suspended under the region map; footer frost blur
ramp; email hover/underline + duplicate regions line; intro wipe and nav-logo
reveal; hero CTA destination; `Origin` type; `.sheet` opaque fill above header.

## Pass 1
A2–A5 header, A6+A9 footer, A7 gradients, A8 rail, A10 matrix anchor,
A1+A12 nav fold state machine.

## Open
- contentScale 0.985 while the menu is open (prototype `NAVCFG.contentScale`).
  The pager writes `transform` inline on `.track` every frame, so a CSS scale
  there is overridden — needs folding into the pager's transform string.
- B6 founders-row measurement on resize
- wheel threshold tuning (A9)

## Testing notes
The intro plays once per session. Clear sessionStorage['amp-intro'] or open a
new tab to replay it.
