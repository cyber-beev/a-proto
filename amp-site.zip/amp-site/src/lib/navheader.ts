/**
 * Spec 5 — the nav header state machine. Three states, one source of truth on
 * <html data-nav>:
 *
 *   up      first section of a page — nav visible, hamburger inert
 *   folded  section 2+ closed      — nav folded away to the right, hamburger drawn
 *   open    section 2+ opened      — nav back, hamburger is an X, page frosted
 *
 * The timings and per-item offsets live in CSS (global.css), keyed off this
 * attribute and the --in-lead / --out-lead / --nav-gap variables the header
 * writes per item: the fold is a staggered transition, not a JS animation, so
 * a second toggle mid-flight retargets instead of restarting.
 *
 * On compact viewports the nav does not fold — it is replaced by the full
 * panel (.sheet), which this module opens with the same burger.
 */
import { bus } from './site';

export function initNavHeader() {
  const links = Array.from(document.querySelectorAll<HTMLAnchorElement>('.nav__link'));
  const burger = document.querySelector<HTMLButtonElement>('[data-burger]');
  const frost = document.querySelector<HTMLElement>('[data-nav-frost]');
  const sheet = document.querySelector<HTMLElement>('[data-sheet]');
  if (!links.length && !burger) return;

  const firstSection = document.querySelector<HTMLElement>('[data-section]')?.dataset.section ?? '';
  const mq = matchMedia('(max-width: 768px)');
  const compact = () => mq.matches;

  let folded = (document.documentElement.dataset.activeSection ?? firstSection) !== firstSection;
  let open = false;

  const paint = () => {
    document.documentElement.dataset.nav = open ? 'open' : folded ? 'folded' : 'up';
    // Folded-away links leave the tab order and the a11y tree; on compact they
    // are display:none and the panel carries navigation instead.
    const hidden = (folded && !open) || compact();
    links.forEach((a) => {
      a.setAttribute('aria-hidden', String(hidden));
      a.tabIndex = hidden ? -1 : 0;
    });
    if (burger) {
      burger.setAttribute('aria-expanded', String(open));
      burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    }
    if (sheet) sheet.dataset.open = String(open && compact());
    document.body.dataset.menuOpen = String(open);
    // The matrix freezes while the menu is open and re-samples the pulse
    // origin, which moves to the hamburger once the nav has folded.
    bus.emit('amp:menu', open);
  };

  const setOpen = (v: boolean) => { open = v; paint(); };

  burger?.addEventListener('click', () => setOpen(!open));
  frost?.addEventListener('click', () => setOpen(false));
  sheet?.addEventListener('click', (e) => { if ((e.target as HTMLElement).closest('a')) setOpen(false); });
  links.forEach((a) => a.addEventListener('click', () => setOpen(false)));
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && open) { setOpen(false); burger?.focus(); }
  });

  // Paging folds the nav and closes an open menu.
  window.addEventListener('amp:section', (e) => {
    folded = ((e as CustomEvent<string>).detail || '') !== firstSection;
    open = false;
    paint();
  });
  mq.addEventListener?.('change', paint);

  paint();
}
