/**
 * Typed access to the page content singletons.
 *
 * `getEntry('pages', 'home')` returns the whole discriminated union, because
 * Astro cannot narrow on a literal id at the type level. This wrapper does the
 * narrowing at runtime — verifying the file's `page` field matches the id it
 * was loaded from — and returns the precise member, so pages get real types
 * instead of a four-way union.
 */
import { getEntry, type CollectionEntry } from 'astro:content';

export type PageId = 'home' | 'about' | 'team' | 'contact';
type PageData = CollectionEntry<'pages'>['data'];
export type Page<T extends PageId> = Extract<PageData, { page: T }>;

export async function getPage<T extends PageId>(id: T): Promise<Page<T>> {
  const entry = await getEntry('pages', id);
  if (!entry) throw new Error(`Missing src/content/pages/${id}.json`);
  const data = entry.data as Page<T>;
  if (data.page !== id) {
    throw new Error(`src/content/pages/${id}.json declares page "${data.page}" — the file name and the "page" field must agree.`);
  }
  return data;
}
