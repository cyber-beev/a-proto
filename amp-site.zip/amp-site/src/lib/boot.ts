/**
 * Client entry point. One module, imported once from Base.astro. Everything
 * here is progressive enhancement: the page is complete, navigable and
 * readable before any of it runs, and with JS disabled the <noscript> styles
 * in Base.astro turn the pager back into an ordinary scrolling document.
 */
import { initTheme } from './theme';
import { initPager } from './pager';
import { initMatrix, type MatrixHandle } from './matrix';
import { initIntro } from './intro';
import { initCycles } from './cycles';
import { initNavHeader } from './navheader';
import { initGradients } from './gradients';
import { initForm } from './form';
import { initCarousels } from './carousel';

const start = () => {
  initTheme();

  const canvas = document.querySelector<HTMLCanvasElement>('[data-matrix]');
  const matrix: MatrixHandle | null = canvas ? initMatrix(canvas, canvas.dataset.logo || null) : null;

  // Focus Regions: the active region is projected into the matrix as a denser
  // dot field, and the word beside it changes with the buttons. The map is not
  // in the section — the matrix carries it.
  const group = document.querySelector<HTMLElement>('[data-region-group]');
  const title = document.querySelector<HTMLElement>('[data-region-title]');
  if (group && matrix) {
    let focusLive = false;
    const applyRegion = (id: string) => {
      matrix.setRegion(id || null);
      const btn = id ? group.querySelector<HTMLElement>(`[data-cycle-value="${id}"]`) : null;
      if (title && btn) title.textContent = btn.textContent?.trim() ?? title.textContent;
    };
    const selectedValue = () =>
      group.querySelector<HTMLElement>('[data-cycle-option][aria-selected="true"]')?.dataset.cycleValue ??
      group.querySelector<HTMLElement>('[data-cycle-option]')?.dataset.cycleValue ?? '';

    // The cycle runs on every page load, so the projection has to be gated on
    // the section being the one on screen — otherwise the map draws under the
    // hero copy, which is not the design.
    group.addEventListener('amp:cycle', (e) => {
      if (focusLive) applyRegion((e as CustomEvent<{ value: string }>).detail.value);
    });
    window.addEventListener('amp:section', (e) => {
      focusLive = (e as CustomEvent<string>).detail === 'focus';
      if (focusLive) applyRegion(selectedValue());
      else matrix.setRegion(null);
    });
  }

  initPager();
  initNavHeader();
  initGradients();
  initCycles();
  initCarousels();
  initForm();
  initIntro();
};

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
else start();
