/**
 * Proposal form: submit, validate, toast. Progressive — the form is a real
 * <form> with a real action, so it works before this module loads and degrades
 * to a normal POST if JS fails.
 *
 * The toast never echoes user input. Rendering a submitted value back into the
 * DOM is a reflected-XSS vector; the messages come from the CMS as static
 * strings and are written with textContent, not innerHTML.
 */
import { validateProposal, LIMITS } from './contact-validation';

type State = 'idle' | 'sending' | 'success' | 'error';

function toast(host: HTMLElement, message: string, kind: 'success' | 'error') {
  const el = document.createElement('div');
  el.className = `toast${kind === 'error' ? ' toast--error' : ''}`;
  el.setAttribute('role', kind === 'error' ? 'alert' : 'status');
  const text = document.createElement('span');
  text.textContent = message;                       // never innerHTML
  const close = document.createElement('button');
  close.type = 'button';
  close.className = 'toast__close';
  close.setAttribute('aria-label', 'Dismiss notification');
  close.textContent = '\u00d7';
  el.append(text, close);
  host.append(el);
  requestAnimationFrame(() => (el.dataset.show = 'true'));
  const remove = () => { el.dataset.show = 'false'; setTimeout(() => el.remove(), 320); };
  close.addEventListener('click', remove);
  setTimeout(remove, kind === 'error' ? 9000 : 6000);
}

function setFieldError(form: HTMLFormElement, name: string, message: string) {
  const field = form.querySelector<HTMLElement>(`[data-field="${name}"]`);
  if (!field) return;
  field.dataset.invalid = message ? 'true' : 'false';
  const slot = field.querySelector<HTMLElement>('[data-error]');
  if (slot) slot.textContent = message;
  const input = field.querySelector<HTMLInputElement | HTMLTextAreaElement>('input, textarea');
  if (input) input.setAttribute('aria-invalid', message ? 'true' : 'false');
}

export function initForm() {
  const form = document.querySelector<HTMLFormElement>('form[data-proposal]');
  if (!form) return;
  const host = document.querySelector<HTMLElement>('[data-toast-host]') ?? form;
  const submit = form.querySelector<HTMLButtonElement>('[type="submit"]');
  const messages = JSON.parse(form.dataset.messages ?? '{}') as Record<string, string>;
  const fileInput = form.querySelector<HTMLInputElement>('input[type="file"]');
  const dropzone = form.querySelector<HTMLElement>('[data-dropzone]');
  const turnstile = form.querySelector<HTMLDivElement>('[data-turnstile]');

  const setState = (s: State) => {
    form.dataset.state = s;
    if (submit) { submit.disabled = s === 'sending'; submit.dataset.state = s; }
  };

  // Live file feedback: size and type are checked before the user submits.
  if (fileInput && dropzone) {
    const reflect = () => {
      const f = fileInput.files?.[0];
      const name = dropzone.querySelector('[data-file-name]');
      if (name) name.textContent = f ? `${f.name} — ${(f.size / 1024 / 1024).toFixed(2)} MB` : '';
      const tooBig = !!f && f.size > LIMITS.fileBytes;
      dropzone.dataset.invalid = String(tooBig);
      setFieldError(form, 'file', tooBig ? `Files must be 4 MB or smaller. For larger catalogues, share a link instead.` : '');
    };
    fileInput.addEventListener('change', reflect);
    for (const ev of ['dragenter', 'dragover']) dropzone.addEventListener(ev, (e) => { e.preventDefault(); dropzone.dataset.dragging = 'true'; });
    for (const ev of ['dragleave', 'drop']) dropzone.addEventListener(ev, (e) => { e.preventDefault(); dropzone.dataset.dragging = 'false'; });
    dropzone.addEventListener('drop', (e) => {
      const dt = (e as DragEvent).dataTransfer;
      if (dt?.files?.length && fileInput) { fileInput.files = dt.files; reflect(); }
    });
    dropzone.addEventListener('click', () => fileInput.click());
    dropzone.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); } });
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const file = fileInput?.files?.[0];
    // Run the SAME validator the server runs, so the visitor gets field-level
    // feedback instead of a round trip. The server re-runs it regardless.
    const result = validateProposal({
      name: fd.get('name'), email: fd.get('email'), phone: fd.get('phone'),
      message: fd.get('message'), link: fd.get('link'), company: fd.get('company'),
      fileName: file?.name, fileSize: file?.size,
    });
    for (const f of ['name', 'email', 'phone', 'message', 'link', 'file']) setFieldError(form, f, '');
    if (!result.ok) {
      for (const i of result.issues) setFieldError(form, i.field, i.message);
      const first = form.querySelector<HTMLElement>(`[data-field="${result.issues[0].field}"] input, [data-field="${result.issues[0].field}"] textarea`);
      first?.focus();
      setState('error');
      return;
    }

    setState('sending');
    try {
      const body = new FormData();
      for (const [k, v] of fd.entries()) if (k !== 'file' && !(v instanceof File)) body.append(k, String(v));
      if (file) body.append('file', file, file.name);
      const token = turnstile?.querySelector<HTMLInputElement>('[name="cf-turnstile-response"]')?.value;
      if (token) body.append('turnstile', token);

      const res = await fetch('/api/contact/', { method: 'POST', body });
      const json = (await res.json().catch(() => ({}))) as { ok?: boolean; issues?: { field: string; message: string }[]; error?: string };
      if (!res.ok || !json.ok) {
        for (const i of json.issues ?? []) setFieldError(form, i.field, i.message);
        setState('error');
        toast(host, json.error || messages.errorMessage || 'Something went wrong. Please try again.', 'error');
        return;
      }
      setState('success');
      toast(host, messages.successMessage || 'Thanks — your proposal has been sent.', 'success');
      form.reset();
      if (dropzone) { const n = dropzone.querySelector('[data-file-name]'); if (n) n.textContent = ''; }
    } catch {
      setState('error');
      toast(host, messages.errorMessage || 'Something went wrong. Please try again.', 'error');
    }
  });
}
