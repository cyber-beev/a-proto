/**
 * Spec 1 — the section pager. One section per gesture: sections are exactly one
 * viewport tall, and a wheel, swipe or arrow key transitions between them over
 * 800ms, with off-screen sections held `inert`.
 *
 * Ported from the approved prototype's usePager. Behaviour preserved:
 *   - the transition plays in full; an explicit animation lock swallows a
 *     mid-flight input rather than queueing it (no artificial breakAfter — the
 *     animation itself is the only gate)
 *   - wheel gestures are classified by ACCELERATION, not by per-event delta
 *   - touch commit is velocity-based as well as distance-based
 *   - per-gesture axis lock, so a second finger cannot jump the track
 *   - over-drag past either end is damped rather than hitting a wall
 *   - reduced motion caps the transition at 260ms rather than removing it —
 *     the view still has to show that it changed
 *
 * Only `transform` and `opacity` are ever written. The transform goes directly
 * on the moving element rather than into a CSS custom property on a parent,
 * which is the recalc trap the standards call out.
 *
 * Accessibility: this hijacks scrolling, so it must not trap anyone. Sections
 * are real <section> elements in the DOM with real content, off-screen ones are
 * `inert` + `aria-hidden`, the rail exposes every section as a button, and the
 * skip link jumps to the active section's content. With JS off the document is
 * a normal, scrollable page (see the <noscript> styles in Base.astro).
 */
import { PAGING, CONTENT_FADE, FOOTER_STOP, easePage, prefersReducedMotion, bus, pagerState } from './site';

const WHEEL = { sampleCap: 12, window: 4, minDelta: 4 };

/** Browsers deliver INTEGER-quantized deltas, so a decaying trackpad tail
 *  produces flat plateaus (24,24,23,23,22,22…) that read as "not decaying" and
 *  punch through any per-event threshold. Compare window averages instead. */
function windowAvg(samples: number[], size: number) {
  const n = Math.min(size, samples.length);
  if (!n) return 0;
  let sum = 0;
  for (let i = samples.length - n; i < samples.length; i++) sum += samples[i];
  return sum / n;
}
function isAccelerating(samples: number[]) {
  if (samples.length < WHEEL.window * 2) return true; // not enough evidence yet
  const recent = windowAvg(samples.slice(-WHEEL.window), WHEEL.window);
  const prior = windowAvg(samples.slice(-WHEEL.window * 2, -WHEEL.window), WHEEL.window);
  return recent >= prior * 0.92;
}

export function initPager() {
  const viewport = document.querySelector<HTMLElement>('[data-viewport]');
  const track = document.querySelector<HTMLElement>('[data-track]');
  if (!viewport || !track) return;

  const sections = Array.from(track.querySelectorAll<HTMLElement>('[data-section]'));
  if (sections.length < 2) return;
  const rail = Array.from(document.querySelectorAll<HTMLButtonElement>('[data-rail-dot]'));
  const frostEl = document.querySelector<HTMLElement>('[data-foot-frost]');
  const count = sections.length;
  const footerLast = sections[count - 1]?.dataset.section === '__footer';

  let index = 0;
  let offset = 0;                 // current translateY of the track, negative
  let animating = false;
  let heights: number[] = [];
  let starts: number[] = [];
  let total = 0;
  let vh = window.innerHeight;

  /* ── measurement ──────────────────────────────────────────────── */
  const measure = () => {
    vh = viewport.clientHeight || window.innerHeight;
    // One source of truth for "a viewport", written to --vh so the CSS height
    // and the JS offsets can never disagree on iOS with the dynamic toolbar.
    document.documentElement.style.setProperty('--vh', `${vh / 100}px`);
    heights = sections.map((s) => s.offsetHeight || vh);
    starts = [];
    let acc = 0;
    for (const h of heights) { starts.push(acc); acc += h; }
    total = acc;
    // Each stop's position in progress space (viewport units). The footer stop
    // is FRACTIONAL: it is only the footer's own height past the last section.
    pagerState.stops = sections.map((_, i) => -offsetFor(i) / vh);
    apply(offsetFor(index), false);
    fade(offsetFor(index));
  };
  /** The last page is content-sized (the footer), so it cannot scroll past the
   *  point where its bottom meets the viewport bottom. */
  const offsetFor = (i: number) => -Math.min(starts[i], Math.max(0, total - vh));

  /* ── painting ─────────────────────────────────────────────────── */
  const apply = (y: number, animate: boolean) => {
    offset = y;
    pagerState.progress = -y / vh;
    if (animate) {
      track!.style.transition = `transform ${duration()}ms var(--ease-out-quint)`;
    } else {
      track!.style.transition = 'none';
    }
    track!.style.transform = `translate3d(0, ${y}px, 0)`;
    frost(y);
  };

  /** The footer is revealed by a partial move, so the section above it is still
   *  mostly on screen. Frosting that leftover body demotes it, and the frost
   *  shrinks as the footer comes in so it never covers the footer itself. */
  const frost = (y: number) => {
    if (!frostEl || !footerLast || count < 2) return;
    const from = -offsetFor(count - 2);
    const to = -offsetFor(count - 1);
    const span = to - from;
    const t = span > 0 ? Math.max(0, Math.min(1, (-y - from) / span)) : 0;
    frostEl.style.opacity = String(t);
    // The blur is what demotes the leftover body — a tint alone just greys it.
    // Ramped with the reveal so it arrives with the footer.
    const blur = (t * FOOTER_STOP.frostBlur).toFixed(2);
    frostEl.style.setProperty('backdrop-filter', `blur(${blur}px)`);
    frostEl.style.setProperty('-webkit-backdrop-filter', `blur(${blur}px)`);
    frostEl.style.height = `${Math.max(0, vh - t * (heights[count - 1] || 0))}px`;
    frostEl.style.pointerEvents = t > 0.02 && t < 0.98 ? 'auto' : 'none';
  };

  /** Content cross-fade + drift, driven by distance from the active section.
   *  Written per frame during a transition, once at rest. */
  const fade = (y: number) => {
    const { sharpness, lift, floor } = CONTENT_FADE;
    for (let i = 0; i < count; i++) {
      const inner = sections[i].querySelector<HTMLElement>('[data-section-inner]');
      if (!inner) continue;
      const d = (-y - starts[i]) / vh;
      if (Math.abs(d) > 1.4) { inner.style.opacity = String(floor); continue; }
      const opacity = Math.max(floor, Math.pow(Math.max(0, 1 - Math.abs(d)), sharpness));
      const driftPx = Math.max(-1, Math.min(1, d)) * lift;
      inner.style.opacity = String(Math.max(0, Math.min(1, opacity)));
      inner.style.transform = `translate3d(0, ${driftPx}px, 0)`;
    }
  };

  const duration = () => (prefersReducedMotion() ? PAGING.reducedDuration : PAGING.duration);

  /* ── state ────────────────────────────────────────────────────── */
  const setActive = (i: number) => {
    index = i;
    sections.forEach((s, n) => {
      const on = n === i;
      // inert keeps off-screen sections out of the tab order and the a11y tree
      if (on) s.removeAttribute('inert'); else s.setAttribute('inert', '');
      s.setAttribute('aria-hidden', String(!on));
    });
    rail.forEach((d, n) => d.setAttribute('aria-current', String(n === i)));
    const id = sections[i].dataset.section ?? '';
    document.documentElement.dataset.activeSection = id;
    window.dispatchEvent(new CustomEvent('amp:section', { detail: id }));
    bus.emit('amp:section', id);
    // Keep the URL honest without adding history entries for every gesture.
    const hash = id && id !== 'hero' ? `#${id}` : ' ';
    if (history.replaceState) history.replaceState(null, '', hash === ' ' ? location.pathname + location.search : location.pathname + location.search + hash);
  };

  const goTo = (i: number, instant = false) => {
    const target = Math.max(0, Math.min(count - 1, i));
    if (animating || target === index) { if (instant) { apply(offsetFor(target), false); setActive(target); } return; }
    const to = offsetFor(target);
    setActive(target);
    if (instant || duration() <= 1) { apply(to, false); fade(to); return; }
    animating = true;
    bus.emit('amp:transition', true);
    const from = offset;
    const t0 = performance.now();
    const dur = duration();
    const step = (now: number) => {
      const t = Math.min(1, (now - t0) / dur);
      const y = from + (to - from) * easePage(t);
      track!.style.transition = 'none';
      track!.style.transform = `translate3d(0, ${y}px, 0)`;
      offset = y;
      pagerState.progress = -y / vh;
      fade(y);
      frost(y);
      if (t < 1) requestAnimationFrame(step);
      else { animating = false; bus.emit('amp:transition', false); }
    };
    requestAnimationFrame(step);
  };

  const next = () => goTo(index + 1);
  const prev = () => goTo(index - 1);

  /* ── wheel ────────────────────────────────────────────────────── */
  const samples: number[] = [];
  let wheelTimer = 0;
  viewport.addEventListener('wheel', (e) => {
    e.preventDefault();
    if (animating) return;                        // the lock swallows mid-flight input
    // Axis lock: a mostly-horizontal wheel/trackpad gesture is not a page turn.
    if (Math.abs(e.deltaY) < Math.abs(e.deltaX)) return;
    const d = Math.abs(e.deltaY);
    if (d < WHEEL.minDelta) return;
    samples.push(d);
    if (samples.length > WHEEL.sampleCap) samples.shift();
    clearTimeout(wheelTimer);
    wheelTimer = window.setTimeout(() => samples.length = 0, 180);
    if (!isAccelerating(samples)) return;         // momentum tail, rejected on merit
    samples.length = 0;
    if (e.deltaY > 0) next(); else prev();
  }, { passive: false });

  /* ── touch ────────────────────────────────────────────────────── */
  let tStart = 0, tY0 = 0, tX0 = 0, tAxis: 'v' | 'h' | null = null, tDragging = false, tLast = 0;
  viewport.addEventListener('touchstart', (e) => {
    if (e.touches.length !== 1) { tDragging = false; return; }   // multi-touch: abort, do not jump
    tDragging = true; tAxis = null;
    tY0 = tLast = e.touches[0].clientY; tX0 = e.touches[0].clientX; tStart = performance.now();
  }, { passive: true });

  viewport.addEventListener('touchmove', (e) => {
    if (!tDragging || animating) return;
    const y = e.touches[0].clientY, x = e.touches[0].clientX;
    if (!tAxis) {
      const dy = Math.abs(y - tY0), dx = Math.abs(x - tX0);
      if (dy < 6 && dx < 6) return;
      tAxis = dy > dx ? 'v' : 'h';                 // per-gesture axis lock
    }
    if (tAxis !== 'v') return;
    e.preventDefault();
    tLast = y;
    let dy = y - tY0;
    // Damped past either end rather than hitting a wall.
    if ((index === 0 && dy > 0) || (index === count - 1 && dy < 0)) dy *= PAGING.rubberband;
    track!.style.transition = 'none';
    track!.style.transform = `translate3d(0, ${offsetFor(index) + dy}px, 0)`;
    pagerState.progress = -(offsetFor(index) + dy) / vh;
    frost(offsetFor(index) + dy);
  }, { passive: false });

  const endTouch = () => {
    if (!tDragging || tAxis !== 'v') { tDragging = false; return; }
    tDragging = false;
    const dy = tLast - tY0;
    const dt = Math.max(1, performance.now() - tStart);
    const vel = Math.abs(dy) / dt;                 // px/ms
    // Velocity-based dismissal, not distance-based: either one commits.
    if (Math.abs(dy) > PAGING.touchDist || vel > PAGING.touchVel) {
      if (dy < 0) next(); else prev();
      return;
    }
    goTo(index);                                   // spring back
  };
  viewport.addEventListener('touchend', endTouch);
  viewport.addEventListener('touchcancel', endTouch);

  /* ── keyboard ─────────────────────────────────────────────────── */
  document.addEventListener('keydown', (e) => {
    const el = document.activeElement;
    // Never hijack keys from a form field, a dialog, or an editing surface.
    if (el instanceof HTMLElement && (/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName) || el.isContentEditable)) return;
    if (el instanceof HTMLElement && el.closest('[data-cycle]') && /^Arrow/.test(e.key)) return; // cycles own arrows
    const map: Record<string, number> = {
      ArrowDown: 1, PageDown: 1, ' ': 1, ArrowUp: -1, PageUp: -1,
    };
    if (e.key in map) { e.preventDefault(); goTo(index + map[e.key]); }
    else if (e.key === 'Home') { e.preventDefault(); goTo(0); }
    else if (e.key === 'End') { e.preventDefault(); goTo(count - 1); }
  });

  /* ── rail ─────────────────────────────────────────────────────── */
  rail.forEach((dot, n) => dot.addEventListener('click', () => goTo(n)));
  // Clicking the frosted leftover body commits to the footer.
  frostEl?.addEventListener('click', () => goTo(count - 1));

  /* ── inbound hash ───────────────────────────────────────────────
   * /#focus and /#contact-form arrive here from the legacy redirects, so a
   * fragment has to open the matching section rather than the hero. A plain
   * anchor cannot do this: the viewport is position:fixed with overflow:hidden.
   */
  const fromHash = () => {
    const id = decodeURIComponent(location.hash.replace('#', ''));
    if (!id) return 0;
    const i = sections.findIndex((s) => s.dataset.section === id);
    return i > 0 ? i : 0;
  };
  document.querySelectorAll<HTMLAnchorElement>('a[href^="#"]').forEach((a) => {
    a.addEventListener('click', (e) => {
      const id = decodeURIComponent(a.getAttribute('href')!.slice(1));
      const i = sections.findIndex((s) => s.dataset.section === id);
      if (i >= 0) { e.preventDefault(); goTo(i); history.replaceState(null, '', `#${id}`); }
    });
  });
  window.addEventListener('hashchange', () => goTo(fromHash()));

  /* ── boot ─────────────────────────────────────────────────────── */
  const ro = new ResizeObserver(() => measure());
  ro.observe(viewport);
  window.addEventListener('resize', measure);
  window.visualViewport?.addEventListener('resize', measure);
  window.addEventListener('load', measure);
  measure();
  setActive(fromHash());
  apply(offsetFor(index), false);
  fade(offsetFor(index));
  if (document.fonts?.ready) document.fonts.ready.then(measure);

  // Sections can change height when images or the founder carousel settle.
  for (const img of Array.from(document.images)) {
    if (!img.complete) img.addEventListener('load', measure, { once: true });
  }
}
