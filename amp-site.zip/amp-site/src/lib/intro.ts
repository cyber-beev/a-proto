/**
 * Load intro: the mark is wiped in left to right, holds, then flies into the
 * nav slot. The wipe is a clip-path inset animation on the img itself — one
 * compositable property, no mask image, no second element to keep in sync.
 * The flight is a measured FLIP onto the real nav logo, so the handover lands
 * on the same pixels and reads as one continuous object.
 *
 * Skipped entirely on bfcache restore and for reduced-motion visitors, who get
 * a 240ms fade instead of the sequence.
 */
import { INTRO, prefersReducedMotion } from './site';

export function initIntro() {
  const overlay = document.querySelector<HTMLElement>('[data-intro]');
  if (!overlay) return;
  // The nav logo starts hidden so the intro can hand over on the same pixels.
  // EVERY exit has to reveal it — a skipped intro (reduced motion, a reload in
  // the same session, a missing target) otherwise leaves the nav with no mark.
  const reveal = () => {
    const el = document.querySelector<HTMLElement>('[data-nav-logo]');
    if (el) el.style.visibility = 'visible';
  };
  const done = () => { reveal(); overlay.dataset.phase = 'done'; overlay.remove(); };

  if (prefersReducedMotion()) { setTimeout(done, 240); return; }
  // Session-only: a reload or a back-navigation should not replay the intro.
  if (sessionStorage.getItem('amp-intro') === '1') { done(); return; }
  sessionStorage.setItem('amp-intro', '1');

  const logo = overlay.querySelector<HTMLImageElement>('[data-intro-logo]');
  const target = document.querySelector<HTMLElement>('[data-nav-logo]');
  if (!logo) { done(); return; }

  // The element ships as data-phase="covered" (clip-path inset(0 100% 0 0)).
  // Flipping to "wipe" in the same frame gives the browser no old value to
  // transition FROM, so the mark just appears. Wait for the image to be
  // decoded, then set the phase on the next frame so the wipe actually plays.
  const begin = () => requestAnimationFrame(() => {
    logo.dataset.phase = 'wipe';
    window.setTimeout(() => {
      logo.dataset.phase = 'fly';
      if (!target) { done(); return; }
      const a = logo.getBoundingClientRect();
      const b = target.getBoundingClientRect();
      // The mask is dropped for the flight: masking a transform-scaled element
      // resamples it every frame, which is where residual softness came from.
      logo.style.clipPath = 'none';
      logo.style.transformOrigin = 'top left';
      logo.style.transform = `translate(${b.left - a.left}px, ${b.top - a.top}px) scale(${b.width / a.width})`;
      // The nav logo is hidden, not unmounted: the intro measures its real rect
      // and hands over on the same pixels, so there is no pop.
      target.style.visibility = 'visible';
      setTimeout(done, INTRO.fly);
    }, INTRO.wipe + INTRO.hold);
  });

  if (logo.complete) begin();
  else logo.addEventListener('load', begin, { once: true });
  // A decode that never resolves must not leave the page behind a black cover.
  window.setTimeout(done, INTRO.wipe + INTRO.hold + INTRO.fly + 1200);
}
