/**
 * The founders carousel. Generalised from the Team section so other short card
 * rows can page the same way.
 *
 * Interruptibility: slides are CSS transitions, not keyframes, so a rapid
 * second input retargets rather than restarting. Dismissal is velocity-based as
 * well as distance-based, pointer capture is taken on drag start, and
 * multi-touch is guarded by a per-gesture axis lock so a second finger cannot
 * jump the track.
 */
export function initCarousels() {
  for (const root of Array.from(document.querySelectorAll<HTMLElement>('[data-carousel]'))) {
    const track = root.querySelector<HTMLElement>('[data-carousel-track]');
    const slides = root.querySelectorAll<HTMLElement>('[data-carousel-slide]');
    if (!track || slides.length < 2) continue;
    const prev = root.querySelector<HTMLButtonElement>('[data-carousel-prev]');
    const next = root.querySelector<HTMLButtonElement>('[data-carousel-next]');

    let index = 0;
    let dragX = 0;
    let startX = 0;
    let startT = 0;
    let dragging = false;
    let axisLocked: 'x' | 'y' | null = null;
    let pointerId: number | null = null;

    const step = () => slides[0]!.offsetWidth + 20;   // slide + gap
    const maxIndex = () => Math.max(0, slides.length - Math.max(1, Math.floor(root.clientWidth / step())));
    const render = (animate = true) => {
      track!.style.transition = animate ? 'transform var(--duration-carousel) var(--ease-out-quint)' : 'none';
      track!.style.transform = `translate3d(${-index * step()}px, 0, 0)`;
      if (prev) prev.disabled = index === 0;
      if (next) next.disabled = index >= maxIndex();
    };
    const goTo = (i: number) => { index = Math.max(0, Math.min(maxIndex(), i)); render(); };

    prev?.addEventListener('click', () => goTo(index - 1));
    next?.addEventListener('click', () => goTo(index + 1));

    track.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      dragging = true; axisLocked = null; pointerId = e.pointerId;
      startX = dragX = e.clientX; startT = performance.now();
      track!.setPointerCapture(e.pointerId);
      track!.style.transition = 'none';
      track!.style.cursor = 'grabbing';
    });
    track.addEventListener('pointermove', (e) => {
      if (!dragging || e.pointerId !== pointerId) return;
      if (!axisLocked) {
        // Horizontal intent only: a vertical drag belongs to the pager.
        if (Math.abs(e.clientX - startX) < 6) return;
        axisLocked = 'x';
      }
      if (axisLocked !== 'x') return;
      dragX = e.clientX;
      let d = dragX - startX;
      if ((index === 0 && d > 0) || (index >= maxIndex() && d < 0)) d *= 0.35;  // damped past either end
      track!.style.transform = `translate3d(${-index * step() + d}px, 0, 0)`;
    });
    const end = (e: PointerEvent) => {
      if (!dragging || e.pointerId !== pointerId) return;
      dragging = false; pointerId = null;
      track!.style.cursor = '';
      const d = e.clientX - startX;
      const dt = Math.max(1, performance.now() - startT);
      const vel = Math.abs(d) / dt;
      if (Math.abs(d) > 60 || vel > 0.45) goTo(index + (d < 0 ? 1 : -1));
      else render();
    };
    track.addEventListener('pointerup', end);
    track.addEventListener('pointercancel', end);
    track.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight') { e.preventDefault(); goTo(index + 1); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); goTo(index - 1); }
    });
    track.tabIndex = 0;
    track.setAttribute('role', 'group');
    track.setAttribute('aria-label', 'Founders, scrollable');
    window.addEventListener('resize', () => render(false));
    render(false);
  }
}
