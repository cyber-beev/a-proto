/** The four pages, and the sections each contains. Mirrors the prototype's
 *  PAGES array — which declared four pages while its comment said five; the
 *  comment was stale and Focus Regions is a section of Home, not a page. */
export type NavItem = { id: string; label: string; href: string };
export const NAV: NavItem[] = [
  { id: 'home', label: 'Home', href: '/' },
  { id: 'about', label: 'About', href: '/about/' },
  { id: 'team', label: 'Team', href: '/team/' },
  { id: 'contact', label: 'Contact', href: '/contact/' },
];

export const SECTIONS: Record<string, { id: string; label: string; footer?: boolean }[]> = {
  home: [
    { id: 'hero', label: 'Hero' },
    { id: 'approach', label: 'Approach' },
    { id: 'focus', label: 'Focus Regions' },
    { id: '__footer', label: 'Footer', footer: true },
  ],
  about: [
    { id: 'what-we-do', label: 'What We Do' },
    { id: 'edge', label: 'Our Edge' },
    { id: 'who', label: 'Who We Work With' },
    { id: '__footer', label: 'Footer', footer: true },
  ],
  team: [
    { id: 'team', label: 'Team & Advisors' },
    { id: '__footer', label: 'Footer', footer: true },
  ],
  contact: [
    { id: 'contact-statement', label: 'Contact' },
    { id: 'contact-form', label: 'Submit Proposal' },
    { id: '__footer', label: 'Footer', footer: true },
  ],
};

export const ORG = {
  name: 'AMP Global',
  legalName: 'AMP Global Entertainment',
  url: 'https://ampglobalent.com',
  email: 'info@ampglobalent.com',
  description:
    'AMP Global is a music investment platform focused on high-growth markets, partnering with creators, rights holders, and local ecosystems to build long-term value.',
  logo: 'https://ampglobalent.com/images/amp-logo-dark.png',
  /** Fill in from Anna before launch — SEO-13. */
  sameAs: [] as string[],
  regions: ['Africa', 'LATAM', 'South Asia', 'Middle East'],
};
