/**
 * Shared constants. Values are the locked Spec 1 / Spec 3 numbers from the
 * approved prototype, and mirror tokens/motion.css so the two never disagree.
 */
export const PAGING = {
  duration: 800,        // ms, section transition — plays in full
  easePower: 3.2,
  touchDist: 60,        // px, touch commit distance
  touchVel: 0.45,       // px/ms, touch commit (fling) velocity
  rubberband: 0.5,      // end-overscroll resistance
  reducedDuration: 260, // ms cap under prefers-reduced-motion
};

export const MATRIX = {
  cell: 5,
  dot: 0.5,
  baseOpacity: 0.1,
  cursorRadius: 40,
  cursorStrength: 0.2,
  cursorFalloff: 2.7,
  dotGrow: 2.3,
  flashInterval: 2.5,   // s between sweeps
  sweepDuration: 2.6,   // s for a sweep to cross
  bandWidth: 300,
  flashOpacity: 0.45,
  flashBoostUnderCursor: 1.1,
  logoWidth: 0.74,      // mark width as a fraction of the viewport
  logoOpacity: 0.62,
  logoResidual: 0.3,
  logoGrow: 2.0,
  regionWidth: 0.42,
  regionGap: 60,
  regionOpacity: 0.44,
  regionGrow: 2.6,
  regionFade: 420,      // ms cross-fade between projections
  levels: 16,           // alpha buckets — one path fill per level
} satisfies Record<string, number>;

export const CYCLE_MS = 5600;
export const CYCLE_MS_FAST = 3800;   // Focus Regions: one word per option
export const CYCLE_RESUME_MS = 9000; // idle time before auto-advance resumes

/** Content cross-fade during a page transition. The outgoing section fades and
 *  counter-drifts slightly as the incoming one arrives, so a transition reads
 *  as a change of subject rather than a rigid panel slide. */
export const CONTENT_FADE = {
  sharpness: 1.9,  // higher = content disappears sooner into the move
  lift: 26,        // px of counter-drift; 0 = pure fade
  floor: 0,        // opacity never drops below this
};

/** Spec 4 — the gradient layer. All gradients live on ONE fixed layer in
 *  viewport space: a box nested in a section would be bounded by it and cut at
 *  the seam as it drifts. Each box is TWO viewports tall and centred on its
 *  stop's bottom edge, so the ellipse is drawn whole. */
export const GRADIENT = {
  standard: { colorMode: 'ground', spreadX: 60, height: 20, opacity: 0.16, midStop: 30, feather: 100 },
  footer: { colorMode: 'accent', spreadX: 75, height: 32, opacity: 0.38, midStop: 29, feather: 100 },
  fade: { enabled: true, sharpness: 2.2, drift: 64 },
};

/** The footer is sized by its CONTENT, not by a fraction of the viewport: the
 *  pager lifts the preceding section by exactly the footer's height, which is
 *  what makes the last stop a PARTIAL move. While the footer shows, the
 *  leftover section above it is frosted so the footer reads as the focus. */
export const FOOTER_STOP = { padY: 34, minVh: 18, frostTint: 0.22, frostBlur: 10 };

/** Live pager position in viewport units, shared with the gradient layer the
 *  way the prototype shared progressRef. `stops` carries each stop's progress,
 *  so the footer can sit at a FRACTIONAL index. */
export const pagerState = { progress: 0, stops: [] as number[] };

/** Spec 5 item 5 — the pulse. A ring leaves the ACTIVE NAV ITEM's rounded-rect
 *  frame (the hamburger once the nav has folded), tracing its outline as it
 *  expands rather than radiating from a point. */
export const NAV_PULSE = {
  period: 2600,   // ms per ring
  max: 140,       // px of reach
  width: 40,      // px band thickness
  strength: 0.28,
  falloff: 3.0,
  grow: 1.5,      // dot radius multiplier at the band's centre
  padX: 14,
  padY: 10,
  corner: 10,
};

export const INTRO = { wipe: 900, hold: 1000, fly: 1100 } as const;

/** out-quint, the house easing: quick to commit, long to settle. */
export const easeOutQuint = (t: number) => 1 - Math.pow(1 - t, 5);
/** The pager's own curve — easePower 3.2, per Spec 1. */
export const easePage = (t: number) => 1 - Math.pow(1 - t, PAGING.easePower);

export const prefersReducedMotion = () =>
  typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;

/** A tiny event bus so the matrix can pause during a page transition without
 *  the two modules holding references to each other. */
type Handlers = Record<string, Set<(detail: unknown) => void>>;
const handlers: Handlers = {};
export const bus = {
  on(event: string, fn: (detail: unknown) => void) {
    (handlers[event] ??= new Set()).add(fn);
    return () => handlers[event]?.delete(fn);
  },
  emit(event: string, detail?: unknown) {
    handlers[event]?.forEach((fn) => { try { fn(detail); } catch (e) { console.error(e); } });
  },
};
