/**
 * Theme. Dark is a first-class, USER-CHOSEN theme — not a system-preference
 * follow — but the system preference decides the first paint for a visitor who
 * has not chosen yet.
 *
 * The pre-paint snippet lives inline in Base.astro so the correct theme is on
 * <html> before the first frame; this module owns everything after that.
 */
const KEY = 'amp-theme';
export type Theme = 'light' | 'dark';

const read = (): Theme =>
  (document.documentElement.dataset.theme as Theme) || 'light';

export function initTheme() {
  const root = document.documentElement;
  const buttons = Array.from(document.querySelectorAll<HTMLButtonElement>('[data-theme-toggle]'));

  const sync = () => {
    const dark = read() === 'dark';
    for (const b of buttons) {
      b.setAttribute('aria-pressed', String(dark));
      b.setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode');
      b.dataset.state = dark ? 'dark' : 'light';
    }
    // The matrix reads dot colour from the theme; tell it to repaint once.
    window.dispatchEvent(new CustomEvent('amp:theme', { detail: read() }));
  };

  for (const b of buttons) {
    b.addEventListener('click', () => {
      const next: Theme = read() === 'dark' ? 'light' : 'dark';
      root.dataset.theme = next;
      try { localStorage.setItem(KEY, next); } catch { /* private mode */ }
      sync();
    });
  }
  sync();
}

/** The pre-paint snippet lives literally in src/layouts/Base.astro, because
 *  Astro does not evaluate expressions inside is:inline scripts. Keep the
 *  storage key above ('amp-theme') and that snippet in sync.
 */
