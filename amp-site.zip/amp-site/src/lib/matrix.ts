/**
 * Spec 3 — the dot matrix. Fixed behind the pager, pointer-events:none, so it
 * stays put while sections slide over it. The cursor field reads window pointer
 * coords rather than canvas events.
 *
 * Ported from the approved prototype's MatrixLayer (unpacked/app-3.js) into
 * framework-free TypeScript, with four deliberate performance changes. The
 * visuals are unchanged; the cost is not.
 *
 *   1. DPR is capped at 1.5 rather than 2. These are 0.5px dots at 0.1 opacity
 *      — sub-pixel by design — so the extra fill rate buys nothing visible and
 *      costs up to 4x on a 3x phone.
 *   2. The loop is capped at ~30fps. The sweep crosses in 2.6s and the cursor
 *      glow is a soft radial; neither reads as 30fps.
 *   3. The cursor term is skipped entirely when there is no fine pointer. A
 *      phone never has a cursor, and Lighthouse mobile emulation is exactly
 *      that phone — this removes per-dot work from the metric that gates NFR-1.
 *   4. The loop stops on visibilitychange and while the mobile menu is open.
 *      It deliberately does NOT stop for a section transition — that reads as
 *      the matrix freezing every time you scroll between sections.
 *
 * Reduced motion suppresses the sweep while the static grid and the cursor
 * field remain — "fewer and gentler, not zero".
 */
import { MATRIX, NAV_PULSE, prefersReducedMotion, bus } from './site';
import { REGION_BY_ID, type Region } from './regions';

type Grid = { cols: number; rows: number; w: number; h: number; dpr: number };

/** The pulse origin's frame: centre plus half-extents. Named rather than
 *  inlined so `fading` can reference the shape without `typeof origin`, which
 *  narrows to `null` at the declaration site. */
type Origin = { cx: number; cy: number; hw: number; hh: number };

export type MatrixHandle = { destroy: () => void; setRegion: (id: string | null) => void; setPaused: (p: boolean) => void };

const FRAME_MS = 1000 / 30;

/** Rasterise a boolean dot grid (a region map) into grid-resolution alpha. */
function regionMask(dots: string[], g: Grid, widthFrac: number, gapPx: number, topOffset: number): Float32Array | null {
  if (!dots?.length || !g.cols || !g.rows) return null;
  const rc = dots[0].length;
  const rr = dots.length;
  const src = document.createElement('canvas');
  src.width = rc; src.height = rr;
  const sctx = src.getContext('2d');
  if (!sctx) return null;
  const id = sctx.createImageData(rc, rr);
  for (let r = 0; r < rr; r++)
    for (let c = 0; c < rc; c++)
      id.data[(r * rc + c) * 4 + 3] = dots[r][c] === '1' ? 255 : 0;
  sctx.putImageData(id, 0, 0);

  const off = document.createElement('canvas');
  off.width = g.cols; off.height = g.rows;
  const octx = off.getContext('2d');
  if (!octx) return null;
  // The map lives in the space left under the section's copy, measured from the
  // live layout rather than a guessed fraction of the viewport.
  const topRow = (topOffset + gapPx) / MATRIX.cell;
  const botRow = (g.h - Math.min(64, g.h * 0.06)) / MATRIX.cell;
  const availRows = Math.max(10, botRow - topRow);
  let boxW = g.cols * widthFrac;
  let boxH = boxW * (rr / rc);
  if (boxH > availRows) { boxH = availRows; boxW = boxH * (rc / rr); }
  // Nearest-neighbour: one source cell becomes a block of dots, so the map
  // reads as part of the grid instead of a blurred blob.
  octx.imageSmoothingEnabled = false;
  octx.drawImage(src, (g.cols - boxW) / 2, topRow + (availRows - boxH) / 2, boxW, boxH);
  const d = octx.getImageData(0, 0, g.cols, g.rows).data;
  const m = new Float32Array(g.cols * g.rows);
  for (let i = 0; i < m.length; i++) m[i] = d[i * 4 + 3] / 255;
  return m;
}

/** Rasterise the AMP mark into grid-resolution alpha. The sweep IS the mark:
 *  the travelling band only lights dots inside it, so the wordmark writes
 *  itself across the grid. */
function logoMask(img: HTMLImageElement | null, g: Grid): Float32Array | null {
  if (!img || !img.naturalWidth || !g.cols || !g.rows) return null;
  const off = document.createElement('canvas');
  off.width = g.cols; off.height = g.rows;
  const octx = off.getContext('2d');
  if (!octx) return null;
  octx.imageSmoothingEnabled = true;
  let boxW = g.cols * MATRIX.logoWidth;
  let boxH = boxW * (img.naturalHeight / img.naturalWidth);
  // Height clamp from the prototype: on a short viewport the mark is fitted to
  // 62% of the grid rather than overflowing it.
  const maxH = g.rows * 0.62;
  if (boxH > maxH) { boxH = maxH; boxW = boxH * (img.naturalWidth / img.naturalHeight); }
  octx.drawImage(img, (g.cols - boxW) / 2, (g.rows - boxH) / 2, boxW, boxH);
  const d = octx.getImageData(0, 0, g.cols, g.rows).data;
  const m = new Float32Array(g.cols * g.rows);
  for (let i = 0; i < m.length; i++) m[i] = d[i * 4 + 3] / 255;
  return m;
}

export function initMatrix(canvas: HTMLCanvasElement, logoSrc: string | null): MatrixHandle | null {
  const ctx = canvas.getContext('2d', { alpha: true });
  if (!ctx) return null;

  const grid: Grid = { cols: 0, rows: 0, w: 0, h: 0, dpr: 1 };
  const pointer = { x: -9999, y: -9999, active: false };
  // The cursor field only exists for a fine pointer. Touch has no hover, so
  // there is nothing to brighten — and no reason to compute it per dot.
  const hasFinePointer = matchMedia('(pointer: fine)').matches;

  let mask: Float32Array | null = null;
  let regFrom: Float32Array | null = null;
  let regTo: Float32Array | null = null;
  let regStart = 0;
  let regionTop = 0;
  let regionId: string | null = null;
  let paused = false;
  let reduced = prefersReducedMotion();
  let dark = document.documentElement.dataset.theme === 'dark';
  /** Pulse origin: the active nav item's frame while the nav is up, the
   *  hamburger once it has folded. Sampled on state changes, never per frame —
   *  a getBoundingClientRect in the draw loop forces layout every frame. */
  let origin: Origin | null = null;
  /** The pulse is not global time: each origin gets its own epoch, so a ring
   *  always starts at radius 0 from the button it belongs to. When the origin
   *  changes the outgoing ring keeps its old epoch and finishes its fade from
   *  the old button, instead of snapping across to the new one. */
  let pulseEpoch = performance.now();
  let fading: { origin: Origin; epoch: number } | null = null;
  let raf = 0;
  let lastFrame = 0;
  let logo: HTMLImageElement | null = null;

  const buildLogo = () => { mask = logoMask(logo, grid); };

  /** Where the map starts: the bottom of the Focus copy, measured against its
   *  OWN section rather than the viewport. The section is two pager stops down
   *  at rest, so a viewport-space rect would put the map off the grid and
   *  nothing would draw. */
  const measureRegionTop = () => {
    const anchor = document.querySelector('[data-section="focus"] [data-region-anchor]');
    const section = anchor?.closest('[data-section]');
    regionTop = anchor && section
      ? anchor.getBoundingClientRect().bottom - section.getBoundingClientRect().top
      : grid.h * 0.4;
  };

  const setRegion = (id: string | null) => {
    regionId = id;
    const next: Region | null = id ? REGION_BY_ID[id] ?? null : null;
    regFrom = regTo;
    regTo = next ? regionMask(next.dots, grid, MATRIX.regionWidth, MATRIX.regionGap, regionTop) : null;
    regStart = performance.now();
  };

  /** Re-rasterise the current projection against a fresh measurement, without
   *  restarting the cross-fade. */
  const rebuildRegion = () => {
    measureRegionTop();
    if (!regionId) return;
    const cur: Region | null = REGION_BY_ID[regionId] ?? null;
    regTo = cur ? regionMask(cur.dots, grid, MATRIX.regionWidth, MATRIX.regionGap, regionTop) : null;
  };

  const measureOrigin = () => {
    // The ring leaves the active nav item while the nav is up, and the
    // hamburger once it has folded away.
    const navUp = document.documentElement.dataset.nav !== 'folded';
    const active = document.querySelector<HTMLElement>('[data-pulse-origin]')
      ?? document.querySelector<HTMLElement>('.nav__link[aria-current="page"]')
      ?? document.querySelector<HTMLElement>('.nav__link');
    const burger = document.querySelector<HTMLElement>('[data-burger]');
    const candidates = navUp ? [active, burger] : [burger, active];
    for (const el of candidates) {
      if (!el) continue;
      const r = el.getBoundingClientRect();
      // A folded-away or display:none control has no frame to trace.
      if (r.width < 4 || r.height < 4) continue;
      // MID-FOLD rects are the reason the ring showed up in empty space: the
      // fold translates each link up to --nav-gap to the right over 1180ms, and
      // getBoundingClientRect reports that in-flight position. A link that is
      // not fully opaque is not where it belongs yet, so it is not measured.
      if (parseFloat(getComputedStyle(el).opacity || '1') < 0.9) continue;
      setOrigin({ cx: r.left + r.width / 2, cy: r.top + r.height / 2, hw: r.width / 2, hh: r.height / 2 });
      return;
    }
    // Nothing settled to measure — keep the last known origin rather than
    // dropping the ring, which is what the prototype does (`if (!el) return`).
  };

  /** Re-sample across the fold. One reading at the moment of a state change is
   *  always taken mid-animation; the prototype samples again at 120/400/800/
   *  1400ms, and the nav's own transitionend catches the rest. */
  let settleTimers: number[] = [];
  const settle = () => {
    settleTimers.forEach(clearTimeout);
    settleTimers = [120, 400, 800, 1400].map((t) => window.setTimeout(measureOrigin, t));
    measureOrigin();
  };

  /** Hand the ring over: the old origin keeps running to the end of its cycle
   *  while the new one starts fresh. A re-measure that lands on the same frame
   *  (fonts settling, a resize) must NOT restart the cycle. */
  const setOrigin = (next: Origin | null) => {
    const same = !!origin && !!next &&
      Math.abs(origin.cx - next.cx) < 1 && Math.abs(origin.cy - next.cy) < 1 &&
      Math.abs(origin.hw - next.hw) < 1 && Math.abs(origin.hh - next.hh) < 1;
    if (same) return;
    if (origin) fading = { origin, epoch: pulseEpoch };
    origin = next;
    pulseEpoch = performance.now();
  };

  const resize = () => {
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    const w = window.innerWidth;
    const h = window.innerHeight;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    grid.cols = Math.ceil(w / MATRIX.cell) + 1;
    grid.rows = Math.ceil(h / MATRIX.cell) + 1;
    grid.w = w; grid.h = h; grid.dpr = dpr;
    mask = null;
    buildLogo();
    measureOrigin();
    rebuildRegion();
  };

  const draw = (now: number) => {
    raf = requestAnimationFrame(draw);
    if (paused || now - lastFrame < FRAME_MS) return;
    lastFrame = now;

    const { cols, rows } = grid;
    if (!cols || !rows) return;
    // Dot colour follows the ground: ink dots on paper, paper dots on ink.
    const [r, g, b] = dark ? [250, 248, 245] : [23, 19, 15];
    const cell = MATRIX.cell;

    // Sweep position. Under reduced motion the band is suppressed and only the
    // static grid + cursor field remain.
    const cycle = MATRIX.flashInterval + MATRIX.sweepDuration;
    const t = (now / 1000) % cycle;
    // The focus section belongs to the region map: the AMP sweep sits out
    // entirely while a projection is up, including its cross-fade out, so the
    // two never occupy the grid at once.
    const regionShowing = !!regionId || (!!regFrom && now - regStart < MATRIX.regionFade);
    const sweeping = !reduced && !regionShowing && t > MATRIX.flashInterval;
    const phase = sweeping ? (t - MATRIX.flashInterval) / MATRIX.sweepDuration : 0;
    const bandX = sweeping ? -MATRIX.bandWidth + phase * (grid.w + MATRIX.bandWidth * 2) : null;

    // Spec 5 item 5 — a ring leaving the active nav item's frame. Two rings can
    // be in flight: the current origin's, and the previous origin's finishing
    // its fade after a tab switch.
    type Ring = { o: Origin; r: number; amp: number };
    const rings: Ring[] = [];
    if (!reduced) {
      if (fading?.origin) {
        const ft = (now - fading.epoch) / NAV_PULSE.period;
        if (ft >= 1) fading = null;
        else rings.push({ o: fading.origin, r: ft * NAV_PULSE.max, amp: Math.pow(1 - ft, 1.6) });
      }
      if (origin) {
        const pt = ((now - pulseEpoch) % NAV_PULSE.period) / NAV_PULSE.period;
        rings.push({ o: origin, r: pt * NAV_PULSE.max, amp: Math.pow(1 - pt, 1.6) });
      }
    }
    const pulseOn = rings.some((k) => k.amp > 0.002);

    const regBlend = regFrom || regTo ? Math.min(1, (now - regStart) / MATRIX.regionFade) : 0;
    const regOn = !!(regFrom || regTo);
    const cursorOn = hasFinePointer && pointer.active;
    const LEVELS = MATRIX.levels;
    const buckets: number[][] = Array.from({ length: LEVELS }, () => []);

    for (let row = 0; row < rows; row++) {
      const y = row * cell;
      const rowOff = row * cols;
      for (let col = 0; col < cols; col++) {
        const x = col * cell;
        let opacity = MATRIX.baseOpacity;
        let radius = MATRIX.dot;

        if (cursorOn) {
          const dx = x - pointer.x, dy = y - pointer.y;
          const d2 = dx * dx + dy * dy;
          const rr = MATRIX.cursorRadius * MATRIX.cursorRadius;
          if (d2 < rr) {
            const f = 1 - Math.sqrt(d2) / MATRIX.cursorRadius;
            const ci = Math.pow(f, MATRIX.cursorFalloff) * MATRIX.cursorStrength;
            opacity += ci;
            radius = Math.max(radius, MATRIX.dot * (1 + ci * (MATRIX.dotGrow - 1)));
          }
        }

        if (regOn) {
          const rv = (regFrom ? regFrom[rowOff + col] * (1 - regBlend) : 0) +
                     (regTo ? regTo[rowOff + col] * regBlend : 0);
          if (rv > 0.01) {
            opacity += rv * MATRIX.regionOpacity;
            radius = Math.max(radius, MATRIX.dot * (1 + rv * (MATRIX.regionGrow - 1)));
          }
        }

        if (bandX !== null) {
          const bd = Math.abs(x - bandX);
          if (bd < MATRIX.bandWidth) {
            let bi = 1 - bd / MATRIX.bandWidth;
            bi *= bi;
            const env = Math.sin(phase * Math.PI);
            const mk = mask ? mask[rowOff + col] : 0;
            const amp = bi * env;
            // Off-mark dots keep a residual so the band still reads as a sweep;
            // dots inside the mark get the full flash, which is what draws it.
            const flash = amp * (MATRIX.flashOpacity * MATRIX.logoResidual + MATRIX.logoOpacity * mk);
            opacity += cursorOn ? flash * MATRIX.flashBoostUnderCursor : flash;
            if (mk > 0.2) radius = Math.max(radius, MATRIX.dot * (1 + amp * mk * (MATRIX.logoGrow - 1)));
          }
        }

        if (pulseOn) {
          for (const k of rings) {
            if (k.amp <= 0.002) continue;
            // Distance to the item's rounded-rect FRAME, not its centre, so the
            // ring traces the outline as it expands.
            const rr = Math.min(NAV_PULSE.corner, k.o.hw + NAV_PULSE.padX, k.o.hh + NAV_PULSE.padY);
            const qx = Math.abs(x - k.o.cx) - (k.o.hw + NAV_PULSE.padX - rr);
            const qy = Math.abs(y - k.o.cy) - (k.o.hh + NAV_PULSE.padY - rr);
            const ox = Math.max(qx, 0), oy = Math.max(qy, 0);
            const dist = Math.sqrt(ox * ox + oy * oy) + Math.min(Math.max(qx, qy), 0);
            const band = Math.abs(dist - k.r);
            if (band < NAV_PULSE.width) {
              const pi = Math.pow(1 - band / NAV_PULSE.width, NAV_PULSE.falloff) * k.amp;
              opacity += pi * NAV_PULSE.strength;
              radius = Math.max(radius, MATRIX.dot * (1 + pi * (NAV_PULSE.grow - 1)));
            }
          }
        }

        if (opacity <= 0.008) continue;
        if (opacity > 1) opacity = 1;
        buckets[(opacity * (LEVELS - 1)) | 0].push(x, y, radius);
      }
    }

    ctx.clearRect(0, 0, grid.w, grid.h);
    ctx.fillStyle = `rgb(${r},${g},${b})`;
    // One path per alpha level rather than a state change per dot.
    for (let level = 1; level < LEVELS; level++) {
      const arr = buckets[level];
      if (arr.length === 0) continue;
      ctx.globalAlpha = level / (LEVELS - 1);
      ctx.beginPath();
      for (let i = 0; i < arr.length; i += 3) {
        ctx.moveTo(arr[i] + arr[i + 2], arr[i + 1]);
        ctx.arc(arr[i], arr[i + 1], arr[i + 2], 0, Math.PI * 2);
      }
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  };

  /* ── listeners ─────────────────────────────────────────────────── */
  const onMove = (e: PointerEvent) => { pointer.x = e.clientX; pointer.y = e.clientY; pointer.active = true; };
  const onLeave = () => { pointer.active = false; };
  const onVisibility = () => { paused = document.hidden || menuOpen; };
  let menuOpen = false;

  // The matrix runs THROUGH a section change. Pausing it for the duration of a
  // transition (an earlier performance change) is visible as a freeze on every
  // scroll between sections; the prototype only ever pauses for the open menu.
  // Sections change height with their content (the founders row, a wrapped
  // headline), so the anchor is re-measured on arrival, not only on resize.
  const offArrive = bus.on('amp:section', () => { rebuildRegion(); settle(); });
  const offMenuOrigin = bus.on('amp:menu', () => settle());
  const offRegion = bus.on('amp:region', (d) => setRegion(d as string | null));
  const offMenu = bus.on('amp:menu', (d) => { menuOpen = d as boolean; onVisibility(); });

  const mqReduce = matchMedia('(prefers-reduced-motion: reduce)');
  const onReduce = () => { reduced = mqReduce.matches; };
  mqReduce.addEventListener?.('change', onReduce);

  const onTheme = () => { dark = document.documentElement.dataset.theme === 'dark'; };
  window.addEventListener('amp:theme', onTheme);

  if (hasFinePointer) {
    window.addEventListener('pointermove', onMove, { passive: true });
    window.addEventListener('pointerleave', onLeave);
  }
  document.addEventListener('visibilitychange', onVisibility);
  window.addEventListener('resize', resize);
  window.visualViewport?.addEventListener('resize', resize);

  if (logoSrc) {
    logo = new Image();
    logo.decoding = 'async';
    logo.onload = buildLogo;
    logo.src = logoSrc;
  }
  resize();
  // The header settles after fonts and the logo load, and the intro hands the
  // mark over ~2s in; re-sample rather than trusting the first frame.
  const originTimers = [120, 400, 800, 1400, 2400].map((t) => window.setTimeout(measureOrigin, t));
  // The fold is a CSS transition, so its end is the authoritative moment to
  // re-read the nav's geometry.
  const nav = document.querySelector<HTMLElement>('.nav');
  const onNavSettled = (e: TransitionEvent) => { if (e.propertyName === 'transform') measureOrigin(); };
  nav?.addEventListener('transitionend', onNavSettled);
  raf = requestAnimationFrame(draw);

  return {
    setRegion,
    setPaused: (p) => { paused = p || document.hidden || menuOpen; },
    destroy() {
      cancelAnimationFrame(raf);
      originTimers.forEach(clearTimeout);
      settleTimers.forEach(clearTimeout);
      nav?.removeEventListener('transitionend', onNavSettled);
      offArrive(); offMenuOrigin(); offRegion(); offMenu();
      mqReduce.removeEventListener?.('change', onReduce);
      window.removeEventListener('amp:theme', onTheme);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerleave', onLeave);
      window.removeEventListener('resize', resize);
      window.visualViewport?.removeEventListener('resize', resize);
      document.removeEventListener('visibilitychange', onVisibility);
      ctx.clearRect(0, 0, grid.w, grid.h);
    },
  };
}
