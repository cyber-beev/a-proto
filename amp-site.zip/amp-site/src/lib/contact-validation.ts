/**
 * AMP Global — contact / proposal form validation.
 *
 * Isomorphic: imported by BOTH the client component and the serverless
 * endpoint. Client validation is a courtesy; the server run is the security
 * boundary. Nothing here may be trusted on the client alone.
 *
 * Target path in the Astro project: src/lib/contact-validation.ts
 *
 * Decisions recorded 2026-09-17:
 *   - name and email required; phone, message, file and link optional
 *   - file capped at 4 MB (Vercel Functions hard-limit the request body at
 *     4.5 MB — see docs/fr7-contact-form.md §3)
 *   - a link is offered as an alternative to an attachment
 *   - no /thank-you/ route; confirmation is an inline toast
 */

/* ─────────────────────────── limits ─────────────────────────── */

export const LIMITS = {
  name: { min: 2, max: 100 },
  email: { max: 254, localPartMax: 64 }, // RFC 5321 hard ceilings
  phone: { minDigits: 7, maxDigits: 15, max: 32 }, // E.164 allows 15 digits
  message: { max: 2000 }, // matches the live Contact Form 7 field
  link: { max: 2048 },
  /** 4 MB. Must stay comfortably under Vercel's 4.5 MB *whole-body* limit. */
  fileBytes: 4 * 1024 * 1024,
  /** Reject oversized bodies before parsing them. */
  bodyBytes: 4_400_000,
} as const;

/**
 * Extension allowlist, carried over from the live form's
 * accept=".zip,.mp3,.wav,.pdf,.xls,.xlsx" plus the prototype's copy.
 * Each entry pairs an extension with the magic bytes that must be present —
 * an extension check alone is trivially spoofed by renaming.
 */
export const FILE_TYPES = [
  { ext: 'pdf', mime: 'application/pdf', magic: [[0x25, 0x50, 0x44, 0x46]] }, // %PDF
  { ext: 'zip', mime: 'application/zip', magic: [[0x50, 0x4b, 0x03, 0x04], [0x50, 0x4b, 0x05, 0x06]] },
  { ext: 'xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', magic: [[0x50, 0x4b, 0x03, 0x04]] }, // xlsx IS a zip
  { ext: 'xls', mime: 'application/vnd.ms-excel', magic: [[0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]] }, // OLE2
  { ext: 'mp3', mime: 'audio/mpeg', magic: [[0x49, 0x44, 0x33], [0xff, 0xfb], [0xff, 0xf3], [0xff, 0xf2]] }, // ID3 or frame sync
  { ext: 'wav', mime: 'audio/wav', magic: [[0x52, 0x49, 0x46, 0x46]] }, // RIFF (also check "WAVE" at offset 8)
] as const;

/* ───────────────────────── sanitising ───────────────────────── */

/**
 * DoS ceiling applied during sanitising, well above any legitimate field. The
 * request body is already capped at LIMITS.bodyBytes before parsing; this is
 * defence in depth so no single field can hold an unbounded string.
 *
 * Note this is NOT the field's max length. Sanitising must not truncate to the
 * real limit — doing so silently accepts over-long input and makes the
 * `tooLong` validation branches unreachable. Reject, don't truncate.
 */
const HARD_CAP = 20_000;

/** Control characters, minus the whitespace we legitimately allow. */
// eslint-disable-next-line no-control-regex
const CONTROL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

/**
 * Normalise a single-line field: NFC, strip control characters, remove CR/LF
 * outright (they are the vector for email-header injection), collapse
 * whitespace runs, trim.
 *
 * Applied to EVERY field before it is validated, stored, or interpolated into
 * an email — never interpolate raw request data into a header.
 */
export function sanitizeLine(input: unknown): string {
  if (typeof input !== 'string') return '';
  return input
    .normalize('NFC')
    .replace(CONTROL, '')
    .replace(/[\r\n]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, HARD_CAP);
}

/** Multi-line variant: preserves internal newlines but strips CR and controls. */
export function sanitizeMultiline(input: unknown): string {
  if (typeof input !== 'string') return '';
  return input
    .normalize('NFC')
    .replace(CONTROL, '')
    .replace(/\r\n?/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
    .slice(0, HARD_CAP);
}

/**
 * Reduce a user-supplied filename to a safe basename. Blocks path traversal
 * (`../../x`), null bytes, and reserved device names. The stored object should
 * still be renamed to a generated key — this is defence in depth, not the
 * primary control.
 */
export function safeFileName(name: unknown): string {
  if (typeof name !== 'string') return '';
  const base = name.replace(/\\/g, '/').split('/').pop() ?? '';
  const cleaned = base.replace(CONTROL, '').replace(/[^\w.\-+ ]/g, '_').slice(0, 180);
  if (!cleaned || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i.test(cleaned.split('.')[0])) return '';
  if (cleaned.split('.').length < 2) return ''; // no extension
  return cleaned;
}

/* ───────────────────────── validators ───────────────────────── */

/** Pragmatic, not RFC-complete: rejects the shapes that matter, allows real addresses. */
const EMAIL = /^[^\s@,;:<>()[\]\\]+@[^\s@,;:<>()[\]\\]+(\.[^\s@,;:<>()[\]\\]+)+$/;
const ALLOWED_URL_SCHEME = /^https?:$/i;

export type Issue = { field: string; code: string; message: string };

export type ProposalInput = {
  name?: unknown;
  email?: unknown;
  phone?: unknown;
  message?: unknown;
  link?: unknown;
  /** Honeypot: rendered off-screen, must arrive empty. */
  company?: unknown;
  fileName?: unknown;
  fileSize?: unknown;
  /** First 16 bytes of the upload, hex or Uint8Array, for magic-byte checking. */
  fileHead?: unknown;
};

export type ProposalData = {
  name: string;
  email: string;
  phone: string;
  message: string;
  link: string;
  fileName: string;
  fileSize: number;
};

/**
 * Validate and normalise. Returns either clean data or a list of issues.
 * Identical on client and server — that is the point of this module.
 */
export function validateProposal(input: ProposalInput):
  | { ok: true; data: ProposalData }
  | { ok: false; issues: Issue[] } {
  const issues: Issue[] = [];
  const add = (field: string, code: string, message: string) => issues.push({ field, code, message });

  // Honeypot: any value means a bot. Return a generic success to the client so
  // the bot learns nothing, but never send the mail.
  if (typeof input.company === 'string' && input.company.trim() !== '') {
    return { ok: false, issues: [{ field: 'company', code: 'spam', message: 'Submission rejected.' }] };
  }

  const name = sanitizeLine(input.name);
  if (name.length < LIMITS.name.min) add('name', 'required', 'Please enter your name.');
  else if (name.length > LIMITS.name.max) add('name', 'tooLong', `Name must be ${LIMITS.name.max} characters or fewer.`);

  const emailRaw = typeof input.email === 'string' ? input.email.trim() : '';
  const email = sanitizeLine(emailRaw);
  if (!email) add('email', 'required', 'Please enter your email address.');
  else if (email.length > LIMITS.email.max) add('email', 'tooLong', 'Email address is too long.');
  else if (!EMAIL.test(email)) add('email', 'format', 'Please enter a valid email address.');
  else if ((email.split('@')[0] ?? '').length > LIMITS.email.localPartMax) add('email', 'format', 'Please enter a valid email address.');

  const phone = sanitizeLine(input.phone);
  if (phone.length > LIMITS.phone.max) add('phone', 'tooLong', `Phone must be ${LIMITS.phone.max} characters or fewer.`);
  else if (phone) {
    const digits = phone.replace(/\D/g, '');
    if (!/^[+\d][\d\s().-]*$/.test(phone)) add('phone', 'format', 'Please enter a valid phone number.');
    else if (digits.length < LIMITS.phone.minDigits || digits.length > LIMITS.phone.maxDigits)
      add('phone', 'format', 'Please enter a valid phone number.');
  }

  const message = sanitizeMultiline(input.message);
  if (message.length > LIMITS.message.max)
    add('message', 'tooLong', `Message must be ${LIMITS.message.max} characters or fewer.`);

  const link = sanitizeLine(input.link);
  if (link.length > LIMITS.link.max) add('link', 'tooLong', `Link must be ${LIMITS.link.max} characters or fewer.`);
  else if (link) {
    let url: URL | null = null;
    try { url = new URL(link); } catch { url = null; }
    if (!url) add('link', 'format', 'Please enter a full link, including https://');
    else if (!ALLOWED_URL_SCHEME.test(url.protocol)) add('link', 'scheme', 'Links must start with http:// or https://');
    else if (!url.hostname.includes('.') || url.hostname.toLowerCase() === 'localhost')
      add('link', 'host', 'Please enter a valid link.');
  }

  // File: size, extension allowlist, and magic bytes.
  const fileName = safeFileName(input.fileName);
  const fileSize = typeof input.fileSize === 'number' && Number.isFinite(input.fileSize) ? input.fileSize : 0;
  if (fileName || fileSize > 0) {
    if (!fileName) add('file', 'name', 'That file name is not allowed.');
    if (fileSize > LIMITS.fileBytes)
      add('file', 'tooLarge', `Files must be ${LIMITS.fileBytes / 1024 / 1024} MB or smaller. For larger catalogues, share a link instead.`);
    if (fileSize <= 0) add('file', 'empty', 'That file is empty.');
    const ext = fileName.split('.').pop()?.toLowerCase() ?? '';
    if (/[.]/.test(ext) || !FILE_TYPES.some((t) => t.ext === ext))
      add('file', 'type', 'Allowed types: ZIP, MP3, WAV, PDF, XLS, XLSX.');
    else if (input.fileHead && !matchesMagic(input.fileHead, ext))
      add('file', 'type', 'That file does not match its extension.');
  }

  if (issues.length) return { ok: false, issues };
  return { ok: true, data: { name, email, phone, message, link, fileName, fileSize } };
}

/** Compare a file's leading bytes against the allowlist entry for its extension. */
export function matchesMagic(head: unknown, ext: string): boolean {
  const entry = FILE_TYPES.find((t) => t.ext === ext);
  if (!entry) return false;
  let bytes: number[];
  if (head instanceof Uint8Array) bytes = Array.from(head);
  else if (typeof head === 'string') bytes = (head.match(/[\da-f]{2}/gi) ?? []).map((h) => parseInt(h, 16));
  else return false;
  return entry.magic.some((sig) => sig.every((b, i) => bytes[i] === b)) &&
    // WAV must also say "WAVE" at offset 8 — RIFF alone covers AVI and webp.
    (ext !== 'wav' || [0x57, 0x41, 0x56, 0x45].every((b, i) => bytes[8 + i] === b));
}

/* ───────────────────── email body assembly ───────────────────── */

/**
 * Build the notification as PLAIN TEXT. Never interpolate user input into a
 * subject or any other header — sanitizeLine() strips CR/LF for exactly this
 * reason, but keeping user content out of headers entirely is the real fix.
 *
 * Any HTML email must escape every interpolated value; plain text sidesteps it.
 */
export function buildNotification(d: ProposalData): {
  subject: string;
  text: string;
} {
  const lines = [
    `New proposal from ${d.name}`,
    '',
    `Name:    ${d.name}`,
    `Email:   ${d.email}`,
    d.phone ? `Phone:   ${d.phone}` : null,
    d.link ? `Link:    ${d.link}` : null,
    d.fileName ? `File:    ${d.fileName} (${(d.fileSize / 1024 / 1024).toFixed(2)} MB)` : null,
    '',
    d.message ? `Message:\n${d.message}` : 'Message: (none provided)',
  ].filter(Boolean);

  // A fixed subject: no user data, so no header-injection surface at all.
  return { subject: 'New proposal via ampglobalent.com', text: lines.join('\n') };
}
