/**
 * Spec 4 — the gradient layer.
 *
 * One fixed layer, positioned in VIEWPORT space from the pager's live
 * progress. A gradient nested inside a section would be bounded by that
 * section and cut at the seam as it drifts; hoisting them removes the
 * constraint instead of fighting it.
 *
 * Each box is two viewports tall and centred on its stop's bottom edge, so the
 * ellipse is drawn whole — a one-viewport box ending at the ellipse centre
 * paints only its upper half and leaves a hard flat cut.
 *
 * Writes run in one rAF and only when progress or the theme actually changed.
 */
import { GRADIENT, pagerState } from './site';

type GradCfg = { colorMode: string; spreadX: number; height: number; opacity: number; midStop: number; feather: number };

function gradientCss(cfg: GradCfg, dark: boolean) {
  // "ground" is a tint of the surface: a LIGHT bloom on ink, a warm DARK bloom
  // on paper. The two are picked for comparable contrast against their own
  // ground — rule tone on paper is ~7x weaker than paper on ink, which made
  // the light-mode gradient effectively invisible at the tuned opacity.
  const rgb =
    cfg.colorMode === 'accent' ? '249,96,61'
    : cfg.colorMode === 'ink' ? '23,19,15'
    : dark ? '250,248,245'   // light bloom on ink
    : '58,51,44';            // warm dark bloom on paper (ink-soft)
  const a = cfg.opacity;
  // The box is 2 viewports tall with the ellipse at its centre, so the
  // vertical radius is halved for `height` to still read as a % of ONE viewport.
  const ry = cfg.height / 2;
  return (
    `radial-gradient(ellipse ${cfg.spreadX}% ${ry}% at 50% 50%, ` +
    `rgba(${rgb},${a}) 0%, ` +
    `rgba(${rgb},${(a * 0.45).toFixed(3)}) ${cfg.midStop}%, ` +
    `rgba(${rgb},0) ${cfg.feather}%)`
  );
}

export function initGradients() {
  const layer = document.querySelector<HTMLElement>('[data-gradients]');
  const track = document.querySelector<HTMLElement>('[data-track]');
  if (!layer || !track) return;

  const sections = Array.from(track.querySelectorAll<HTMLElement>('[data-section]'));
  if (!sections.length) return;

  const boxes = sections.map((s) => {
    const el = document.createElement('div');
    el.className = 'grad';
    el.dataset.footer = String(s.dataset.section === '__footer');
    layer.appendChild(el);
    return el;
  });

  let lastP: number | null = null;
  let lastDark: boolean | null = null;

  const tick = () => {
    requestAnimationFrame(tick);
    const p = pagerState.progress;
    const dark = document.documentElement.dataset.theme === 'dark';
    if (p === lastP && dark === lastDark) return;
    lastP = p;
    lastDark = dark;

    for (let i = 0; i < boxes.length; i++) {
      const el = boxes[i];
      // Stops carry their own position in progress space, so the footer can sit
      // at a fractional index — it is only part of a viewport past the last
      // section, not a whole one.
      const at = pagerState.stops[i] ?? i;
      const d = p - at;
      if (Math.abs(d) > 1.4) { el.style.display = 'none'; continue; }
      const cfg = el.dataset.footer === 'true' ? GRADIENT.footer : GRADIENT.standard;
      const opacity = GRADIENT.fade.enabled
        ? Math.pow(Math.max(0, 1 - Math.abs(d)), GRADIENT.fade.sharpness)
        : 1;
      if (opacity <= 0.001) { el.style.display = 'none'; continue; }
      const driftVh = GRADIENT.fade.enabled
        ? Math.max(-1, Math.min(1, d)) * GRADIENT.fade.drift
        : 0;
      el.style.display = 'block';
      el.style.top = `${-d * 100}%`;
      el.style.transform = `translateY(${driftVh}vh)`;
      el.style.opacity = String(opacity);
      el.style.background = gradientCss(cfg as GradCfg, dark);
    }
  };

  requestAnimationFrame(tick);
}
