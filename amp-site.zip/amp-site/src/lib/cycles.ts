/**
 * Option cycling — one behaviour shared by every cyclable group (Focus Regions,
 * What We Do pillars, Our Edge items):
 *   - it only runs while that section is the one on screen, so a paged-away
 *     section is not burning a timer or arriving mid-cycle
 *   - any pointer or keyboard touch hands control to the user, and it picks
 *     back up only after they have gone idle
 *   - one keyboard model: arrows step through the options, wrapping
 *   - prefers-reduced-motion stops the automatic advance; the options stay
 *     fully operable by hand
 */
import { CYCLE_MS, CYCLE_RESUME_MS, prefersReducedMotion } from './site';

export function initCycles() {
  for (const group of Array.from(document.querySelectorAll<HTMLElement>('[data-cycle]'))) {
    const options = Array.from(group.querySelectorAll<HTMLElement>('[data-cycle-option]'));
    if (options.length < 2) continue;
    // Copy blocks in a [data-cycle-panel] beside the options: one per option,
    // keyed by the option's cycle value. All but the first are hidden in the
    // server-rendered HTML, so with JS off the panel still reads correctly.
    const copies = Array.from(group.querySelectorAll<HTMLElement>('[data-cycle-copy]'));
    const hoverSelects = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const interval = Number(group.dataset.cycleInterval) || CYCLE_MS;
    let index = Math.max(0, options.findIndex((o) => o.getAttribute('aria-selected') === 'true' || o.getAttribute('aria-pressed') === 'true'));
    let timer = 0;
    let idle = 0;
    let live = group.dataset.cycleLive === 'true';

    const select = (i: number, focus = false) => {
      index = ((i % options.length) + options.length) % options.length;
      options.forEach((o, n) => {
        o.setAttribute('aria-selected', String(n === index));
        o.setAttribute('aria-pressed', String(n === index));
        o.tabIndex = n === index ? 0 : -1;
      });
      const value = options[index].dataset.cycleValue ?? String(index);
      copies.forEach((c) => { c.hidden = c.dataset.cycleCopy !== value; });
      group.dispatchEvent(new CustomEvent('amp:cycle', { detail: { index, value: options[index].dataset.cycleValue ?? String(index) }, bubbles: true }));
      if (focus) options[index].focus();
    };

    const start = () => {
      stop();
      if (!live || prefersReducedMotion()) return;
      timer = window.setInterval(() => select(index + 1), interval);
    };
    const stop = () => { if (timer) { clearInterval(timer); timer = 0; } };
    const handOver = () => {
      stop();
      clearTimeout(idle);
      idle = window.setTimeout(start, CYCLE_RESUME_MS);
    };

    group.addEventListener('pointerdown', handOver);
    group.addEventListener('keydown', (e) => {
      const k = e.key;
      if (k === 'ArrowRight' || k === 'ArrowDown') { e.preventDefault(); handOver(); select(index + 1, true); }
      else if (k === 'ArrowLeft' || k === 'ArrowUp') { e.preventDefault(); handOver(); select(index - 1, true); }
    });
    options.forEach((o, n) => {
      o.addEventListener('click', () => { handOver(); select(n); });
      // Hovering an option selects it, as in the approved prototype. Gated on a
      // fine pointer so a tap cannot select twice.
      if (hoverSelects) o.addEventListener('pointerenter', () => { handOver(); select(n); });
      o.addEventListener('focus', () => { handOver(); select(n); });
    });

    // Only run while the section is on screen.
    window.addEventListener('amp:section', (e) => {
      const id = (e as CustomEvent<string>).detail;
      const was = live;
      live = (group.closest('[data-section]') as HTMLElement | null)?.dataset.section === id;
      group.dataset.cycleLive = String(live);
      if (live && !was) start(); else if (!live && was) { stop(); clearTimeout(idle); }
    });

    select(index);
    if (live) start();
  }
}
