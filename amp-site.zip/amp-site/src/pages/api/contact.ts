/**
 * FR-7 — Submit Proposal endpoint. Serverless on Vercel.
 *
 * Security notes, in the order they run:
 *  1. Method and origin are checked before anything is parsed.
 *  2. Content-Length is checked against LIMITS.bodyBytes BEFORE parsing, so an
 *     oversized body is rejected without being read into memory.
 *  3. The request is parsed as multipart/form-data. NEVER base64 JSON: base64
 *     inflates ~37%, so a 4 MB file becomes a 5.5 MB body and Vercel returns
 *     413 against its 4.5 MB limit.
 *  4. validateProposal() runs here again. The client copy is UX only.
 *  5. Turnstile is verified server-side. A client token proves nothing.
 *  6. The notification is plain text with a FIXED subject, so there is no
 *     header-injection surface and no HTML to inject into.
 *  7. Nothing containing personal data is logged.
 *
 * Rate limiting belongs in a Vercel WAF rule (per IP, e.g. 5/minute on this
 * path) rather than in code: functions are ephemeral, so an in-memory counter
 * resets on every cold start and is trivially bypassed.
 */
import type { APIContext } from 'astro';
import { validateProposal, LIMITS, buildNotification } from '../../lib/contact-validation';

export const prerender = false;

const ALLOWED_ORIGINS = ['https://ampglobalent.com', 'https://www.ampglobalent.com'];

const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  });

async function verifyTurnstile(token: string | null, ip: string | null): Promise<boolean> {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret) return true;                     // not configured yet — do not block submissions
  if (!token) return false;
  const body = new URLSearchParams({ secret, response: token });
  if (ip) body.set('remoteip', ip);
  try {
    const res = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST', body, headers: { 'content-type': 'application/x-www-form-urlencoded' },
    });
    const data = (await res.json()) as { success?: boolean };
    return data.success === true;
  } catch {
    return false;                               // fail closed if Turnstile is unreachable
  }
}

async function sendEmail(text: string, subject: string, replyTo: string): Promise<{ ok: boolean; error?: string }> {
  const key = process.env.RESEND_API_KEY;
  const from = (process.env.PROPOSAL_FROM) || 'proposals@ampglobalent.com';
  const to = (process.env.PROPOSAL_TO) || 'info@ampglobalent.com';
  if (!key) {
    // Not configured: log to the function log (no PII beyond what the sender
    // chose to write) and tell the caller plainly, rather than silently
    // pretending the submission succeeded.
    console.warn('[contact] RESEND_API_KEY is not set — notification not delivered');
    return { ok: false, error: 'The submission service is not configured yet. Please email info@ampglobalent.com directly.' };
  }
  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json' },
      // Sent FROM the provider's verified domain with reply-to the AMP inbox,
      // so no SPF change is needed on the GoDaddy zone. FR-10 forbids editing
      // mail records; this keeps that promise.
      body: JSON.stringify({ from, to, reply_to: replyTo, subject, text }),
    });
    if (!res.ok) {
      console.error('[contact] resend status', res.status);
      return { ok: false, error: 'Your proposal could not be sent. Please email info@ampglobalent.com directly.' };
    }
    return { ok: true };
  } catch (e) {
    console.error('[contact] resend error', (e as Error).message);
    return { ok: false, error: 'Your proposal could not be sent. Please email info@ampglobalent.com directly.' };
  }
}

export async function POST({ request }: APIContext) {
  // Astro hands endpoints an APIContext, not a Request. Destructuring above is
  // load-bearing: with the Web-standard `(request: Request)` signature every
  // property read is undefined and the handler 405s on a valid POST.
  if (request.method !== 'POST') return json(405, { ok: false, error: 'Method not allowed.' });

  // Cheap origin check. Not a security boundary on its own — the origin header
  // is absent for some legitimate clients — but it stops drive-by form posts.
  const origin = request.headers.get('origin');
  if (origin && !ALLOWED_ORIGINS.some((o) => origin.startsWith(o)) && !origin.includes('.vercel.app')) {
    return json(403, { ok: false, error: 'Forbidden.' });
  }

  const length = Number(request.headers.get('content-length') ?? 0);
  if (length > LIMITS.bodyBytes) {
    return json(413, { ok: false, issues: [{ field: 'file', message: 'Files must be 4 MB or smaller. For larger catalogues, share a link instead.' }] });
  }

  let form: FormData;
  try { form = await request.formData(); }
  catch { return json(400, { ok: false, error: 'Malformed submission.' }); }

  const str = (k: string) => { const v = form.get(k); return typeof v === 'string' ? v : ''; };
  const file = form.get('file');
  const upload = file instanceof File && file.size > 0 ? file : null;

  // File storage is intentionally not wired yet. Attachments need Vercel Blob
  // (or equivalent) with a private read token and a retention window; until
  // that exists, the link field is the supported path and the file input is
  // not rendered (PUBLIC_ALLOW_FILE_UPLOADS=false). See docs/fr7-contact-form.md.
  if (upload) {
    return json(400, {
      ok: false,
      issues: [{ field: 'file', message: 'Attachments are not enabled yet — please share a link to the catalogue instead.' }],
    });
  }

  // When blob storage is wired up, read the first 16 bytes of the upload here
  // and pass them as `fileHead`; validateProposal() then checks magic bytes
  // against the declared extension, which is what stops a renamed .exe.
  //   const head = new Uint8Array(await upload.slice(0, 16).arrayBuffer());
  //   const fileHead = Array.from(head, (b) => b.toString(16).padStart(2, '0')).join('');
  const result = validateProposal({
    name: str('name'), email: str('email'), phone: str('phone'),
    message: str('message'), link: str('link'), company: str('company'),
  });

  if (!result.ok) {
    // A filled honeypot means a bot. Return success so it learns nothing, and
    // do not send mail.
    if (result.issues.some((i) => i.code === 'spam')) return json(200, { ok: true });
    return json(422, { ok: false, issues: result.issues.map((i) => ({ field: i.field, message: i.message })) });
  }

  const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? null;
  if (!(await verifyTurnstile(str('turnstile') || null, ip))) {
    return json(403, { ok: false, error: 'Human verification failed. Please try again.' });
  }

  const { data } = result;
  const { subject, text } = buildNotification(data);
  const sent = await sendEmail(text, subject, data.email);
  if (!sent.ok) return json(502, { ok: false, error: sent.error });

  return json(200, { ok: true });
}
