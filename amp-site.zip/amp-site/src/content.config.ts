/**
 * Content Collections — the single source of truth for what the CMS may edit.
 *
 * Keystatic writes these files; Astro type-checks them at build time. If an
 * editor removes a required field the build fails rather than the page
 * rendering blank. Keep the schemas here aligned with keystatic.config.ts.
 *
 * Region *dot matrices* are deliberately NOT in the CMS: they are generated
 * raster data, not copy, and live in src/lib/regions.ts. Editors change a
 * region's name and order; changing a map is a code change.
 */
import { defineCollection } from 'astro:content';
// Astro 7 deprecates its own `z` re-export; zod is Astro's own dependency (^4.5.4)
// and is declared explicitly here so the schemas cannot pick up a second copy.
import { z } from 'zod';
import { glob } from 'astro/loaders';

const seo = z.object({
  title: z.string().max(60),
  description: z.string().min(50).max(160),
});

const pages = defineCollection({
  loader: glob({ pattern: '*.json', base: './src/content/pages' }),
  schema: z.discriminatedUnion('page', [
    z.object({
      page: z.literal('home'),
      seo,
      hero: z.object({
        headlineBefore: z.string(),
        headlineEmphasis: z.string(),
        headlineAfter: z.string(),
        lead: z.string(),
        ctaLabel: z.string(),
      }),
      approach: z.object({
        paragraphs: z.array(z.string()).min(1).max(4),
        headingBefore: z.string(),
        headingEmphasis: z.string(),
        headingAfter: z.string(),
      }),
      focus: z.object({
        heading: z.string(),
        body: z.string(),
        /** Must match an id in src/lib/regions.ts */
        regionOrder: z.array(z.string()).min(1),
      }),
    }),
    z.object({
      page: z.literal('about'),
      seo,
      whatWeDo: z.object({
        heading: z.string(),
        body: z.string(),
        pillars: z.array(z.object({ title: z.string(), copy: z.string() })).min(1),
      }),
      edge: z.object({
        heading: z.string(),
        items: z.array(z.object({
          title: z.string(),
          copy: z.string(),
          icon: z.enum(['pin', 'scale', 'build', 'data', 'curve', 'wave', 'mic', 'headphones']),
        })).min(1),
      }),
      who: z.object({
        heading: z.string(),
        intro: z.string(),
        items: z.array(z.object({
          label: z.string(),
          icon: z.enum(['head', 'catalogue', 'record', 'partners', 'mic', 'headphones', 'wave', 'curve']),
        })).min(1),
      }),
    }),
    z.object({
      page: z.literal('team'),
      seo,
      heading: z.string(),
      body: z.string(),
      groupLabel: z.string(),
      members: z.array(z.object({
        name: z.string(),
        role: z.string(),
        photo: z.string(),
        photoAlt: z.string(),
      })).min(1),
    }),
    z.object({
      page: z.literal('contact'),
      seo,
      statement: z.object({
        headingBefore: z.string(),
        headingEmphasis: z.string(),
        headingAfter: z.string(),
        body: z.string(),
        regionsLine: z.string(),
        email: z.email(),
      }),
      proposal: z.object({
        heading: z.string(),
        body: z.string(),
        submitLabel: z.string(),
        fileHint: z.string(),
        successMessage: z.string(),
        errorMessage: z.string(),
      }),
    }),
  ]),
});

const news = defineCollection({
  loader: glob({ pattern: '**/*.{mdoc,md}', base: './src/content/news' }),
  schema: z.object({
    title: z.string(),
    /** ISO date; posts dated in the future are treated as drafts. */
    publishedOn: z.coerce.date(),
    excerpt: z.string().max(200),
    cover: z.string().optional(),
    coverAlt: z.string().optional(),
    tags: z.array(z.string()).default([]),
    draft: z.boolean().default(false),
  }),
});

export const collections = { pages, news };
