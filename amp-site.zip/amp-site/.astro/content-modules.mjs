
export default new Map([
["src/content/news/hello-from-amp.mdoc", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fnews%2Fhello-from-amp.mdoc&astroContentModuleFlag=true")]]);
		