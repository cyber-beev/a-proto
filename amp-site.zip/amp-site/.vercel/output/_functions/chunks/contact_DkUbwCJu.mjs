import { t as __exportAll } from "./rolldown-runtime_D7D4PA-g.mjs";
//#region src/lib/contact-validation.ts
/**
* AMP Global — contact / proposal form validation.
*
* Isomorphic: imported by BOTH the client component and the serverless
* endpoint. Client validation is a courtesy; the server run is the security
* boundary. Nothing here may be trusted on the client alone.
*
* Target path in the Astro project: src/lib/contact-validation.ts
*
* Decisions recorded 2026-09-17:
*   - name and email required; phone, message, file and link optional
*   - file capped at 4 MB (Vercel Functions hard-limit the request body at
*     4.5 MB — see docs/fr7-contact-form.md §3)
*   - a link is offered as an alternative to an attachment
*   - no /thank-you/ route; confirmation is an inline toast
*/
var LIMITS = {
	name: {
		min: 2,
		max: 100
	},
	email: {
		max: 254,
		localPartMax: 64
	},
	phone: {
		minDigits: 7,
		maxDigits: 15,
		max: 32
	},
	message: { max: 2e3 },
	link: { max: 2048 },
	/** 4 MB. Must stay comfortably under Vercel's 4.5 MB *whole-body* limit. */
	fileBytes: 4194304,
	/** Reject oversized bodies before parsing them. */
	bodyBytes: 44e5
};
/**
* Extension allowlist, carried over from the live form's
* accept=".zip,.mp3,.wav,.pdf,.xls,.xlsx" plus the prototype's copy.
* Each entry pairs an extension with the magic bytes that must be present —
* an extension check alone is trivially spoofed by renaming.
*/
var FILE_TYPES = [
	{
		ext: "pdf",
		mime: "application/pdf",
		magic: [[
			37,
			80,
			68,
			70
		]]
	},
	{
		ext: "zip",
		mime: "application/zip",
		magic: [[
			80,
			75,
			3,
			4
		], [
			80,
			75,
			5,
			6
		]]
	},
	{
		ext: "xlsx",
		mime: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
		magic: [[
			80,
			75,
			3,
			4
		]]
	},
	{
		ext: "xls",
		mime: "application/vnd.ms-excel",
		magic: [[
			208,
			207,
			17,
			224,
			161,
			177,
			26,
			225
		]]
	},
	{
		ext: "mp3",
		mime: "audio/mpeg",
		magic: [
			[
				73,
				68,
				51
			],
			[255, 251],
			[255, 243],
			[255, 242]
		]
	},
	{
		ext: "wav",
		mime: "audio/wav",
		magic: [[
			82,
			73,
			70,
			70
		]]
	}
];
/**
* DoS ceiling applied during sanitising, well above any legitimate field. The
* request body is already capped at LIMITS.bodyBytes before parsing; this is
* defence in depth so no single field can hold an unbounded string.
*
* Note this is NOT the field's max length. Sanitising must not truncate to the
* real limit — doing so silently accepts over-long input and makes the
* `tooLong` validation branches unreachable. Reject, don't truncate.
*/
var HARD_CAP = 2e4;
/** Control characters, minus the whitespace we legitimately allow. */
var CONTROL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
/**
* Normalise a single-line field: NFC, strip control characters, remove CR/LF
* outright (they are the vector for email-header injection), collapse
* whitespace runs, trim.
*
* Applied to EVERY field before it is validated, stored, or interpolated into
* an email — never interpolate raw request data into a header.
*/
function sanitizeLine(input) {
	if (typeof input !== "string") return "";
	return input.normalize("NFC").replace(CONTROL, "").replace(/[\r\n]+/g, " ").replace(/\s+/g, " ").trim().slice(0, HARD_CAP);
}
/** Multi-line variant: preserves internal newlines but strips CR and controls. */
function sanitizeMultiline(input) {
	if (typeof input !== "string") return "";
	return input.normalize("NFC").replace(CONTROL, "").replace(/\r\n?/g, "\n").replace(/\n{3,}/g, "\n\n").trim().slice(0, HARD_CAP);
}
/**
* Reduce a user-supplied filename to a safe basename. Blocks path traversal
* (`../../x`), null bytes, and reserved device names. The stored object should
* still be renamed to a generated key — this is defence in depth, not the
* primary control.
*/
function safeFileName(name) {
	if (typeof name !== "string") return "";
	const cleaned = (name.replace(/\\/g, "/").split("/").pop() ?? "").replace(CONTROL, "").replace(/[^\w.\-+ ]/g, "_").slice(0, 180);
	if (!cleaned || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i.test(cleaned.split(".")[0])) return "";
	if (cleaned.split(".").length < 2) return "";
	return cleaned;
}
/** Pragmatic, not RFC-complete: rejects the shapes that matter, allows real addresses. */
var EMAIL = /^[^\s@,;:<>()[\]\\]+@[^\s@,;:<>()[\]\\]+(\.[^\s@,;:<>()[\]\\]+)+$/;
var ALLOWED_URL_SCHEME = /^https?:$/i;
/**
* Validate and normalise. Returns either clean data or a list of issues.
* Identical on client and server — that is the point of this module.
*/
function validateProposal(input) {
	const issues = [];
	const add = (field, code, message) => issues.push({
		field,
		code,
		message
	});
	if (typeof input.company === "string" && input.company.trim() !== "") return {
		ok: false,
		issues: [{
			field: "company",
			code: "spam",
			message: "Submission rejected."
		}]
	};
	const name = sanitizeLine(input.name);
	if (name.length < LIMITS.name.min) add("name", "required", "Please enter your name.");
	else if (name.length > LIMITS.name.max) add("name", "tooLong", `Name must be ${LIMITS.name.max} characters or fewer.`);
	const email = sanitizeLine(typeof input.email === "string" ? input.email.trim() : "");
	if (!email) add("email", "required", "Please enter your email address.");
	else if (email.length > LIMITS.email.max) add("email", "tooLong", "Email address is too long.");
	else if (!EMAIL.test(email)) add("email", "format", "Please enter a valid email address.");
	else if ((email.split("@")[0] ?? "").length > LIMITS.email.localPartMax) add("email", "format", "Please enter a valid email address.");
	const phone = sanitizeLine(input.phone);
	if (phone.length > LIMITS.phone.max) add("phone", "tooLong", `Phone must be ${LIMITS.phone.max} characters or fewer.`);
	else if (phone) {
		const digits = phone.replace(/\D/g, "");
		if (!/^[+\d][\d\s().-]*$/.test(phone)) add("phone", "format", "Please enter a valid phone number.");
		else if (digits.length < LIMITS.phone.minDigits || digits.length > LIMITS.phone.maxDigits) add("phone", "format", "Please enter a valid phone number.");
	}
	const message = sanitizeMultiline(input.message);
	if (message.length > LIMITS.message.max) add("message", "tooLong", `Message must be ${LIMITS.message.max} characters or fewer.`);
	const link = sanitizeLine(input.link);
	if (link.length > LIMITS.link.max) add("link", "tooLong", `Link must be ${LIMITS.link.max} characters or fewer.`);
	else if (link) {
		let url = null;
		try {
			url = new URL(link);
		} catch {
			url = null;
		}
		if (!url) add("link", "format", "Please enter a full link, including https://");
		else if (!ALLOWED_URL_SCHEME.test(url.protocol)) add("link", "scheme", "Links must start with http:// or https://");
		else if (!url.hostname.includes(".") || url.hostname.toLowerCase() === "localhost") add("link", "host", "Please enter a valid link.");
	}
	const fileName = safeFileName(input.fileName);
	const fileSize = typeof input.fileSize === "number" && Number.isFinite(input.fileSize) ? input.fileSize : 0;
	if (fileName || fileSize > 0) {
		if (!fileName) add("file", "name", "That file name is not allowed.");
		if (fileSize > LIMITS.fileBytes) add("file", "tooLarge", `Files must be ${LIMITS.fileBytes / 1024 / 1024} MB or smaller. For larger catalogues, share a link instead.`);
		if (fileSize <= 0) add("file", "empty", "That file is empty.");
		const ext = fileName.split(".").pop()?.toLowerCase() ?? "";
		if (/[.]/.test(ext) || !FILE_TYPES.some((t) => t.ext === ext)) add("file", "type", "Allowed types: ZIP, MP3, WAV, PDF, XLS, XLSX.");
		else if (input.fileHead && !matchesMagic(input.fileHead, ext)) add("file", "type", "That file does not match its extension.");
	}
	if (issues.length) return {
		ok: false,
		issues
	};
	return {
		ok: true,
		data: {
			name,
			email,
			phone,
			message,
			link,
			fileName,
			fileSize
		}
	};
}
/** Compare a file's leading bytes against the allowlist entry for its extension. */
function matchesMagic(head, ext) {
	const entry = FILE_TYPES.find((t) => t.ext === ext);
	if (!entry) return false;
	let bytes;
	if (head instanceof Uint8Array) bytes = Array.from(head);
	else if (typeof head === "string") bytes = (head.match(/[\da-f]{2}/gi) ?? []).map((h) => parseInt(h, 16));
	else return false;
	return entry.magic.some((sig) => sig.every((b, i) => bytes[i] === b)) && (ext !== "wav" || [
		87,
		65,
		86,
		69
	].every((b, i) => bytes[8 + i] === b));
}
/**
* Build the notification as PLAIN TEXT. Never interpolate user input into a
* subject or any other header — sanitizeLine() strips CR/LF for exactly this
* reason, but keeping user content out of headers entirely is the real fix.
*
* Any HTML email must escape every interpolated value; plain text sidesteps it.
*/
function buildNotification(d) {
	return {
		subject: "New proposal via ampglobalent.com",
		text: [
			`New proposal from ${d.name}`,
			"",
			`Name:    ${d.name}`,
			`Email:   ${d.email}`,
			d.phone ? `Phone:   ${d.phone}` : null,
			d.link ? `Link:    ${d.link}` : null,
			d.fileName ? `File:    ${d.fileName} (${(d.fileSize / 1024 / 1024).toFixed(2)} MB)` : null,
			"",
			d.message ? `Message:\n${d.message}` : "Message: (none provided)"
		].filter(Boolean).join("\n")
	};
}
//#endregion
//#region src/pages/api/contact.ts
/**
* FR-7 — Submit Proposal endpoint. Serverless on Vercel.
*
* Security notes, in the order they run:
*  1. Method and origin are checked before anything is parsed.
*  2. Content-Length is checked against LIMITS.bodyBytes BEFORE parsing, so an
*     oversized body is rejected without being read into memory.
*  3. The request is parsed as multipart/form-data. NEVER base64 JSON: base64
*     inflates ~37%, so a 4 MB file becomes a 5.5 MB body and Vercel returns
*     413 against its 4.5 MB limit.
*  4. validateProposal() runs here again. The client copy is UX only.
*  5. Turnstile is verified server-side. A client token proves nothing.
*  6. The notification is plain text with a FIXED subject, so there is no
*     header-injection surface and no HTML to inject into.
*  7. Nothing containing personal data is logged.
*
* Rate limiting belongs in a Vercel WAF rule (per IP, e.g. 5/minute on this
* path) rather than in code: functions are ephemeral, so an in-memory counter
* resets on every cold start and is trivially bypassed.
*/
var contact_exports = /* @__PURE__ */ __exportAll({
	POST: () => POST,
	prerender: () => false
});
var ALLOWED_ORIGINS = ["https://ampglobalent.com", "https://www.ampglobalent.com"];
var json = (status, body) => new Response(JSON.stringify(body), {
	status,
	headers: {
		"content-type": "application/json; charset=utf-8",
		"cache-control": "no-store"
	}
});
async function verifyTurnstile(token, ip) {
	const secret = process.env.TURNSTILE_SECRET_KEY;
	if (!secret) return true;
	if (!token) return false;
	const body = new URLSearchParams({
		secret,
		response: token
	});
	if (ip) body.set("remoteip", ip);
	try {
		return (await (await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
			method: "POST",
			body,
			headers: { "content-type": "application/x-www-form-urlencoded" }
		})).json()).success === true;
	} catch {
		return false;
	}
}
async function sendEmail(text, subject, replyTo) {
	const key = process.env.RESEND_API_KEY;
	const from = process.env.PROPOSAL_FROM || "proposals@ampglobalent.com";
	const to = process.env.PROPOSAL_TO || "info@ampglobalent.com";
	if (!key) {
		console.warn("[contact] RESEND_API_KEY is not set — notification not delivered");
		return {
			ok: false,
			error: "The submission service is not configured yet. Please email info@ampglobalent.com directly."
		};
	}
	try {
		const res = await fetch("https://api.resend.com/emails", {
			method: "POST",
			headers: {
				authorization: `Bearer ${key}`,
				"content-type": "application/json"
			},
			body: JSON.stringify({
				from,
				to,
				reply_to: replyTo,
				subject,
				text
			})
		});
		if (!res.ok) {
			console.error("[contact] resend status", res.status);
			return {
				ok: false,
				error: "Your proposal could not be sent. Please email info@ampglobalent.com directly."
			};
		}
		return { ok: true };
	} catch (e) {
		console.error("[contact] resend error", e.message);
		return {
			ok: false,
			error: "Your proposal could not be sent. Please email info@ampglobalent.com directly."
		};
	}
}
async function POST(request) {
	if (request.method !== "POST") return json(405, {
		ok: false,
		error: "Method not allowed."
	});
	const origin = request.headers.get("origin");
	if (origin && !ALLOWED_ORIGINS.some((o) => origin.startsWith(o)) && !origin.includes(".vercel.app")) return json(403, {
		ok: false,
		error: "Forbidden."
	});
	if (Number(request.headers.get("content-length") ?? 0) > LIMITS.bodyBytes) return json(413, {
		ok: false,
		issues: [{
			field: "file",
			message: "Files must be 4 MB or smaller. For larger catalogues, share a link instead."
		}]
	});
	let form;
	try {
		form = await request.formData();
	} catch {
		return json(400, {
			ok: false,
			error: "Malformed submission."
		});
	}
	const str = (k) => {
		const v = form.get(k);
		return typeof v === "string" ? v : "";
	};
	const file = form.get("file");
	if (file instanceof File && file.size > 0 ? file : null) return json(400, {
		ok: false,
		issues: [{
			field: "file",
			message: "Attachments are not enabled yet — please share a link to the catalogue instead."
		}]
	});
	const result = validateProposal({
		name: str("name"),
		email: str("email"),
		phone: str("phone"),
		message: str("message"),
		link: str("link"),
		company: str("company")
	});
	if (!result.ok) {
		if (result.issues.some((i) => i.code === "spam")) return json(200, { ok: true });
		return json(422, {
			ok: false,
			issues: result.issues.map((i) => ({
				field: i.field,
				message: i.message
			}))
		});
	}
	const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null;
	if (!await verifyTurnstile(str("turnstile") || null, ip)) return json(403, {
		ok: false,
		error: "Human verification failed. Please try again."
	});
	const { data } = result;
	const { subject, text } = buildNotification(data);
	const sent = await sendEmail(text, subject, data.email);
	if (!sent.ok) return json(502, {
		ok: false,
		error: sent.error
	});
	return json(200, { ok: true });
}
//#endregion
//#region \0virtual:astro:page:src/pages/api/contact@_@ts
var page = () => contact_exports;
//#endregion
export { page };
