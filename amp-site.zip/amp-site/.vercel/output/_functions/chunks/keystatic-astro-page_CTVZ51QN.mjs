import { t as __exportAll } from "./rolldown-runtime_D7D4PA-g.mjs";
import { i as renderComponent, l as renderTemplate } from "./server_CiKPUWoy.mjs";
import { t as createComponent } from "./compiler_DGFsWi42.mjs";
//#region node_modules/@keystatic/astro/internal/keystatic-astro-page.astro
var keystatic_astro_page_exports = /* @__PURE__ */ __exportAll({
	default: () => $$KeystaticAstroPage,
	file: () => $$file,
	prerender: () => false,
	url: () => void 0
});
var $$KeystaticAstroPage = createComponent(($$result, $$props, $$slots) => {
	return renderTemplate`${renderComponent($$result, "Keystatic", null, {
		"client:only": "react",
		"client:component-hydration": "only",
		"client:component-path": "/tmp/arena/tenants/fa958cbc-468d-4555-aed3-c1b852748be5/sessions/820ab33c-0db4-4df3-bdf3-904db682661d/workspace/amp-site/node_modules/@keystatic/astro/internal/keystatic-page.js",
		"client:component-export": "Keystatic"
	})}`;
}, "/tmp/arena/tenants/fa958cbc-468d-4555-aed3-c1b852748be5/sessions/820ab33c-0db4-4df3-bdf3-904db682661d/workspace/amp-site/node_modules/@keystatic/astro/internal/keystatic-astro-page.astro", void 0);
var $$file = "/tmp/arena/tenants/fa958cbc-468d-4555-aed3-c1b852748be5/sessions/820ab33c-0db4-4df3-bdf3-904db682661d/workspace/amp-site/node_modules/@keystatic/astro/internal/keystatic-astro-page.astro";
//#endregion
//#region \0virtual:astro:page:node_modules/@keystatic/astro/internal/keystatic-astro-page@_@astro
var page = () => keystatic_astro_page_exports;
//#endregion
export { page };
