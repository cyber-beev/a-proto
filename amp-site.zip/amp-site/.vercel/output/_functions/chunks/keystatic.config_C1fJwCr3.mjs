import { i as setOnSetGetEnv, n as getEnv$1, t as createInvalidVariablesError } from "./runtime_B2CN_IQS.mjs";
import { makeGenericAPIRouteHandler } from "@keystatic/core/api/generic";
import { collection, config, fields, singleton } from "@keystatic/core";
//#region node_modules/astro/dist/env/validators.js
function getEnvFieldType(options) {
	const optional = options.optional ? options.default !== void 0 ? false : true : false;
	let type;
	if (options.type === "enum") type = options.values.map((v) => `'${v}'`).join(" | ");
	else type = options.type;
	return `${type}${optional ? " | undefined" : ""}`;
}
var stringValidator = ({ max, min, length, url, includes, startsWith, endsWith }) => (input) => {
	if (typeof input !== "string") return {
		ok: false,
		errors: ["type"]
	};
	const errors = [];
	if (max !== void 0 && !(input.length <= max)) errors.push("max");
	if (min !== void 0 && !(input.length >= min)) errors.push("min");
	if (length !== void 0 && !(input.length === length)) errors.push("length");
	if (url !== void 0 && !URL.canParse(input)) errors.push("url");
	if (includes !== void 0 && !input.includes(includes)) errors.push("includes");
	if (startsWith !== void 0 && !input.startsWith(startsWith)) errors.push("startsWith");
	if (endsWith !== void 0 && !input.endsWith(endsWith)) errors.push("endsWith");
	if (errors.length > 0) return {
		ok: false,
		errors
	};
	return {
		ok: true,
		value: input
	};
};
var numberValidator = ({ gt, min, lt, max, int }) => (input) => {
	const num = Number.parseFloat(input ?? "");
	if (isNaN(num)) return {
		ok: false,
		errors: ["type"]
	};
	const errors = [];
	if (gt !== void 0 && !(num > gt)) errors.push("gt");
	if (min !== void 0 && !(num >= min)) errors.push("min");
	if (lt !== void 0 && !(num < lt)) errors.push("lt");
	if (max !== void 0 && !(num <= max)) errors.push("max");
	if (int !== void 0) {
		const isInt = Number.isInteger(num);
		if (!(int ? isInt : !isInt)) errors.push("int");
	}
	if (errors.length > 0) return {
		ok: false,
		errors
	};
	return {
		ok: true,
		value: num
	};
};
var booleanValidator = (input) => {
	const bool = input === "true" ? true : input === "false" ? false : void 0;
	if (typeof bool !== "boolean") return {
		ok: false,
		errors: ["type"]
	};
	return {
		ok: true,
		value: bool
	};
};
var enumValidator = ({ values }) => (input) => {
	if (!(typeof input === "string" ? values.includes(input) : false)) return {
		ok: false,
		errors: ["type"]
	};
	return {
		ok: true,
		value: input
	};
};
function selectValidator(options) {
	switch (options.type) {
		case "string": return stringValidator(options);
		case "number": return numberValidator(options);
		case "boolean": return booleanValidator;
		case "enum": return enumValidator(options);
	}
}
function validateEnvVariable(value, options) {
	const isOptional = options.optional || options.default !== void 0;
	if (isOptional && value === void 0) return {
		ok: true,
		value: options.default
	};
	if (!isOptional && value === void 0) return {
		ok: false,
		errors: ["missing"]
	};
	return selectValidator(options)(value);
}
//#endregion
//#region \0virtual:astro:env/internal
var schema = {
	"KEYSTATIC_SECRET": {
		"type": "string",
		"context": "server",
		"access": "secret",
		"optional": true
	},
	"KEYSTATIC_GITHUB_CLIENT_ID": {
		"type": "string",
		"context": "server",
		"access": "secret",
		"optional": true
	},
	"KEYSTATIC_GITHUB_CLIENT_SECRET": {
		"type": "string",
		"context": "server",
		"access": "secret",
		"optional": true
	},
	"PUBLIC_KEYSTATIC_GITHUB_APP_SLUG": {
		"type": "string",
		"context": "client",
		"access": "public",
		"optional": true
	}
};
//#endregion
//#region \0astro:env/server
/** @returns {string} */
var getEnv = (key) => {
	return getEnv$1(key);
};
var getSecret = (key) => {
	return getEnv(key);
};
var _internalGetSecret = (key) => {
	const rawVariable = getEnv(key);
	const variable = rawVariable === "" ? void 0 : rawVariable;
	const options = schema[key];
	const result = validateEnvVariable(variable, options);
	if (result.ok) return result.value;
	const type = getEnvFieldType(options);
	throw createInvalidVariablesError(key, type, result);
};
setOnSetGetEnv(() => {
	KEYSTATIC_SECRET = _internalGetSecret("KEYSTATIC_SECRET");
	KEYSTATIC_GITHUB_CLIENT_ID = _internalGetSecret("KEYSTATIC_GITHUB_CLIENT_ID");
	KEYSTATIC_GITHUB_CLIENT_SECRET = _internalGetSecret("KEYSTATIC_GITHUB_CLIENT_SECRET");
});
var KEYSTATIC_SECRET = _internalGetSecret("KEYSTATIC_SECRET");
var KEYSTATIC_GITHUB_CLIENT_ID = _internalGetSecret("KEYSTATIC_GITHUB_CLIENT_ID");
var KEYSTATIC_GITHUB_CLIENT_SECRET = _internalGetSecret("KEYSTATIC_GITHUB_CLIENT_SECRET");
//#endregion
//#region node_modules/@keystatic/astro/dist/keystatic-astro-api.js
function makeHandler(_config) {
	return async function keystaticAPIRoute(context) {
		var _config$clientId, _config$clientSecret, _config$secret;
		const { body, headers, status } = await makeGenericAPIRouteHandler({
			..._config,
			clientId: (_config$clientId = _config.clientId) !== null && _config$clientId !== void 0 ? _config$clientId : getSecret("KEYSTATIC_GITHUB_CLIENT_ID"),
			clientSecret: (_config$clientSecret = _config.clientSecret) !== null && _config$clientSecret !== void 0 ? _config$clientSecret : getSecret("KEYSTATIC_GITHUB_CLIENT_SECRET"),
			secret: (_config$secret = _config.secret) !== null && _config$secret !== void 0 ? _config$secret : getSecret("KEYSTATIC_SECRET")
		}, { slugEnvName: "PUBLIC_KEYSTATIC_GITHUB_APP_SLUG" })(context.request);
		return new Response(body, {
			status,
			headers
		});
	};
}
//#endregion
//#region keystatic.config.ts
/**
* Keystatic — the editor UI, mounted at /admin.
*
* Storage is 'local' by default so `npm run dev` gives a working CMS at
* http://localhost:4321/admin with no accounts and no keys. For the deployed
* site, set KEYSTATIC_GITHUB_CLIENT_ID / _SECRET / KEYSTATIC_SECRET and switch
* `storage` to the github block. Content lives in the repo as JSON and Markdoc
* either way — Keystatic is an editor over Git, not a database.
*
* The schemas here MUST mirror src/content.config.ts. If they drift, an editor
* can write something the build rejects.
*/
var seoObject = fields.object({
	title: fields.text({
		label: "Meta title",
		description: "Shown in search results and browser tabs. Max 60 characters.",
		validation: { length: { max: 60 } }
	}),
	description: fields.text({
		label: "Meta description",
		multiline: true,
		description: "The snippet under the title in search results, and the text in link previews. 50–160 characters.",
		validation: { length: {
			min: 50,
			max: 160
		} }
	})
}, { label: "Search & sharing (SEO)" });
var keystatic_config_default = config({
	storage: process.env.KEYSTATIC_GITHUB_CLIENT_ID ? {
		kind: "github",
		repo: {
			owner: "cyber-beev",
			name: "a-proto"
		}
	} : { kind: "local" },
	ui: {
		brand: { name: "AMP Global" },
		navigation: [
			"home",
			"about",
			"team",
			"contact",
			"---",
			"news"
		]
	},
	singletons: {
		home: singleton({
			label: "Home",
			path: "src/content/pages/home",
			format: { data: "json" },
			schema: {
				page: fields.text({
					label: "Page key (do not edit)",
					defaultValue: "home",
					validation: { isRequired: true }
				}),
				seo: seoObject,
				hero: fields.object({
					headlineBefore: fields.text({ label: "Headline — before the bold word" }),
					headlineEmphasis: fields.text({
						label: "Headline — the bold word",
						description: "Rendered at weight 700."
					}),
					headlineAfter: fields.text({ label: "Headline — after the bold word" }),
					lead: fields.text({
						label: "Lead paragraph",
						multiline: true
					}),
					ctaLabel: fields.text({ label: "Button label" })
				}, { label: "Hero" }),
				approach: fields.object({
					paragraphs: fields.array(fields.text({
						label: "Paragraph",
						multiline: true
					}), {
						label: "Body paragraphs",
						itemLabel: (p) => String(p.value ?? "").slice(0, 40) || "Paragraph"
					}),
					headingBefore: fields.text({ label: "Heading — before the bold word" }),
					headingEmphasis: fields.text({ label: "Heading — the bold word" }),
					headingAfter: fields.text({ label: "Heading — after the bold word" })
				}, { label: "Approach" }),
				focus: fields.object({
					heading: fields.text({ label: "Heading" }),
					body: fields.text({
						label: "Body",
						multiline: true
					}),
					regionOrder: fields.array(fields.text({ label: "Region id" }), {
						label: "Regions",
						description: "Ids from src/lib/regions.ts: africa, mena, south-asia, latam. Order sets the cycle.",
						itemLabel: (p) => String(p.value ?? "").slice(0, 40) || "Region"
					})
				}, { label: "Focus Regions" })
			}
		}),
		about: singleton({
			label: "About",
			path: "src/content/pages/about",
			format: { data: "json" },
			schema: {
				page: fields.text({
					label: "Page key (do not edit)",
					defaultValue: "about",
					validation: { isRequired: true }
				}),
				seo: seoObject,
				whatWeDo: fields.object({
					heading: fields.text({ label: "Heading" }),
					body: fields.text({
						label: "Body",
						multiline: true
					}),
					pillars: fields.array(fields.object({
						title: fields.text({ label: "Title" }),
						copy: fields.text({
							label: "Copy",
							multiline: true
						})
					}), {
						label: "Pillars",
						itemLabel: (p) => p.fields.title.value || "Pillar"
					})
				}, { label: "What We Do" }),
				edge: fields.object({
					heading: fields.text({ label: "Heading" }),
					items: fields.array(fields.object({
						title: fields.text({ label: "Title" }),
						copy: fields.text({
							label: "Copy",
							multiline: true
						}),
						icon: fields.select({
							label: "Icon",
							defaultValue: "pin",
							options: [
								"pin",
								"scale",
								"build",
								"data",
								"curve",
								"wave",
								"mic",
								"headphones"
							].map((v) => ({
								label: v,
								value: v
							}))
						})
					}), {
						label: "Items",
						itemLabel: (p) => p.fields.title.value || "Item"
					})
				}, { label: "Our Edge" }),
				who: fields.object({
					heading: fields.text({ label: "Heading" }),
					intro: fields.text({
						label: "Intro",
						multiline: true
					}),
					items: fields.array(fields.object({
						label: fields.text({ label: "Label" }),
						icon: fields.select({
							label: "Icon",
							defaultValue: "head",
							options: [
								"head",
								"catalogue",
								"record",
								"partners",
								"mic",
								"headphones",
								"wave",
								"curve"
							].map((v) => ({
								label: v,
								value: v
							}))
						})
					}), {
						label: "Items",
						itemLabel: (p) => p.fields.label.value || "Item"
					})
				}, { label: "Who We Work With" })
			}
		}),
		team: singleton({
			label: "Team",
			path: "src/content/pages/team",
			format: { data: "json" },
			schema: {
				page: fields.text({
					label: "Page key (do not edit)",
					defaultValue: "team",
					validation: { isRequired: true }
				}),
				seo: seoObject,
				heading: fields.text({ label: "Heading" }),
				body: fields.text({
					label: "Body",
					multiline: true
				}),
				groupLabel: fields.text({
					label: "Group label",
					description: "e.g. \"Founders\""
				}),
				members: fields.array(fields.object({
					name: fields.text({ label: "Name" }),
					role: fields.text({ label: "Role" }),
					photo: fields.text({
						label: "Photo path",
						description: "e.g. /images/temi.webp — upload via the repo, then paste the path."
					}),
					photoAlt: fields.text({
						label: "Photo alt text",
						description: "Describe the person for screen readers."
					})
				}), {
					label: "Members",
					itemLabel: (p) => p.fields.name.value || "Member"
				})
			}
		}),
		contact: singleton({
			label: "Contact",
			path: "src/content/pages/contact",
			format: { data: "json" },
			schema: {
				page: fields.text({
					label: "Page key (do not edit)",
					defaultValue: "contact",
					validation: { isRequired: true }
				}),
				seo: seoObject,
				statement: fields.object({
					headingBefore: fields.text({ label: "Heading — before the bold word" }),
					headingEmphasis: fields.text({ label: "Heading — the bold word" }),
					headingAfter: fields.text({ label: "Heading — after the bold word" }),
					body: fields.text({
						label: "Body",
						multiline: true
					}),
					regionsLine: fields.text({ label: "Regions line" }),
					email: fields.text({
						label: "Contact email",
						validation: { isRequired: true }
					})
				}, { label: "Statement" }),
				proposal: fields.object({
					heading: fields.text({ label: "Heading" }),
					body: fields.text({
						label: "Body",
						multiline: true
					}),
					submitLabel: fields.text({ label: "Submit button label" }),
					fileHint: fields.text({
						label: "File hint",
						description: "Must match the real limit — see docs/fr7-contact-form.md."
					}),
					successMessage: fields.text({
						label: "Success toast",
						description: "Never interpolate the submitter's input here."
					}),
					errorMessage: fields.text({ label: "Error toast" })
				}, { label: "Proposal form" })
			}
		})
	},
	collections: { news: collection({
		label: "News",
		slugField: "title",
		path: "src/content/news/*",
		format: { contentField: "body" },
		columns: [
			"title",
			"publishedOn",
			"draft"
		],
		schema: {
			title: fields.slug({ name: { label: "Title" } }),
			publishedOn: fields.date({
				label: "Published on",
				defaultValue: { kind: "today" }
			}),
			excerpt: fields.text({
				label: "Excerpt",
				multiline: true,
				description: "Used in the listing and as the meta description. Max 200 characters.",
				validation: { length: { max: 200 } }
			}),
			cover: fields.text({ label: "Cover image path" }),
			coverAlt: fields.text({ label: "Cover alt text" }),
			tags: fields.array(fields.text({ label: "Tag" }), {
				label: "Tags",
				itemLabel: (p) => String(p.value ?? "").slice(0, 40) || "Tag"
			}),
			draft: fields.checkbox({
				label: "Draft",
				defaultValue: true,
				description: "Drafts are excluded from the site and the sitemap."
			}),
			body: fields.markdoc({ label: "Body" })
		}
	}) }
});
//#endregion
export { makeHandler as n, keystatic_config_default as t };
