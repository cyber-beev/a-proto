import { defineConfig } from 'astro/config';
import markdoc from '@astrojs/markdoc';
import react from '@astrojs/react';
import keystatic from '@keystatic/astro';
import sitemap from '@astrojs/sitemap';
import vercel from '@astrojs/vercel';

export default defineConfig({
  site: 'https://ampglobalent.com',
  // WordPress served /about-us/ with a trailing slash; keeping 'always' means
  // canonicals, sitemap and the redirect table all agree and no 308s are issued.
  trailingSlash: 'always',
  output: 'static',
  adapter: vercel(),
  integrations: [react(), markdoc(), keystatic(), sitemap({ filter: (p) => !p.includes('/admin') })],
  image: { responsiveStyles: true },
  // React is present for one reason only: Keystatic's admin UI is a React app
  // and its integration injects `/keystatic/[...params]` with
  // `client:only="react"`. No public page renders React — verify with
  // `npm run audit:public` after any change to the integrations list.
  vite: {
    build: { assetsInlineLimit: 2048 },
    // The matrix and pager are hand-written TS with no dependencies to prebundle.
    optimizeDeps: { exclude: ['@keystatic/core'] },
  },
  devToolbar: { enabled: false },
  // @keystatic/astro reads its GitHub credentials through astro:env, so they
  // must be declared even in local mode (where they are simply unused). Only
  // Keystatic's own variables belong here: Astro exposes PUBLIC_* through
  // import.meta.env automatically, and the contact endpoint reads its secrets
  // from process.env, which Vercel populates for serverless functions.
  env: {
    schema: {
      KEYSTATIC_SECRET: { type: 'string', context: 'server', access: 'secret', optional: true },
      KEYSTATIC_GITHUB_CLIENT_ID: { type: 'string', context: 'server', access: 'secret', optional: true },
      KEYSTATIC_GITHUB_CLIENT_SECRET: { type: 'string', context: 'server', access: 'secret', optional: true },
      PUBLIC_KEYSTATIC_GITHUB_APP_SLUG: { type: 'string', context: 'client', access: 'public', optional: true },
    },
  },
});