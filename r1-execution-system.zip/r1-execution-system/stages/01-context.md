# Stage 1 — Context (Einleitung)

## Goal

Why the project exists, who is involved, where its edges are.

## Ask

1. What is the current situation / what triggered this project?
2. What is the concrete goal — describe the end state in plain words.
3. Why this solution? What does the client get out of it, what do end users get?
4. Who is involved? (client, planners, suppliers, internal reviewers/leads — names + roles)
5. What interfaces exist — technical and organizational?
6. What is explicitly OUT of scope?

## Generate

| Artifact | Path | Format |
| --- | --- | --- |
| Situation & background | `specs/product/context.md` §Situation | prose |
| Project goal (overall picture, description, justification) | `specs/product/context.md` §Goal | prose |
| Stakeholders & interfaces | `specs/product/context.md` §Stakeholders | table or mermaid `flowchart LR` |
| Scope boundary | `specs/product/SCOPE_LATEST.yaml` | yaml: in-scope / out-of-scope lists |
| Deviations log | `specs/product/deviations.md` | empty table (date, deviation, reason, impact) |

## Gate

Out-of-scope list must be non-empty and explicit — a scope with no edges fails.

## bigpowers mapping

`elaborate-spec` + `scope-work` output; deviations.md implements compliance rule #4 (change-request-only after kickoff).
