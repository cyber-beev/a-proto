# Stage 4 — Design & Implementation (Durchführung)

## Goal

Architecture decided, logic specified, build documented.

## Ask

1. Major components and who owns which responsibility?
2. Interfaces between components — protocols, message/command names both directions?
3. Runtime states and transitions? Walk through one full interaction end-to-end.
4. Key technology decisions and alternatives rejected? (ADR material)
5. During execution: what was built per component, decisions made, pitfalls hit?

## Generate

| Artifact | Path | Format |
| --- | --- | --- |
| Architecture overview + responsibility split | `specs/tech-architecture/architecture.md` | prose + mermaid `flowchart` |
| Component diagram | same doc | mermaid `flowchart` subgraphs |
| Sequence diagram(s) — one per core interaction | `specs/tech-architecture/sequences.md` | mermaid `sequenceDiagram` |
| State diagram | `specs/tech-architecture/state.md` | mermaid `stateDiagram-v2` |
| Interface/protocol definition | `specs/tech-architecture/interfaces.md` | table (direction, command, payload, trigger) |
| Decision records | `specs/adr/NNNN-*.md` | one short ADR per decision (context, decision, consequence) |
| Implementation log | `specs/epics/<epic>/implementation-notes.md` | prose per component |

## Gate

Every component boundary appears in ≥1 diagram; every cross-component message defined in interfaces.md; every "we chose X over Y" becomes an ADR.

## bigpowers mapping

`specs/adr/`, `specs/tech-architecture/tech-stack.md`.
