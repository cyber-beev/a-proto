# Stage 2 — Analysis (Analyse)

## Goal

Requirements fully enumerated, stable, measurable.

## Ask

1. What must the system DO? Collect loosely — you structure them.
2. For each functional area: what happens on edge cases (invalid input, interruption, timeout)?
3. What quality bars apply? Probe explicitly: reliability/recovery, performance limits, maintainability, usability, security.
4. Which actors interact with the system and how? (for use-case diagram)

## Generate

| Artifact | Path | Format |
| --- | --- | --- |
| Requirements FR-xx | `specs/product/requirements.md` §Functional | table: ID, requirement, acceptance criterion |
| Requirements NFR-xx | `specs/product/requirements.md` §Non-functional | table: ID, requirement, measurable threshold |
| Use-case diagram | `specs/product/use-cases.md` | mermaid |

## Gate (hard)

Every FR has an objective acceptance criterion. Every NFR has a number/threshold. IDs assigned here LOCK — later stages generate against them.

## bigpowers mapping

Feeds `slice-tasks` stories later; NFRs feed Stage 3 QS plan.
