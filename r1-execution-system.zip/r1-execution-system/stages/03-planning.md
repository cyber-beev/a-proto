# Stage 3 — Planning (Planung)

## Goal

How work will be executed, controlled, quality-assured, and paid for.

## Ask

1. Process model — waterfall / extended waterfall / agile hybrid? Any preference or constraint?
2. Total hour budget? Any client- or exam-specific phase constraints?
3. How should hours split into phases → work packages? (rough priorities fine; you draft the PSP)
4. What counts as "done well" for this project? Which quality measures: reviews? test strategy? doc standards?
5. Milestones — which completions matter, target dates?
6. Resources — software licenses, hardware, people with roles?
7. Economics needed? make-or-buy reasoning, hourly rate, hardware costs, benefit/amortization?

## Generate

| Artifact | Path | Format |
| --- | --- | --- |
| Process model + rationale | `specs/planning/approach.md` | prose |
| Time plan (PSP): phases → work packages x.y with estimates | `specs/release-plan.yaml` + human table in `specs/planning/time-plan.md` | yaml + table |
| Gantt | `specs/planning/gantt.md` | mermaid `gantt` |
| Milestone plan (PSP-code ref, Soll dates) | `specs/planning/milestones.md` | table |
| QS plan (measures ↔ quality criteria ↔ NFRs from Stage 2) | `specs/planning/quality-plan.md` | prose + table |
| Resource plan | `specs/planning/resources.md` | table |
| Make-or-buy + costs + amortization | `specs/planning/economics.md` | prose + cost table + formula |

## Gates (hard)

Σ work-package hours ≤ budget · buffer line ≥2h present · every QS measure maps to ≥1 NFR.

## bigpowers mapping

`plan-release` → release-plan.yaml; `slice-tasks`/`plan-work` → epic capsules per work package; milestone plan ≈ release ordering.
