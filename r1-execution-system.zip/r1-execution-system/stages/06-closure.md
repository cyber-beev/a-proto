# Stage 6 — Closure (Abschluss)

## Goal

Formal acceptance and honest accounting. Mostly GENERATED from earlier stages — ask only for actuals and events.

## Ask

1. Actual hours per phase/work package? (vs `specs/release-plan.yaml`)
2. All test cases passed? Bugs resolved?
3. Acceptance event — date, participants, demo scope, defects found (or none)?
4. Hand-over items — user manual needed? tech docs audience? training?
5. Lessons learned, outlook/future ideas?

## Generate

| Artifact | Path | Format |
| --- | --- | --- |
| Functional Soll-Ist | `specs/closure/soll-ist.md` §Functional | GENERATED from test protocol summary |
| Hours Soll-Ist | `specs/closure/soll-ist.md` §Hours | table: phase, Soll h, Ist h, deviation, justification (user supplies actuals + reasons) |
| Acceptance protocol | `specs/closure/acceptance.md` | structured md: version-pinned references, per-requirement verdicts (from test protocol), defect list w/ priorities 1–4, declaration checkboxes, warranty + change-request terms |
| Lessons learned + outlook | `specs/closure/lessons-learned.md` | prose |
| User manual | `specs/closure/user-manual.md` | plain-language prose (non-technical audience) |
| Final bundle | appendix order per PROJECT_TEMPLATE.md | A1…A15 assembled from all stages |

## Gates (hard)

- Acceptance references exact versions of requirements/test docs.
- Open FAILs or unresolved bugs block the acceptance declaration.
- Post-acceptance changes go ONLY through `specs/product/deviations.md` / change-request entries.

## bigpowers mapping

`verify-work` results + `trace-requirement` coverage matrix → acceptance protocol; close out `specs/state.yaml`.
