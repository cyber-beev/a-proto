# Project Documentation Template — extracted from IHK FIAE Projektbericht

Source: `IHK-FIAE-Dokumentation-Bamigboye-Oluwafemi.pdf`
Purpose: canonical stage sequence + per-stage info intake + artifacts (markdown/mermaid) that the R1 Execution System generates.
Each stage = one AI-guided interview → confirmed context → generated documents. No stage starts before the previous stage's artifacts are confirmed.

---

## Compliance rules baked into the template (non-negotiable gates)

1. **Traceability chain**: every Requirement ID (FR-/NFR-) must have ≥1 Test Case (FT-/NFT-); every TC must appear in the Acceptance Protocol. Nothing ships untraced.
2. **Time budget**: total hours split across phases; buffer ≥2h tracked as its own line.
3. **Versioned reference docs**: acceptance references exact versions of spec/test docs ("Pflichtenheft v2.2"), so regenerate-with-changes bumps versions.
4. **Scope boundary**: explicit in/out-of-scope list (Projektabgrenzung) — deviations after kickoff go through change requests, documented in "Abweichungen".
5. **Soll-Ist accounting**: planned vs actual hours per work package, every deviation justified.

---

## Stage pipeline

### Stage 1 — Context (Einleitung)

**Goal**: why does this project exist, who is involved, where are the edges.

Intake questions:

- What is the current situation / trigger for the project?
- What is the concrete goal (measurable core functionality)?
- Why this solution — operator + end-user motivation?
- Who are the parties: client, planners, content suppliers, internal reviewers/leads?
- What interfaces (technical + organizational) exist?
- What is explicitly OUT of scope?

Artifacts:

| Doc | Format |
| --- | --- |
| Situation & background | prose md |
| Project goal (overall picture + description + justification) | prose md |
| Stakeholders & interfaces | table or mermaid `flowchart LR` |
| Scope boundary (in/out) | two-column table |
| Deviations log (starts empty) | table |

bigpowers mapping: `elaborate-spec` + `scope-work` → `specs/product/SCOPE_LATEST.yaml`, `specs/state.yaml`.

---

### Stage 2 — Analysis (Analyse)

**Goal**: requirements, fully enumerated and stable.

Intake questions:

- What must the system DO? (→ functional requirements, FR-xx, one behavior each)
- What quality bars apply? reliability, performance (<X s), maintainability, usability… (→ NFR-xx, measurable)
- Which actors interact with the system and how? (for use-case diagram)

Artifacts:

| Doc | Format |
| --- | --- |
| Requirements list FR/NFR with IDs | table (ID, requirement, acceptance criterion) |
| Use-case diagram | mermaid `graph`/custom |

Gate: every FR has an objective acceptance criterion; NFRs are measurable.

bigpowers mapping: requirements feed `specs/product/`; use-cases inform stories later (`slice-tasks`).

---

### Stage 3 — Planning (Planung)

**Goal**: how the work will be executed, controlled, and paid for.

Intake questions:

- Vorgehensmodell: waterfall / extended waterfall / agile hybrid — and why?
- Total hour budget? Split into phases → work packages (PSP codes x.y) with estimates.
- Quality criteria + QS measures: reviews? test strategy (module/integration)? documentation standards?
- Milestones: which work-package completions count, target dates?
- Resources: software, hardware, people (with roles)?
- Economics: make-or-buy reasoning, cost calc (hours × rate + hardware), benefit & amortization?

Artifacts:

| Doc | Format |
| --- | --- |
| Process model choice + rationale | prose md |
| Time plan: phases → work packages (PSP) | table (code, description, est. h) |
| Gantt | mermaid `gantt` |
| Milestone plan (PSP-code ref, Soll/Ist dates) | table |
| QS plan (measures mapped to quality criteria) | prose + table |
| Resource plan | table |
| Make-or-buy decision | prose md |
| Cost table + amortization calc | table + formula |

Gates: Σ hours ≤ budget, buffer present.

bigpowers mapping: `plan-release` → `specs/release-plan.yaml`; `slice-tasks`/`plan-work` → epic capsules + `-tasks.yaml`; milestone plan ≈ release-plan ordering.

---

### Stage 4 — Design & Implementation (Durchführung)

**Goal**: architecture decided, logic specified, build documented.

Intake questions:

- System components and responsibilities? (component diagram)
- Communication protocols/interfaces between components? (formal message/command definitions)
- Runtime states + transitions? (state machine)
- Signal/data flow end-to-end? (sequence diagram)
- Implementation notes per component (what was built, key decisions, pitfalls hit)?

Artifacts:

| Doc | Format |
| --- | --- |
| Architecture overview + responsibilities split | prose + mermaid `flowchart` |
| Component diagram | mermaid `flowchart` subgraphs |
| Sequence diagram(s) | mermaid `sequenceDiagram` |
| State diagram | mermaid `stateDiagram-v2` |
| Protocol/interface definition (commands both directions) | table or fenced block |
| Implementation log per component | prose md |

bigpowers mapping: `specs/adr/` decisions; `specs/tech-architecture/tech-stack.md`; diagrams live beside the epics they describe.

---

### Stage 5 — Quality Assurance (Qualitätssicherung)

**Goal**: prove every requirement is met.

Intake questions:

- Test environment (hardware/software/tools)?
- Test phases (unit/module → integration)?
- For each FR/NFR: concrete test steps, expected result? → auto-generate TC IDs from requirement IDs
- Roles: executor vs acceptor?

Artifacts:

| Doc | Format |
| --- | --- |
| Test concept (env, strategy, roles) | prose md |
| Test case table (TC-ID ↔ Req-ID, description, expected result) | table — GENERATED from Stage 2 requirements |
| Test protocol (actual result, PASS/FAIL, measurements, remarks) | table |
| Measurement records for NFRs (e.g. latency runs) | table + stats |

Gate: all TCs executed; FAILs become bugs (bigpowers `specs/bugs/BUG-*.md`) before proceeding.

bigpowers mapping: `plan-tests`, `develop-tdd`, `verify-work`.

---

### Stage 6 — Closure (Abschluss)

**Goal**: formal acceptance and honest accounting.

Intake questions:

- Functional result vs plan? (all TCs passed?)
- Hours actuals per phase/work package + reasons for deviation?
- Acceptance date, participants, demo scope, defect list (or none)?
- Hand-over items (user manual, tech docs, training)?
- Lessons learned + outlook?

Artifacts:

| Doc | Format |
| --- | --- |
| Soll-Ist comparison (functional + hours, deviations explained) | tables — GENERATED from Stage 3 plan + tracked actuals |
| Acceptance protocol (reference doc versions, per-requirement verdict, defect list w/ priorities, declaration checkboxes, warranty/change-request terms) | structured md |
| Lessons learned + outlook | prose md |
| User manual (non-technical audience) | prose md |
| Technical documentation | prose md |

Gates: acceptance only with version-pinned reference docs; post-acceptance changes → change-request procedure only.

bigpowers mapping: `verify-work` Phase results → Soll-Ist; `trace-requirement` → coverage matrix feeding the acceptance protocol; session close updates `specs/state.yaml`.

---

## Generated appendix set (final deliverable bundle)

A1 Requirements spec · A2 PSP · A3 Time plan · A4 Milestones · A5 Gantt · A6 Use-case · A7 Components · A8 Sequence · A9 State · A10 Test concept · A11 Test protocol · A12 Acceptance protocol · A13 Hours Soll-Ist · A14 User manual · A15 Tech documentation

All diagrams mermaid-in-markdown; all tables plain markdown. Front matter: title page, TOC (auto), abbreviation glossary, source/reference list.

## System flow recap

```
init project → Stage 1 interview → confirm → Stage 2 → … → Stage 6 → bundle export
```

Every stage: ask → draft → user confirms → persist artifacts under `specs/` in bigpowers layout → advance. Confirmation locks the stage's IDs so later stages can generate against them (requirements drive tests, plan drives Soll-Ist).
