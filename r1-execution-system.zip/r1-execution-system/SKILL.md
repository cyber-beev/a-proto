---
name: r1-execution-system
description: Run a project through a staged documentation engine — AI-assisted interviews that generate compliant planning and execution docs (requirements, PSP/Gantt, architecture diagrams, test cases, acceptance protocol) as markdown + mermaid in bigpowers layout. Use when the user wants to init/start/continue an R1 project, create project documentation, or says "init a new project", "next stage", "r1".
---

# R1 Execution System

Agent-native project documentation engine. No code to run: you ARE the engine. You interview the user stage by stage, draft formal artifacts from their rough answers, get confirmation, persist files, advance.

## Protocol

1. **Init**: `init a new project <name>` → create `<name>/specs/state.yaml` from the template below.
2. **Resume**: read `<name>/specs/state.yaml` → first stage not `confirmed`.
3. **Interview**: load `stages/<NN>-<name>.md` (same directory as this file). Ask intake questions in batches of 3–4. Never invent answers.
4. **Draft-from-answers rule**: the user answers loosely; YOU produce the formal artifacts (requirement tables, mermaid diagrams, cost calcs). Never make the user format anything.
5. **Confirm**: show drafts; iterate until approved.
6. **Persist**: write artifacts to the paths listed in the stage file, update `state.yaml` (stage → `confirmed`, artifacts listed), then stop. The next stage starts only on explicit request.
7. **Gates**: if a stage declares a hard gate and the draft violates it, fix before showing or flag explicitly why it can't be met.

## state.yaml template

```yaml
project:
  name:
  created:
  client:
stages:
  context: pending   # pending | drafted | confirmed
  analysis: pending
  planning: pending
  design: pending
  qa: pending
  closure: pending
artifacts: []        # path: confirmed-version/date
```

## Project directory layout

```text
<project>/specs/
  state.yaml
  product/           # context, scope, requirements (Stages 1–2)
  planning/          # approach, time plan, gantt, milestones, QS, resources, economics (Stage 3)
  release-plan.yaml
  adr/               # decisions (Stage 4)
  tech-architecture/ # diagrams + interfaces (Stage 4)
  tests/             # concept, cases, protocol, measurements (Stage 5)
  bugs/              # failed test cases → BUG-<id>.md
  closure/           # Soll-Ist, acceptance, lessons learned, manuals (Stage 6)
```

## References (relative to this skill)

- `TEMPLATE.md` — canonical stage pipeline, compliance gates, appendix bundle order A1–A15. Compliance rules there are non-negotiable: traceability chain FR→TC→acceptance, buffer ≥2h tracked, versioned acceptance references, change-request-only deviations.

## Stage order

context → analysis → planning → design → qa → closure. IDs lock at confirmation: Stage 2 requirement IDs drive Stage 5 test-case generation; Stage 3 plan drives Stage 6 Soll-Ist.
